Parts file (parts.cir): SWX is a binary switch: closed resistance ron when V(c,r) > 1.65 V, 100 Mohm otherwise. INDQ has series resistance 2*pi*1 MHz*L/30 (Q = 30 at 1 MHz). CAPX has ESR = 0.02/sqrt(C in uF) ohm. Each has tolerance parameters (kc, kr, kl, default 1) that are scaled for corners. Usable capacitance range is about 10 nF to 100 uF.

Noise tones on the 12 V source: 0.105, 0.43, 0.6, 0.82, 1.255, 1.7, 2.35, 3.0, 3.76, 4.4, 4.99 MHz and one additional tone at 0.27 MHz, each 10 mV peak with zero phase.

Sampling background: a tone at f aliases to |f - k*250 kHz| for the nearest integer k. Anything whose alias lands within 0-20 kHz counts as in-band, and a fold to exactly 0 Hz is removed with the mean. Under a 30 kHz triangular spread of +/-100 kHz, a switching fundamental and its harmonics sweep their alias frequency across the band instead of sitting on one value. Tuned notches and traps have a bandwidth of a few percent, and a +/-15% capacitor or +/-10% inductor tolerance moves their center by 5-8%.

Practice: ripple of a buck-type stage is about (1-D)*Vo/(8*L*C*f^2) peak-to-peak before ESR. LC corner attenuation is 40 dB/decade per stage above the corner. Inductor DCR, ESR and switch Ron set conduction loss. Return current in a ground segment produces a voltage of about I*(R + j*2*pi*f*L). A 6 nH segment is 38 mohm at 1 MHz, so about 8 mohm + 38 mohm per segment. Anything that shares the analog reference path with pulsed current appears directly in the rail as the converter sees it. Sensing the output at the converter reference removes drops in the return from the regulated quantity.

Simulation practice: edge transitions of 3 ns need time steps of about 0.5 ns or finer near edges and 5-20 ns elsewhere. Start-up ramps and load steps need the return to settle before the stay-inside window is evaluated.

Sampling phase: the sampler is asynchronous, so its phase relative to clk is arbitrary. Test with several offsets within one 4 us sample period.
