I need a 12 V to 5.0 V power block for our mixed-signal sensor board. The 12 V digital rail is noisy. A 16-bit converter sampled at 250 kS/s, asynchronous to the block's clock, reads the 5.0 V analog rail, and anything that aliases into 0-20 kHz shows up as reading noise. The board clock driving the block is spread-spectrum, so the block must hold across the whole wander, not only at nominal.

Fixed interfaces
- Subcircuit `abk` with ports in this order: vin12 vout5 clk dgnd a b c.
- Ground copper dgnd-a-b-c is in /app/input_assets/ground_network.cir (subcircuit GNET, 8 mohm + 6 nH per segment). The converter reference and the load return are at node c. Your block may connect its returns to any of dgnd, a, b, c.
- The 12 V source returns to dgnd through 0.5 ohm + 100 nH in series, with twelve noise tones of 10 mV each between 0.1 and 5 MHz.
- clk is a 0/3.3 V logic input: triangular spread 0.9-1.1 MHz at 30 kHz rate, 3 ns edges, 0.3 ns rms jitter. The whole spread profile may sit anywhere from 0.97x to 1.03x of nominal.
- Load 10-60 mA, resistive, from vout5 to c.
- Power path uses only the parts in /app/input_assets/parts.cir (SWX switches, INDQ inductors, CAPX capacitors) plus plain resistors. Capacitors vary +/-15% and inductors +/-10%. Control circuitry (behavioral sources, small R/C) may sense any node but may only drive switch control pins, may not use time or any clock other than clk, and its own power is covered by a fixed 1 mW added to input power.

Definitions
- Rail = V(vout5) - V(c).
- In-band noise = rms of the 0-20 kHz content of the rail, sampled by an ideal unfiltered 250 kS/s sampler at any sampling phase, mean removed, over a record of at least 2 ms after 1 ms of settling.
- Efficiency = mean load power / (mean power from the 12 V source + 1 mW), over whole 33.3 us clock-modulation periods.

Requirements (all with loads of 10, 35 and 60 mA, any clock offset in range, any component corner, unless stated)
1. Mean rail 4.90 V to 5.10 V.
2. In-band noise <= 20 uV rms.
3. In-band noise <= 25 uV rms with an additional 150 mA peak, 1.013 MHz sine current injected between node a and dgnd.
4. Efficiency >= 80% at 35 mA and >= 70% at 10 mA.
5. Load step 10 -> 60 mA in 1 us: rail inside 4.90-5.10 V within 40 us and stays inside for the next 160 us.
6. Start-up at 35 mA with 12 V ramping 0 -> 12 V in 20 us: rail enters 4.90-5.10 V within 300 us, never exceeds 5.5 V, and stays inside afterwards.
7. Switch area sum(0.15 ohm / ron) <= 4.0 over all SWX instances, ron between 0.15 and 2 ohm; total inductance <= 10 uH.
8. The in-band noise result must be numerically converged: it changes by no more than 20% or 2 uV, whichever is larger, when the time resolution of the evaluation is made twice as fine.

Deliver /app/output/abk.cir: a SPICE netlist defining subcircuit abk. Do not include the parts file; it is loaded for you.
