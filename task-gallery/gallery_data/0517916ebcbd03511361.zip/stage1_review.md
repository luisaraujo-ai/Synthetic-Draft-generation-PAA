### 11 · Quiet 5 V analog rail with spread clock and ground-return partition — advance, rank 8

Design decision as written: yes — "I need a 12 V to 5.0 V power block for our mixed-signal sensor board" with "Deliver /app/output/abk.cir: a SPICE netlist defining subcircuit abk". The agent chooses the converter topology, filter staging, where each return ties into the dgnd-a-b-c copper, switch ron/area, inductor/capacitor values, and the control law built from `clk` alone.

Forge task: design a subcircuit `abk vin12 vout5 clk dgnd a b c` (SWX/INDQ/CAPX + resistors in the power path; behavioral control only on switch pins) that delivers 4.90–5.10 V into 10–60 mA from a noisy 12 V rail with a spread-spectrum 0.9–1.1 MHz clock, holding ≤20 µV rms aliased 0–20 kHz rail noise at 250 kS/s (≤25 µV with a 150 mA / 1.013 MHz burst into a→dgnd), ≥80% / ≥70% efficiency at 35 / 10 mA, load-step and start-up band entry, sum(0.15/ron) ≤ 4.0 and Ltotal ≤ 10 µH, plus timestep-converged noise numbers.

Why it fits:
- It is a design decision (a circuit), not analysis: the deliverable is a netlist the agent must synthesize; the simulation is the grader's instrument.
- Every requirement maps to a scripted check: ngspice transients for R1/R2/R3/R5/R6, waveform-integrated power for R4, a statement parser for R7, and a re-run at half timestep for R8. No human-in-the-loop measurement is needed.
- The core engineering tension is real and survives translation to simulation: spread spectrum plus component tolerance kills tuned traps, so attenuation must be broadband; broadband filtering plus a 12→5 V step-down fights the efficiency and area limits; and the ground-return partition plus Kelvin sensing at node c is exactly the classical quiet-rail problem.
- The aliasing definition (tone at f folds to |f − k·250 kHz|, DC folds removed) is stated precisely enough to implement deterministically.
- Multiple valid architectures are plausible (cascaded buck + LC, interleaved, switch-cap front end), so the task does not secretly encode one reference topology.

What stops it:
- Structural objections: none. The idea as written is a bounded single-deliverable design task.
- Unresolved feasibility risks (not yet demonstrated): (a) the reference outline is an author proposal, not a passing design — no run showing ≤20 µV rms at all corners exists in the payload; (b) full-grid verification cost is unknown: ~3 loads × several clock scales × corner sets × burst on/off × several sampling phases × two timesteps is on the order of 50+ transients of 2–3 ms each with 0.5 ns steps near 3 ns edges; if each run takes minutes, the grader sweep and an agent's iteration loops may exceed a two-hour run; (c) the corner scaling of kc/kr/kl is not quantified anywhere in the payload; (d) the parts library's behavioral expression `V(d,s)/(V(c,r) > 1.65 ? {ron} : 1e8)` and the `8m` / `6n` suffixes must be confirmed to parse and behave as intended in the pinned ngspice version; (e) R8 as written (change ≤20% or 2 µV when halving the step) can be satisfied trivially if the base step is already fine — the discriminator depends on how the checker picks the base step and how it handles the 3 ns edges.

How to check it:
- ngspice (transient, variable timestep): mean rail, rail waveform during the 10→60 mA step and the 20 µs input ramp, source and load currents/periods for efficiency, burst case.
- numpy (FFT of the 250 kS/s resampled `V(vout5)-V(c)`, mean removed) + the stated fold rule: in-band 0–20 kHz rms for R2/R3 and the R8 convergence comparison.
- A netlist parser (Python) for R7: element types, ron/l parameter evaluation, control-source drive nodes, and a ban on `time` and on any source other than parts + behavioral control.
- Wrapper the checker owns: 0.5 Ω + 100 nH source with the twelve 10 mV tones, the GNET ground copper, triangular spread clock with jitter, resistive loads, burst injector, ideal sampler at several phases within the 4 µs sample period.

Simulation gaps:
- Ideal binary switch (instantaneous state change at 1.65 V, fixed 100 MΩ off-state) has no body-diode / dead-time / gate-charge loss and no dv/dt coupling; real switch loss and shoot-through are not modeled.
- INDQ is a fixed-Q-30-at-1 MHz series-R model: no saturation, no core loss spectrum, no frequency-dependent winding capacitance. CAPX is a lumped ESR model: no ESL, no dielectric absorption, no DC-bias derating — and real MLCC capacitance loss with bias would move the filter corners.
- No PCB parasitics beyond the fixed 8 mΩ + 6 nH/segment chain; real plane spreading, via arrays, and component-loop inductance are absent, so the delivered noise margin in sim will be optimistic relative to hardware.
- Ideal 250 kS/s sampler with no aperture jitter or ADC reference noise; the real converter's own reference/decoupling noise is out of scope by construction.
- Numerical: FFT leakage with a 2 ms record (500 Hz bins) and a swept 0.9–1.1 MHz switching fundamental is the dominant measurement error; the declared 1 µV allowance is an author assertion to be validated, and R8's base/half-step pair is sensitive to how the checker handles 3 ns edges.

Why frontier models fail:
- The naive move is a tuned trap at 1.000 MHz or a ground tie that cancels at one frequency: it looks far under limit at the nominal clock and one sampling phase, but the ±10 % spread, ±15 %/±10 % part tolerance and held-out clock scales swing the alias into 0–20 kHz. Seeing that requires reasoning about the fold |f − k·250 kHz| over a continuously moving f, not at one frequency.
- Coupled constraints: ripple attenuation (multi-stage LC, DCR/ESR resistance, output impedance) trades directly against R4 efficiency and R7 area/inductance, and against R5 load-step recovery (stiffer filtering = slower loop), while R3 forces the ground-return partition and Kelvin sensing at node c to be right — these cannot be satisfied one requirement at a time.
- The control-law constraints (no `time`, no clock other than `clk`) rule out textbook compensators and force a clk-derived PWM/PFM scheme that must also be light-load efficient for R4 at 10 mA.
This is a hypothesis about model behavior; it is not trial-supported.

Real-world risks:
- Even a design passing every simulated check would face real PCB parasitics, capacitor DC-bias/temperature drift, inductor saturation, and switch/thermal behavior the models omit.
- Spread-spectrum clock generation, jitter and edge-rate in hardware may differ from the wrapper's ideal triangle.
- EMC (radiated/conducted) is entirely outside the check set; a quiet 20 µV rail in sim can still fail system-level EMC.

Milestones (contingency, if measured runtime exceeds one run):
1. Regulation + efficiency + structure (R1, R4, R5, R6, R7) at nominal parts and nominal clock: grader checks band entry, efficiency, area/inductance and structural rules on `abk.cir`.
2. Aliased-noise design (R2, R3) at nominal and worst-case corners: grader runs the sampler/FFT sweep plus burst.
3. Robustness and numerics (R8 + held-out clock scales/phases): grader re-runs the full sweep at base and half timestep.
Each milestone keeps the same device and deliverable file; only the check set is staged.

What to change (reshape): Nothing substantive. Pin down the open details under "Numbers to supply next"; if runtime measurement shows the full sweep cannot be run inside the budget, stage the checks as the three milestones above rather than shrinking the requirements.

Evidence status: The payload is a draft with author-supplied text only; nothing has been executed and the filesystem has not been inspected. Supplied text establishes: stated requirements and limits (R1–R8), the contents of `parts.cir` and `ground_network.cir` as specified dependencies (existence/validity unverified), and the grader plan as proposed method. Author claims, unverified: the reference outline (a proposal, explicitly "no passing reference has been run yet"), the `distinct_valid_designs` list, the `public_designs` failure claims and `mechanism_survival` narrative, and the 1 uV FFT leakage allowance. My engineering inference: the linear-regulator 41% figure is consistent with 5/12 ≈ 42%; twelve tones (11 listed + 0.27 MHz) matches the stated twelve; 1/250 kS/s = 4 µs and 1/30 kHz ≈ 33.3 µs match the text. Verified evidence: none.

Checks before full-task readiness:
- Reproduce at least one claimed baseline failure (e.g. a single-stage buck exceeding R2 at a held-out clock scale) to confirm the wrapper and sampler discriminate as described.
- Produce and run at least one candidate netlist that meets R1–R8 at nominal and one corner, or revise the limits on evidence (without widening them merely to obtain a pass).
- Confirm the parts library parses and behaves as intended in the pinned ngspice (ternary in B-source, `8m`/`6n` suffixes, off-state resistance, tolerance parameter scaling).
- Specify and freeze the corner-scaling values, clock scales, sampling phases, burst timing, base/half timestep, and FFT/leakage procedure.
- Measure ngspice runtime and numerical noise for a representative transient and for the full sweep; decide single-run versus staged milestones on that measurement.
- Validate the R7 parser against benign and adversarial netlists (e.g. a design using `time` or a hidden independent source must be rejected).

Numbers to supply next:
- Requirement (missing spec): corner scaling for the tolerance parameters — e.g. kc ∈ {0.85, 1.0, 1.15}, kr same as kc, kl ∈ {0.9, 1.0, 1.1}, and whether all combinations or a fixed worst-case subset is swept.
- Requirement (missing spec): evaluation time steps and record — e.g. base run tstep 10 ns / maxstep 0.5 ns near edges, half-step run 5 ns / 0.25 ns, tstop 3 ms (1 ms settle + 2 ms measure), and how the convergence criterion R8 is computed from the two runs.
- Requirement (missing spec): sampling phases tested — e.g. offsets {0, 0.7, 1.6, 2.9, 3.6} µs within the 4 µs sample period, and whether "any phase" means worst case over the tested set.
- Requirement (missing spec): held-out clock scales — e.g. {0.972, 1.013, 1.028} × nominal, with 0.97 and 1.03 endpoints included in the declared sweep.
- Requirement (missing spec): burst definition — e.g. 150 mA peak sine at 1.013 MHz into a→dgnd, on for the whole measurement window, zero or fixed phase relative to the spread triangle start.
- Requirement (missing spec): FFT procedure — e.g. rectangular vs Hann window, mean removal, 2 ms record (500 Hz bins), and whether the 1 µV leakage allowance is applied to R2 and R3.
- Interface: inputs `/app/input_assets/parts.cir`, `/app/input_assets/ground_network.cir`, and the checker wrapper netlist; output exactly `/app/output/abk.cir` containing one `.subckt abk vin12 vout5 clk dgnd a b c` … `.ends`; schema: instances of SWX/INDQ/CAPX and resistors in the power path, behavioral B-sources and small R/C for control driving only switch control pins, `.param` allowed, no `time`, no other subcircuits, no independent sources in the power path.
- Handbook data: SWX ron ∈ [0.15, 2] Ω (given), INDQ Q = 30 at 1 MHz and CAPX ESR = 0.02/√(C in µF) Ω (given), ground segment 8 mΩ + 6 nH (given); supply the pinned ngspice version and confirm the parts netlist parses in it; supply clock generation details (triangle 0.9–1.1 MHz at 30 kHz, 3 ns edges, 0.3 ns rms jitter) as a waveform spec the wrapper implements.
- Verification still needed (not a spec): a demonstrated passing design, a demonstrated baseline failure, and measured runtime/noise numbers for the grader sweep and for R8.