We are adding a pluggable accessory module to a 12 V backplane and need the power-entry stage designed. The module hot-plugs onto a bus with a lightly damped cable, and its downstream converter acts as a constant-power load once enabled. The stage must behave the same whether it is plugged in cold, re-plugged with residual charge on the output, or released from a current limit.

Fixed interfaces: the stage is a SPICE subcircuit named ENTRY with ports in this order: VIN VOUT GND VAUX EN. VAUX is an auxiliary rail of 5 to 12 V (use 8 V nominal) and EN is a 0/5 V enable input, high = on. The pass device is the N-channel MOSFET subcircuit PASSFET (pins D G S) in /app/input_assets/models.lib; one or more instances may be used. The op-amp macro OPA_GBW and comparator macro CMP_IDEAL in the same file may be used. Other parts are discrete passives; any sense resistor is 10 to 50 mOhm. Output capacitance 220 uF (ESR 0.03 ohm) is added outside ENTRY at VOUT. Do not include it, the source or the load in your subcircuit.

Source: an ideal DC bus voltage VBUS of 10.8 to 13.2 V behind 0.15 ohm series, 1.2 uH cable inductance and a 100 uF bulk capacitor with 0.05 ohm ESR at the entry-stage side; cable inductance and bulk ESR each vary independently by +/-25 percent. VIN means the ENTRY port VIN node. Load: 18 W constant power, starting 5 ms after EN rises, dropping out below 8 V at VOUT.

Requirements, all with the module enabled at t=0 unless stated. In R3 to R5, the reference voltage is VBUS (the DC source value, not the ringing VIN node), and the time to reach 2 percent is the last instant after which VOUT stays within 2 percent of VBUS (for R5, of its pre-sag value).
R1. Peak current into VIN during cold plug (VOUT initially 0 V): <= 4.0 A, at every bus voltage and tolerance corner.
R2. Energy dissipated in the pass devices, sum over all PASSFET instances of the integral of Vds*Id, cold plug from 0 to 30 ms: <= 0.25 J.
R3. VOUT within 2 percent of VBUS from 12 ms after EN onward, for cold plug.
R4. Warm re-plug with VOUT precharged to any value between 0 and 11 V: same R1 and R3 limits, pass-device energy <= 0.25 J, and VOUT never exceeds VBUS by more than 0.3 V.
R5. Bus sag (VBUS drops by 3 V for 2 ms) applied after the load has started: VOUT is back within 2 percent of its pre-sag value within 5 ms after the sag ends and stays there until 30 ms after the sag ends. Latch-up is defined as VOUT failing this condition, or the load dropping out and not restarting, by 30 ms.
R6. With the load running at steady state, any bus voltage and tolerance corner: peak-to-peak oscillation of VOUT over 20 to 30 ms after EN (and, for the sag case, over 20 to 30 ms after the sag ends) <= 50 mV.
R7. Results must not change materially with simulation resolution: each metric above changes by <= 3 percent of its limit when the time resolution is made two and four times finer.

Deliver /app/output/entry.cir, a SPICE netlist containing the ENTRY subcircuit (it may .include the supplied model file by that path) and nothing else that drives the ports.
