### 16-hotplug-entry-stage-12v-cpl · Hot-plug 12 V power-entry stage — advance, rank 7

Design decision as written: yes — "we need the power-entry stage designed", with design freedom "parameter selection" and a topology left open ("any topology accepted" in G1).

Forge task: Design the topology and component values of a hot-plug power-entry circuit delivered as `.subckt ENTRY VIN VOUT GND VAUX EN` (PASSFET / OPA_GBW / CMP_IDEAL macros plus passives), such that the checker's wrapper deck meets inrush (≤4.0 A), pass-device energy (≤0.25 J), 12 ms settling to 2 % of VBUS, warm-plug overshoot (≤0.3 V), 5 ms sag recovery without latch-up, ≤50 mV ripple and ≤3 % metric drift under timestep refinement, at every bus/tolerance corner and precharge state.

Why it fits:
• It is a genuine physical design decision: topology (soft-start ramp, current limit, damping), compensation values, sense resistor value and device counts are the agent's to choose; the output is a netlist a headless simulator drives.
• ngspice can evaluate every requirement without a human: transient runs of the supplied wrapper give peak VIN current, per-PASSFET ∫Vds·Id, band-exit time, overshoot, settling and ripple; corner sweeps and timestep repeats are pure scripting.
• The difficulty is real engineering, not tedium: constant-power load negative incremental resistance (−V²/P ≈ −3.6 Ω at 8 V) against the 1.2 µH / 100 µF source resonance (~14 kHz, Z0 ≈ 0.11 Ω — my arithmetic agrees with the handbook), a gate pole from Cgs/Cgd with a dominant output pole, and compensation-node state that differs between cold plug, warm plug and limit release.
• R4/R5/R6 as specified do discriminate robust designs from designs tuned to one natural start state, which is the mechanism the author intends (author claim, not trial-verified).

What stops it:
• Structural objections: none. The device and the core decision (design the entry stage) are unchanged by any fix below.
• Unresolved feasibility risk 1 (my arithmetic on the supplied model text, not simulated): PASSFET is `LEVEL=1 ... KP=0.08` with `W=1 L=1`, so effective Kp·W/L = 0.08 A/V². That gives Rds(on) ≈ 1/(0.08·(10−2.5)) ≈ 1.7 Ω at Vgs = 10 V and ≈ 0.5 A saturation current at Vgs = 6 V, versus the handbook's "Rds(on) about 20 mOhm at 10 V" and "a few amps need roughly 4.5 to 6 V gate drive". A consistent device would need Kp·W/L ≈ 8 A/V² (e.g. W=100 L=1). With the macro literally as written, holding 18 W at 2 % of 12 V looks infeasible; model and handbook must be reconciled before the task is runnable.
• Unresolved feasibility risk 2: VAUX is a ground-referenced 5–12 V rail while the pass device is a high-side NMOS whose source sits at VOUT ≈ 12 V, so Vgs = VAUX − VOUT ≤ 0 in steady state. The reference outline ("gate ramp is a current-source charged capacitor from VAUX") inherits this. Gate drive above VOUT (bootstrap/charge pump built only from allowed passives) must be explicitly permitted, or the device/placement changed — otherwise no design can pass.
• Unresolved feasibility risk 3: the grader sweep is large (27 corners × ~4 scenarios × 3 timesteps ≈ 300 transients, before held-out precharge draws and offsets). No runtime has been measured; behavioural sources (tanh comparator, clamped CPL) may also force small steps or fail convergence at abrupt events.
• Author claims not corroborated: the public-design failure narratives (RC soft start breaking R1/R2/R4, plain op-amp limiter breaking R6, timer hot-swap controller breaking R5/R4) and the mechanism_survival story are hypotheses in the draft; no run artifacts are supplied.

How to check it:
• ngspice: wrap `/app/output/entry.cir` in the specified source (VBUS, 0.15 Ω, 1.2 µH, 100 µF/0.05 Ω), 220 µF/0.03 Ω output cap and the constant-power load; run cold plug, warm plug (IC on VOUT at 0–11 V), and 3 V/2 ms sag transients at all L/ESR/bus corners.
• ngspice + post-processing: peak VIN current and VOUT band-exit time from saved node voltages/branch currents; ∫Vds·Id per PASSFET instance by hierarchical device saves or behavioural power sources; cross-check energy against input-minus-output-cap-minus-load balance (grader plan's 10 % agreement rule).
• ngspice: repeat each case at max step 1 / 0.5 / 0.25 µs and diff every metric for R7.
• Scripted sweep driver (Python) enumerating the corner grid and held-out draws, with per-case pass/fail JSON for the grader.

Simulation gaps:
• LEVEL=1 MOSFET has no temperature, self-heating, SOA or package inductance; level-1 short-channel behaviour is not a real hot-swap FET.
• The CPL clamp near VOUT ≈ 1 V and the 8 V dropout with 0.5 V hysteresis are behavioural conventions; small changes in their implementation can shift sag-recovery and latch-up outcomes.
• CMP_IDEAL's tanh is smooth but steep (200 V⁻¹); interaction with adaptive stepping is a known source of metric noise — R7 exists because of this, and its own noise floor must be measured.
• Energy integration accuracy depends on saved-point density; the checker must integrate from the simulated waveform, not from a coarse export.
• Nothing in simulation checks PCB layout, thermal design, EMI, connector contact physics, or passive tolerance drift beyond the declared corners.

Why frontier models fail (hypothesis unless trials run):
• The competing loops (gate ramp, current limit, load-enable guard, damping RC) interact; a design can pass cold start at nominal while the compensation node left charged by a warm plug or a limit release re-enters with a different state.
• The constant-power load's negative incremental resistance moves the effective damping and can push the ~14 kHz resonance toward crossover; ripple ≤50 mV at every corner requires damping and loop shaping to be solved together, not sequentially.
• Robustness over L/ESR ±25 %, three bus voltages and arbitrary precharge values is a multidimensional tuning problem where one-at-a-time sweeps lie; plus the R7 convergence requirement punishes designs that only work at one timestep.

Real-world risks:
• A netlist that passes still needs a real pass device with adequate SOA/thermal margin for the ≤0.25 J events and 2.25 A steady state; not checked here.
• Gate-drive headroom and any bootstrap network must exist in hardware (charge-pump/level-shifter reality), and sense-resistor Kelvin layout matters at 10–50 mΩ where a 1 mV op-amp offset is comparable to the sense signal (handbook point, arithmetically consistent: 4 A × 50 mΩ = 0.2 V, 4 A × 10 mΩ = 40 mV).
• Model fidelity gap: a passing design may still ring on a real cable with different parasitics than 1.2 µH / 0.15 Ω / 100 µF.

Milestones (only if the sweep runtime forces a split): 1. Cold-plug entry (R1–R3): netlist plus wrapper; grader checks peak current, energy and settling at corners. 2. Warm plug + sag (R4–R5): same netlist, IC-on-VOUT and sag wrapper; grader checks overshoot, settling, latch-up. 3. Robustness (R6–R7): ripple windows and timestep refinement on the same netlist. Each is standalone with its own wrapper deck and reference netlist; the deliverable file is identical across milestones.

What to change (reshape): • Nothing structural. Keep the device, the ENTRY interface and all seven requirements; only supply the model/interface numbers listed below and reconcile the PASSFET drive strength.

Numbers to supply next:
• Missing spec — PASSFET drive strength: effective Kp·W/L consistent with the handbook, e.g. `W=100 L=1` (≈8 A/V²) so Rds(on) ≈ 20 mΩ at Vgs = 10 V; supply the corrected `models.lib` text and its path.
• Missing spec — gate-drive headroom: maximum Vgs and maximum gate-node voltage relative to VOUT/GND, and whether a bootstrap/charge-pump network built from permitted passives is allowed — e.g. "gate node up to 24 V abs max, Vgs ≤ 20 V, bootstrap from VIN via diode + capacitor permitted".
• Missing spec — permitted parts: whether diodes and inductors count as "discrete passives", and instance budget — e.g. "R, C, small-signal D and one ≤100 µH L allowed; ≤6 PASSFET, ≤2 OPA_GBW, ≤2 CMP_IDEAL".
• Missing spec — VAUX budget: e.g. "5–12 V (8 V nominal), stage may draw ≤20 mA continuous from VAUX".
• Missing spec — passive tolerances for the agent's own parts: e.g. "resistors 1 %, capacitors ±10 % with ESR ≤0.05 Ω, sense resistor 1 % in 10–50 mΩ".
• Missing spec — timing: EN rise time (e.g. 100 ns), exact sag application time(s) (e.g. at t = 20 ms after EN and a second case at t = 6 ms), total simulated time (e.g. 60 ms), and that the load enables 5 ms after EN (already stated).
• Missing spec — exact load law: behavioural expression for I = P/VOUT with clamp below ~1 V, 8 V dropout and 0.5 V restart hysteresis — e.g. "I = limit(18/V(VOUT), 0, 5 A) for V > 1 V, else 18 A·V" plus the switching rule.
• Missing spec — output schema: exact first line `.subckt ENTRY VIN VOUT GND VAUX EN`, allowed statements inside (`.include /app/input_assets/models.lib`, local models/subcircuits allowed; no independent sources, no `.tran`/`.ic` in the deliverable), one example skeleton file.
• Missing spec — numerics: reference max timestep for R7 (1 µs per G4), solver options and IC convention (VOUT initial condition set by the wrapper deck).
• Interface: input `/app/input_assets/models.lib` (verify the file exists; its embedded text is supplied content, not proof of the file), output `/app/output/entry.cir`; plus the exact wrapper deck the checker will use, so the agent can reproduce every metric locally.
• Handbook data: absolute-max ratings for a real part standing in for PASSFET (e.g. Vds 40 V per DBODY BV, Id 10 A continuous, SOA pulse curve) and ESR/tolerance table for 220 µF output and 100 µF bulk caps.
• Verification still needed (not spec): sanity deck driving PASSFET at fixed Vgs = 10 V to measure Rds(on) against the handbook number after the model fix; a minimal reference netlist actually passing R1–R6 at nominal (the author states thresholds are provisional); measured runtime for the full corner × timestep sweep; reproduction of one claimed public-design failure (e.g. plain op-amp limiter breaking R6) to confirm the mechanism; a noise-floor run showing a fixed design's metrics move <3 % of limit across the three timesteps.

Evidence status: Draft-only input. The `models.lib` content is supplied text (it establishes the quoted macro definitions, not that the file exists at the path, nor physical fidelity); the reference outline is a proposed solution, not a passing design; `grader_plan`, public_design failure claims, mechanism_survival claims, distinct_valid_designs and all tolerances are author claims; no simulation artifacts, runtimes or validation results were supplied or inspected. Verified by my own check of the supplied text only: arithmetic consistency of the handbook numbers (16 mJ stored in 220 µF at 12 V; 18 W/8 V = 2.25 A; −V²/P ≈ −3.56 Ω; √(L/C) ≈ 0.11 Ω; 1/(2π√(LC)) ≈ 14.5 kHz; OPA_GBW pole 20 Hz from 1 kΩ × 7.96 µF) and the two drive-strength/headroom inconsistencies above. The 2 % settling, energy, ripple and robustness outcomes remain unverified.

Checks before full-task readiness: (1) reconcile PASSFET model parameters with the handbook's Rds(on)/gate-drive claims and re-measure Rds(on) and saturation current in ngspice; (2) demonstrate a legal gate-drive arrangement that keeps the pass device enhanced with source at VOUT ≈ 12 V under the stated VAUX range, or amend the interface; (3) produce one reference netlist passing R1–R6 at nominal before freezing limits; (4) measure per-transient runtime and total sweep time, and stage the grader (nominal + subset first, held-out corners second) if needed; (5) confirm hierarchical PASSFET instance enumeration works in ngspice for the wrapper's energy sum; (6) reproduce one claimed public-design failure to validate the catching_rows mechanism.