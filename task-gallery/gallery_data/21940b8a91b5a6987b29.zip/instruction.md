We are adding a precision sensor front end behind a 12 V to 3.3 V point-of-load buck stage. Slow drift of the ripple envelope against the clock would alias into the sensor band, so we need a bound on the output residual. The power stage and loop architecture are fixed by the board; only the passive and compensator values are yours.

Fixed: synchronous buck, one inductor, one output capacitor bank, a three-pole/two-zero voltage-mode compensator, fixed-amplitude PWM ramp, fs = 500 kHz. Vin 9 to 15 V, Vout 3.3 V, load 0.2 to 2.0 A. Fixed parts (MOSFET Rds(on), dead time, ramp amplitude, divider, reference, allowed Isat list, inductor DCR) are in /app/input_assets/fixed_params.json. Inductor: L(i) = L0/(1+(i/Isat)^2), L0 0.47 to 4.7 uH, Isat from the allowed list, with Isat tolerance corners -30% and +10%. Total output capacitance at most 100 uF nominal.

Corner set, applied to every requirement below: ESR = 5 mOhm and 15 mOhm (each applied to every capacitor in the bank, replacing the ESR you chose), crossed with capacitance at 1.0x and 0.6x of the nominal value (-40% DC-bias derating), crossed with Isat at -30% and +10% of your chosen value.

Metric (residual): take the output voltage over a 200-cycle (400 us) window, least-squares fit it on exactly the basis {1, cos(2 pi fs t), sin(2 pi fs t)}, no other term, and take the RMS of what remains, in mV.

Requirements, at every corner above:
1. Steady state at Vin 9, 12, 15 V and load 0.2, 1.0, 2.0 A, window 2.0 to 2.4 ms after startup: residual RMS <= 4.0 mV.
2. Load step 0.2 A to 2.0 A at 10 A/us, Vin 12 V, from steady state: from the start of the load edge until 700 us after it, the output stays within +/-3% of 3.3 V; and residual RMS <= 4.0 mV over the 200 cycles from 300 to 700 us after the edge.
3. Light-load boundary, load 0.2 to 0.5 A at any Vin in range, whatever conduction mode results: residual RMS <= 4.0 mV (same window as 1).
4. Saturation: Isat at -30%, Vin 15 V, load 2.0 A, with ESR and capacitance corners: residual RMS <= 4.0 mV.
5. Intermediate Vin and load points inside the stated ranges must also meet requirement 1.
6. Component values must respect the bounds above, and the fixed parts and fs in the netlist must match the input file.

Netlist interface: the input source is a voltage source named Vin and the load is a current source named Iload (both to be replaced or re-valued by us), the output node is named vout, and the capacitor bank is elements named Cbank1, Cbank2, ... each with a series resistor named Rbank1, ... Inductor value and Isat are .param entries L0 and Isat.

Deliver in /app/output/: converter.cir, a SPICE netlist of the complete converter and compensator with the fixed parts as given; and design.json with fields L0_uH, Isat_A, cap_bank (list of {C_uF, ESR_mOhm}), and compensator values (resistors in ohm, capacitors in F, named as in the netlist).
