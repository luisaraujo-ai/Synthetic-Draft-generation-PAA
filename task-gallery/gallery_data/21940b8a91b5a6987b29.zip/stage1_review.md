### 21-buck-pol-ripple-residual-saturating-inductor · POL buck with bounded residual under saturation corners — advance, rank 8

Design decision as written: yes — "The power stage and loop architecture are fixed by the board; only the passive and compensator values are yours."

Forge task: Select L0 (0.47-4.7 uH), an allowed Isat, a capacitor bank (<= 100 uF nominal) and type-III compensator values for a 12 V->3.3 V, 500 kHz synchronous buck, delivering converter.cir and design.json, such that the residual RMS of vout (offset plus one fs sinusoid removed) stays <= 4.0 mV and the load-step excursion stays within +/-3% at every ESR(5/15 mOhm) x C(1.0x/0.6x) x Isat(-30%/+10%) corner.

Why it fits:
• The deliverable is a set of physical component values plus a working netlist, not an analysis or a report; the agent must make a trade-off (inductance vs saturation vs capacitance vs loop shape) and stand behind it.
• The metric is exactly specified: uniform sampling, 200-cycle windows, fixed basis {1, cos, sin} at fs, RMS of the remainder — fully scriptable in Python after an ngspice run.
• Corner set, netlist interface (Vin, Iload, vout, Cbank*/Rbank*, .param L0/Isat) and output schema (design.json fields) are given, so the grader can override corners deterministically.
• Real engineering coupling: at Vin 15 V, 2 A the ripple current is large relative to the -30% Isat corner, so L falls, the LC resonance moves, and the loop margin and residual move with it — this is the kind of coupled trade frontier models get wrong without iteration.

What stops it:
• Structural objection: none. Fixing the power stage and compensator architecture is a stated constraint, not an uncheckable step.
• Unresolved feasibility risk (not a missing number): the 4.0 mV residual threshold is described by the author as provisional until a reference design is simulated; with ~3-3.5 A ripple at 15 V and 15 mOhm ESR the non-fundamental ripple content is on the order of a few mV, so the margin may be thin or absent. Author's reference_outline is a proposed solution, not a passing design.
• Unresolved feasibility risk: a behavioural current-dependent inductor L(i)=L0/(1+(i/Isat)^2) plus ideal-ish synchronous switches and dead time can be slow or non-convergent in ngspice at 500 kHz over 2.4 ms windows; no measured runtime is supplied.
• Unresolved feasibility risk: the author's claim that a solver's own residual proxy can mask subharmonic envelopes is unverified; the fixed-basis grader metric itself is well defined, but the marginal-design failure modes it is meant to catch have not been demonstrated in simulation.

How to check it:
• ngspice (.tran, timestep small enough for 40+ points per 2 us cycle): produce vout at each Vin x load x corner; verify switching frequency, output level and the step response shape.
• Python/numpy: uniform resampling, least-squares fit on exactly {1, cos(2 pi fs t), sin(2 pi fs t)}, RMS of residual in the stated windows (2.0-2.4 ms; 300-700 us post-step).
• Static parse (Python) of converter.cir and design.json: L0 range, Isat list membership, total nominal C <= 100 uF, fs = 500 kHz, fixed Rds(on)/dead time/ramp/divider values, presence of Vin/Iload/vout/Cbank*/Rbank*/.param L0/Isat, and consistency between design.json and the netlist.
• Checkable in principle; not implemented or validated here. Unverified: solver convergence rate, behavioural-inductor accuracy vs a flux-based model, timestep sensitivity of the residual RMS at the 2% tolerance level, and runtime of the full corner sweep.

Simulation gaps:
• No thermal, core loss, capacitor aging/leakage, MOSFET switching loss or board-layout parasitics; ESR is a fixed resistor per capacitor and the ESR zero's interaction with ESL/decoupling is not modelled.
• DCM/reverse-current behaviour of the synchronous stage depends on how the agent implements the switches; a simplified model may under- or over-state light-load residual (R3).
• Startup and soft-start detail is only loosely defined ("time zero is when Vin is applied or the soft-start begins"); window 2.0-2.4 ms must have reached steady state in every corner, which is not demonstrated.

Why frontier models fail:
• The residual metric punishes exactly the behaviour models tend to wave away: slow beat/subharmonic envelopes near saturation and light load that a hand calculation or a single nominal simulation misses.
• Eight corners must hold simultaneously while the step requirement penalises over-damping and R4 penalises under-sized inductors — a genuine multi-constraint trade that only a real simulation loop resolves. (Predicted failure is a hypothesis; supporting trials are not supplied.)

Real-world risks:
• Inductor peak current at 15 V/2 A with -30% Isat sits close to the allowed list's lower options; saturation and DCR heating in the built unit may exceed the behavioural model.
• The chosen capacitance assumes a -40% DC-bias derating multiplier; real MLCC derating depends on part number, voltage rating and aging.
• Residual measured on an ideal netlist can be smaller than on hardware with switching-node coupling and ESL.

Milestones (if too big): not required; the task plausibly fits one run once runtime is measured. If it does not, split: 1. power-stage netlist + L(i) law: grader checks topology, fixed parts, fs and converter open-loop operation. 2. Compensator + corners: grader checks R1/R3/R4/R5 residuals. 3. Load-step: grader checks R2 excursion and residual.

What to change (reshape): nothing structural. Pin down, in the numbers below: threshold calibration against a reference simulation, the exact ESR-override rule, inductor-current definition in the L(i) law, and transient settings that make the residual reproducible within the stated 2% tolerance.

Numbers to supply next:
• Requirement: residual RMS threshold at each corner class — e.g. 4.0 mV, to be confirmed by simulating at least one reference design (e.g. L0 1.5 uH, 6 A Isat, 70 uF) and reporting its worst-corner residual; if the reference fails, recalibrate before release rather than widening the limit silently.
• Requirement: load-step edge definition and step source — e.g. current ramp 0.2 -> 2.0 A at 10 A/us with edge time t_edge specified as an absolute time in the netlist (e.g. 2.0 ms).
• Requirement: steady-state convergence criterion before the 2.0-2.4 ms window — e.g. |dvout/dt| < 1 mV over 100 us prior.
• Interface: /app/input_assets/fixed_params.json as supplied (values confirmed, units Hz/V/A/mOhm/ns/uH/uF); /app/output/converter.cir (ASCII SPICE, ngspice-compatible, .tran directive supplied by grader) and /app/output/design.json with keys L0_uH (float), Isat_A (float from [2.5,3.5,4.5,6.0]), cap_bank (list of {C_uF, ESR_mOhm}), compensator (map of element name -> value).
• Interface: grader override convention — e.g. RbankN .param values replaced by 5 or 15 mOhm, CbankN scaled by 1.0 or 0.6, .param Isat scaled by 0.7 or 1.1; state that design.json must agree with converter.cir element values exactly.
• Handbook data: inductor law convention — e.g. L(i) = L0/(1+(i/Isat)^2) evaluated on instantaneous inductor current, implemented flux-based or behaviourally as the agent chooses, with a required self-test (measured effective L within 5% of the law at 0.5x, 1x, 2x Isat); plus inductor DCR 8 mOhm, capacitor DC-bias multiplier 0.6, dead time 10 ns, ramp 1.2 V, vref 0.8 V as in fixed_params.json.
• Verification still needed (not specifications): measure full-sweep runtime and residual RMS noise vs timestep; reproduce at least one of the author's claimed public-design failures (e.g. the datasheet 1 uH/47 uF design failing R4) to confirm the metric discriminates; confirm the behavioural inductor matches a flux-based implementation.

Evidence status: Draft-only input. fixed_params.json content is supplied text (stated specification, not inspected on disk). The reference outline, budget-fit claims, public-design failure claims, and the mechanism_survival masking claim are unverified author claims; no simulation output, passing design, or runtime measurement is supplied or inspected. Checkable in principle per tools named above; implemented and validated coverage is zero at this stage.

Checks before full-task readiness: (1) simulate a reference design across the full corner set and record worst-corner residual to calibrate 4.0 mV; (2) reproduce one claimed public-design failure to show the metric discriminates; (3) demonstrate ngspice convergence and measure runtime for one full sweep (150+ transient runs at 2.4 ms) plus timestep-sensitivity of the residual at the 2% tolerance; (4) confirm the behavioural L(i) implementation agrees with the stated law; (5) freeze the ESR/C/Isat override convention and design.json schema.