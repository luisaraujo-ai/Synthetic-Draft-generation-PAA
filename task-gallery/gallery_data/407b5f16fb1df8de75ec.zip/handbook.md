Handbook (reference data and conventions)

Crystal. Series Rm-Lm-Cm branch in parallel with C0. Series resonance fs = 1/(2 pi sqrt(Lm Cm)), about 10.000 MHz here. Motional Q = 2 pi fs Lm / Rm is about 12,600 for the unloaded part. Parallel resonance sits above fs by about fs*Cm/(2 C0) (roughly 0.35 percent). A load capacitance CL in series with the crystal pulls frequency by about Cm/(2 (C0+CL)^2) per farad, of the order of 20 ppm per pF for CL near 20 pF. Series resistance in the crystal branch lowers loaded Q to 2 pi fs Lm / (Rm+Rext).

Envelope dynamics. The amplitude envelope follows a first-order law with time constant about 2 Lm / (Rm + Rext + Rneg), where Rneg is the negative resistance presented by the active circuit (Rneg is negative in sign for gain, so the denominator shrinks as gain rises). Near-unity loop gain and high loaded Q make this time constant long (hundreds of microseconds). Large excess gain shortens start-up but raises crystal current and distortion. Limiter recovery also slows as loop gain approaches unity.

Injection locking (Adler). Lock range as a fraction of frequency is roughly (1/(2 Q_L)) * (I_inj / I_osc), with Q_L the loaded Q and I_inj / I_osc the injected-to-oscillating current ratio at the injection point. Lock-in time constant scales as the inverse of the lock range. Phase offset in lock is asin(detuning/lock range), so detuning near the lock-range edge makes phase sensitive to disturbances. Strong injection also pulls amplitude and frequency.

Drive level. P = Irms^2 * Rm with Irms the current in the motional branch (through Lm). Small AT-cut crystals are typically rated 10 to 200 microwatts.

Measurement definitions.
- Envelope: peak amplitude per cycle of the out-node fundamental.
- RMS amplitude: over whole cycles in the stated window.
- Frequency: from interpolated zero crossings over the 100-cycle window.
- Phase against the reference: per-cycle phase of the out-node fundamental minus reference phase, unwrapped; detrending removes a least-squares straight line over the window.
- Supply current: time-average current delivered by the 3.0 V source over whole cycles in the settled window.
- Settled state: any state after the settling time defined in the brief.
- Timestep change: the same case simulated at the base step and at half that step.

Test conditions. Supply application is a 1 microsecond ramp from zero with all node voltages and inductor currents starting at zero. A 10 microamp, 10 ns current pulse is applied across xa-xb at the start for numerical seeding. The reference is off for free-run tests and on from time zero in locked tests. The supply dropout takes the supply source to 0 V for 2 microseconds with 0.1 microsecond edges. Reference offsets are sampled anywhere inside the declared band, including between band edges. Corners are combinations of the multipliers in crystal.json. Time integration uses tight tolerances.

Practical ranges. Saturating tanh transconductors self-limit amplitude near Isat times the load impedance. Supply current is dominated by active-source current. A 3 V supply with 1 ohm source has negligible droop at 1 mA.
