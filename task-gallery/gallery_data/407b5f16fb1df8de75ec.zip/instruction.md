I'm the product lead on a metering node and I need a 10 MHz timing block built around a fixed small AT-cut crystal. It must start fast, stay settled, and follow an external 10 MHz disciplining tone that wanders by tens of ppm. Power is scarce, but a block that settles late or slips lock corrupts field timestamps.

Fixed inputs:
- Supply: 3.0 V DC through 1 ohm source resistance.
- Crystal: parameters and corner multipliers are in /app/input_assets/crystal.json. It connects between pins xa and xb.
- Load on pin out: 10 kohm in parallel with 5 pF to ground.
- Reference tone on pin ref: 150 mV peak sinusoid through 1 kohm source resistance, frequency 10 MHz plus or minus 20 ppm.
- Allowed parts and parameter ranges: /app/input_assets/allowed_devices.json. Nothing else may be used.

Topology, gain, loading, injection point and strength, bias and start-up arrangement are yours to choose.

Deliverable: /app/output/osc.cir, a SPICE netlist containing one subcircuit named osc with ports in the order vdd gnd xa xb out ref.

Every requirement must hold at all crystal corners: Rm x0.75 to x1.25, C0 x0.9 to x1.1, series resonance -8 to +8 ppm. Every simulated case is observed from supply application (t=0) to t = 1.5 ms.

Definitions: a window is 50 consecutive cycles; the window envelope change is (max-min)/mean of the per-cycle peak amplitude in it. Settling time is the earliest time t_s such that every 50-cycle window starting at or after t_s, up to 1.5 ms, has envelope change under 1 percent.

Requirements:
1. Cold start from zero stored energy, reference off: settling time at most 400 microseconds after supply application.
2. Free-run, nominal crystal, after settling: amplitude of consecutive 100-cycle windows differs by at most 0.5 percent and frequency by at most 5 ppm.
3. Output RMS amplitude at out is 0.8 to 1.4 V in every settled state, free-run or locked.
4. Crystal drive power (motional-branch RMS current squared times that corner's Rm) is at most 100 microwatts in every settled state.
5. Average supply current is at most 1.2 mA in every settled state.
6. Locked state, reference anywhere in 10 MHz plus or minus 20 ppm, supply and reference applied together: over the 2000 cycles starting 600 microseconds after application, the output phase against the reference has no cycle slip (unwrapped excursion under 180 degrees) and, after linear detrending, peak-to-peak phase spread of at most 3 degrees.
7. After a 2 microsecond total supply dropout from a settled locked state, with observation running 1.5 ms from the supply returning: settling time (as defined, measured from the supply returning) is at most 600 microseconds, and requirement 6 holds over the 2000 cycles starting 600 microseconds after the supply returns.
8. Numerical resolution independence: halving the base time resolution moves the requirement 1 settling time by at most 20 microseconds and the requirement 6 phase spread by at most 1 degree.
9. The netlist uses only allowed parts, within their ranges and placement rules.
