### 10-10mhz-crystal-clock-block-settled-and-locked · Crystal clock block that settles and locks across corners — advance, rank 8

Design decision as written: yes — "Topology, gain, loading, injection point and strength, bias and start-up arrangement are yours to choose"; deliverable is a SPICE subcircuit netlist.

Forge task: Design a <=40-element SPICE subcircuit (R, C, L, linear VCCS, tanh current source, up to 4 D1 diodes; only vdd as current-sourcing terminal) implementing a 10 MHz crystal-referenced oscillator that settles within 400 us cold, delivers 0.8-1.4 V RMS into 10 kohm || 5 pF, keeps motional drive <=100 uW and supply current <=1.2 mA, locks to a 150 mV-pk 10 MHz +/-20 ppm reference with no cycle slip and <=3 deg detrended phase spread, at all corners (Rm x0.75-1.25, C0 x0.9-1.1, fs +/-8 ppm), and recovers within 600 us after a 2 us supply dropout.

Why it fits:
- The deliverable is a design artifact (chosen topology and component values), not analysis; the checker builds its own bench and runs headless ngspice transients plus a Python static parse (element types, ranges, count, port order, placement rule).
- Genuine coupled trade-off: excess loop gain shortens the envelope time constant but raises crystal drive and supply current; injection strength buys Adler lock range but pulls amplitude and frequency; robustness across corners, held-out reference offsets and a halved timestep forces deliberate margin rather than a knife-edge nominal tuning.
- Bounded design space: <=40 ideal elements from a closed allowed list, fixed crystal model, explicit numeric limits.

What stops it:
- Structural: nothing. As written it is a design decision, doable in principle and script-checkable.
- Unresolved feasibility risk: no passing design has been demonstrated. The reference outline is a proposed solution and the author states "thresholds are provisional until a reference passes"; whether R1 (<=400 us settling), R4 (<=100 uW at Rm x0.75) and R6 (<=3 deg at +/-20 ppm detuning) are simultaneously satisfiable at 1.2 mA is an author claim, not verified evidence.
- Unresolved runtime risk: 1.5 ms at 10 MHz is ~15,000 cycles per transient; 27 corner combinations plus undisclosed reference offsets, cold-start/locked/dropout cases and half-step reruns could exceed both the agent budget and the grader budget. Unmeasured.
- Spec ambiguity (not a missing number per se): the phase metric "per-cycle phase of the out-node fundamental minus reference phase" needs a pinned extraction formula and window alignment, since R6/R8 margins are ~1-3 degrees.

How to check it:
- ngspice (headless transient): checker-built bench (3.0 V + 1 ohm, Rm-Lm-Cm || C0 with corner multipliers from crystal.json, 10 kohm || 5 pF load, 150 mV-pk 10 MHz +/-20 ppm sine through 1 kohm, 10 uA/10 ns seeding pulse, 2 us dropout with 0.1 us edges); numpy computes 50-cycle envelope settling, waveform RMS over whole cycles, Irms^2*Rm in the motional branch, mean supply current, interpolated zero-crossing frequency, unwrapped fundamental phase and detrended peak-to-peak.
- Python static parse of osc.cir against allowed_devices.json: element set, parameter ranges, <=40 elements, .subckt osc vdd gnd xa xb out ref, G/B first node at vdd, forbidden directives absent.

Simulation gaps:
- Ideal elements: no parasitics, no PCB/package capacitance, no transconductor output conductance or headroom limits beyond the tanh form, no noise sources (phase jitter, AM noise, reference amplitude noise), no temperature drift.
- Crystal model is fixed and linear; drive-level dependence of Rm, activity dips, and shunt-path nonlinearity are not modeled, so passing drive-power limits in simulation does not guarantee safe drive in hardware.
- Numerical: R8 probes only two step sizes; convergence of tanh B-sources and diodes at startup, and the sensitivity of the settling-window definition to integration method, remain uncertain.
- Robustness to held-out reference offsets near band edges and to the undisclosed dropout instant depends on the checker's sampling; corner coverage in the agent's own loop is likely sparser than the grader's.

Why frontier models fail: hypothesis, not demonstrated. The plausible difficulty is real engineering coupling — envelope time constant, drive level, injection lock range, amplitude and supply current move in opposite directions, and corner/wander/timestep variation punishes a nominal-point optimum. Predicted failures of the named public topologies (Pierce settling ~1 ms, Colpitts drive >100 uW, near-unity-gain loops slipping at band edges) are author claims pending reproduction.

Real-world risks:
- A tanh transconductor and ideal D1 diodes are abstractions; real 3 V implementations face headroom, output swing and loading not represented here.
- Passing the checks establishes simulated functionality at declared corners only; jitter/phase noise, temperature, aging, supply ripple and layout parasitics are unassessed.
- The measurement conventions (fundamental projection, zero-crossing interpolation) can move R6/R8 results by a non-trivial fraction of their margins.

Milestones (if split is desired; not required):
1. Free-run oscillator meeting R1-R5 at all corners: grader checks settling, RMS, drive power, supply current.
2. Injection-locked variant meeting R6 at held-out offsets: grader checks slip count and detrended phase spread.
3. Dropout recovery and step-independence meeting R7-R8: grader checks re-settling and half-step deltas.

What to change (reshape): nothing. The brief already fixes one process/medium (SPICE netlist), one deliverable and one bench; pinning the phase-extraction formula and the numerical settings belongs in "Numbers to supply next".

Evidence status: draft-only input. Requirements text, crystal.json and allowed_devices.json contents are supplied text; I have not inspected /app/input_assets or run any simulation. The reference outline, distinct_valid_designs list, public-design failure claims, mechanism-survival narrative and the "thresholds are provisional" note are author claims. Named asset paths are specified dependencies, not verified assets. Feasibility of the joint limits and all runtimes are unverified.

Checks before full-task readiness:
- Produce and run at least one reference netlist through the full grader set (cold start, free-run, locked at held-out offsets, dropout, half-step reruns) and record pass margins; or reproduce the claimed baseline failures to confirm the tests discriminate.
- Measure ngspice runtime for a 1.5 ms transient at the intended tolerance and total sweep cost across 27 corners x offsets x cases x 2 steps; trim the sweep if it does not fit.
- Pin the phase-extraction formula, window alignment and zero-crossing interpolation so R6/R8 are reproducible across implementations; state the trap/gear choice and maxstep.
- Confirm ngspice accepts the specified tanh B-source form and .model D1 exactly as the static parser expects, and that seeding pulse and dropout are applied deterministically.
- Verify /app/input_assets/crystal.json and /app/input_assets/allowed_devices.json exist and load.

Numbers to supply next:
- Requirement (spec): base time resolution and tolerance set — e.g. maxstep 0.5 ns, reltol 1e-6, trap integration; halved step = 0.25 ns.
- Requirement (spec): exact phase metric — e.g. least-squares projection of out onto cos/sin at the reference frequency over each 100-cycle window, phase = atan2 of coefficients, unwrapped across windows.
- Requirement (spec): dropout instant range and reference phase at t=0 — e.g. dropout between 1.0 and 1.2 ms after application; ref phase 0 at t=0; reference offset sampling list policy (e.g. 5 fixed held-out offsets drawn by seed).
- Requirement (spec): grading runtime budget and case count — e.g. <=30 min CPU per netlist, 27 corners x 5 offsets max.
- Interface (specified, assets unverified): inputs /app/input_assets/crystal.json and /app/input_assets/allowed_devices.json (contents supplied); output /app/output/osc.cir (schema supplied); still needed: the checker bench netlist template and the exact numpy measurement functions used for R1-R8.
- Handbook data (spec): crystal drive rating used for R4 justification — e.g. 10-200 uW typical for small AT-cut; transconductor Isat and Vs usable ranges already given in allowed_devices.json.
- Verification still needed (not spec): a demonstrated passing design, reproduced failure of at least one listed public topology, and measured simulation runtimes/noise at the two timesteps.