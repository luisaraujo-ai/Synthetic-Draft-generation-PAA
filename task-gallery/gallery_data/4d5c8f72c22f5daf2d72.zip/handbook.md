# Handbook

## Fixed data
Models (models.lib, level-1 square-law): NMOS vto 0.45 V, kp 220 uA/V^2, lambda 0.08/V. PMOS vto -0.45 V, kp 80 uA/V^2, lambda 0.10/V. tox 4 nm (Cox about 8.6 fF/um^2), overlap caps 0.3 fF/um. Minimum L is 0.18 um. Gate area and device sizes are free. Temperature is 27 C; ignore temperature effects.

trimact (trim_actuator.cir): ports `cin vtrim`. It is a unity-gain buffer followed by two cascaded RC low-passes with time constants 8 us and 16 us, and models the trim DAC and reconstruction filter. The output must not be loaded other than by a controlled-source control input. Series insertion into the input path is commonly done with a voltage-controlled voltage source whose controlling voltage is v(vtrim).

## Offset mismatch
Pelgrom: sigma(deltaVT) = sqrt(2) * A_VT / sqrt(W*L) for a matched pair, with A_VT = 4 mV*um and W, L in um. Offset is injected as a DC source in series with inp, outside the cell, after the 250 kOhm. Draws are uniform to +/-3 sigma, which means larger gate area lowers the offset the trim must remove. Gate capacitance forms a pole with the 250 kOhm input resistance, so large area costs gm flatness at 200 kHz.

## Practice and ranges
A square-law differential pair has gm = Itail/Vov with Vov per device. Its third-order distortion for a sine of amplitude A scales as HD3 ~ (A*gm/Itail)^2/16 and improves with degeneration only if the gm target is held. Source degeneration trades gm and linearity against headroom. Typical trim loops use an integrator, optionally with a proportional path, and a series sense filter, giving crossover in the 2 to 20 kHz range with phase margin 30 to 75 degrees. The sensitivity peaking of a loop with phase margin PM is roughly 1/(2*sin(PM/2)). Current can be sensed with a 0 V source in series with a drain. Behavioural integrators can be built from a VCCS or CCCS into a capacitor.

## Measurement definitions
- Iout = I(into outp) - I(into outn), measured on the source holding each output at 1.0 V.
- Cycle-averaged input-referred offset e(t): the mean of Iout over the trailing one input period, divided by the measured fundamental gm at that frequency.
- gm: fundamental Fourier amplitude of Iout in a coherent, integer-cycle window starting at least 1.5 ms after power-up, divided by the input amplitude.
- Residual offset: mean of Iout in the same window divided by gm.
- Power-up settling: time after the supply reaches 90 % of its final value until |e| stays <= 150 uV for the rest of a 1.5 ms record. Supply ramp times of 2 to 20 us are used.
- Step settling: step applied at 1 ms; final value is the mean of e over 1.8 to 2.0 ms; settling time is the last instant |e - final| exceeds 1 % of |step|. Overshoot is the peak excess of e beyond the final value in the direction of travel, divided by |step|.
- HD3: amplitude of the third harmonic over the fundamental, in dBc, in a coherent window.
- Wander line: Fourier amplitude of Iout at the wander frequency divided by the fundamental amplitude, in dBc. Windows are integer-cycle in both frequencies; the wander is added in series with the signal and the DC offset.
- Numerical resolution comparison: the whole record is evaluated twice, the second time with the maximum time step halved relative to the first.
- Corner set: supply 1.71, 1.8, 1.89 V; R and C values scaled by 0.9 or 1.1 independently (four combinations); mismatch draws in +/-3 sigma including the extremes; two different supply ramp rates.

## Fixed testbench loads
The 1.0 V output sources and the 2 pF capacitors per output are outside the cell. The cell input pins see the source resistance and the offset sources.
