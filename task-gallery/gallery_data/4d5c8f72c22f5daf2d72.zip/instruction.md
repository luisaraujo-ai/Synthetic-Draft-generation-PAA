I need a transconductance cell for a sensor front end, delivered as a SPICE subcircuit. A slow offset-trim loop removes the input-pair mismatch offset. It has to settle fast, stay well behaved and stay quiet while the cell amplifies a 50 kHz to 200 kHz signal.

Interface: `.subckt gm_cell inp inn outp outn vdd` (ground is node 0). Supply is 1.8 V +/-5 %. The PMOS input pair is named M1 (inp side) and M2 (inn side), with W and L on their instance lines. Use the models pch and nch from the supplied models file and do not redefine them. Each input is driven through 250 kOhm at 0.8 V common mode. Each output is held at 1.0 V with 2 pF to ground. Iout is the current into outp minus the current into outn. The input-referred pair offset is zero-mean with sigma = 5.66 mV*um / sqrt(W*L) of M1/M2, and I will use draws out to +/-3 sigma. Trim correction must enter as a series voltage in the input path. It must come through the supplied trimact block, instantiated exactly once; that block drives only controlled-source control inputs. Other allowed elements are MOSFETs, resistors, capacitors, ideal controlled sources and ideal DC current sources. Every resistor and capacitor, including those in trimact, can vary +/-10 % from nominal.

Requirements, with a 20 mV peak differential sine input unless stated:
- R1: fundamental of Iout divided by input amplitude, at any frequency 50 kHz to 200 kHz, must be 0.97 to 1.03 mS.
- R2: steady-state residual input-referred offset (mean Iout / gm) must be <= 150 uV.
- R3: after power-up (supply ramping from 0, integrator uncharged), the cycle-averaged input-referred offset must enter 150 uV and stay there within <= 200 us of the supply reaching 90 %.
- R4: after a +/-5 mV input offset step, the cycle-averaged offset must settle to within 1 % of the step of its final value in <= 200 us.
- R5: overshoot after that step must be <= 20 % of the step.
- R6: HD3 must be <= -60 dBc at any frequency 50 kHz to 200 kHz.
- R7: with a 10 uV peak sinusoidal offset wander at any frequency 2 kHz to 5 kHz in series with the input, the Iout spectral line at the wander frequency must be <= -72 dBc relative to the fundamental of a 100 kHz signal.
- R8: that wander line must agree to within 1 dB between consecutive windows of at least 10 wander periods.
- R9: the R4 settling time must change by <= 10 us between two otherwise identical evaluations of the same record at different numerical resolution.
- R10: the peak trim voltage at the trimact output must stay within +/-9 mV through R3 to R5, including mismatch plus step.
- R11: mean supply current from vdd must be <= 180 uA (20 uA is reserved for trim circuitry outside the netlist).

All limits must hold over supply corners, the stated component tolerance and any mismatch draw within +/-3 sigma.

Deliver /app/output/gm_cell.cir: a SPICE netlist containing the gm_cell subcircuit and nothing that needs other files except the supplied models and trimact definitions. The supplied files are in /app/input_assets/. Measurement conventions are in the handbook.
