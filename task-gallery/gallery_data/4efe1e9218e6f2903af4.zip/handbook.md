# Handbook

## Supplied models (fixed_parts.cir)
- pass d g s: n-channel square-law device, threshold 2 V, transconductance 2 A/V^2 (device W/L = 1), small channel-length modulation, gate capacitances 300 pF (g-s) and 50 pF (g-d). Connect drain to vin, source to vout, gate to the error amplifier output.
- ea ref fb g: transconductance amplifier injecting current into g when ref exceeds fb. Small-signal gm 10 mS, output current limited to +/-2 mA (tanh law), output resistance 5 Mohm, soft clamp keeping g between 0 and 12 V. Input pins are high impedance. Compensation components go on g.
- vrefblk vin ref: 1.25 V reference that follows vin during power-up (full value once vin is about 6 V or more) through a 10 kohm internal output resistance.
- cdr a b c0= esr=: ceramic capacitor. Effective capacitance = c0 * (1 - 0.6 * (min(max(Vdc,0),32)/32)^1.2), in series with esr. Vdc is the voltage across the capacitor. Tolerance applies to c0.
- dgen: generic silicon junction diode (Is 1e-12 A, N 1, Rs 0.1 ohm).

## Derating table (capacitance fraction of nominal vs DC bias)
0 V: 1.00; 8 V: 0.89; 16 V: 0.74; 24 V: 0.58; 32 V: 0.40. Above 32 V the fraction stays at 0.40. This applies to every cdr instance, input and added alike.

## Tolerance corners
Cable inductance 5.6 to 10.4 uH. Capacitor c0 within +/-20%. Resistors +/-1%. Added inductors +/-20%. Corners are applied to the delivered netlist's values and may be combined.

## Measurement definitions
- Rail ripple: maximum minus minimum of v(vout) over the stated window.
- Cycle-to-cycle variation: within the last 5 load cycles, the spread (max minus min) of the 5 per-cycle maxima, and separately of the 5 per-cycle minima.
- Cold-start reference value: mean of v(vout) over 0.5 ms after 5 ms, same harness voltage, constant load, same corner.
- Recovery time: time from the start of the harness step until v(vout) enters and stays within 50 mV of its pre-step mean.
- Part count: lines starting with R, L, D, or X (capacitor model instances) inside reg, excluding pass, ea and vrefblk.
- Pre-charge states are applied as initial conditions on the input-capacitor node and on vout. Remaining nodes start at 0 V (cold) or settle from there. The inductor current starts at 0.
- Load toggling starts at t = 0 with the heavy-current level, so it overlaps the start-up in the toggling runs.

## General engineering background
- Multilayer ceramic capacitors have ESR roughly 2 to 10 mohm at 10 to 100 kHz. Class-II dielectrics lose capacitance with DC bias and the loss depends on voltage rating and case size. They have negligible dielectric damping.
- A cable inductance in series with a low-ESR ceramic forms an LC resonance whose characteristic impedance and Q follow from L, C and the series resistance.
- Capacitors on the error-amplifier output integrate; its current limit makes large-signal behaviour (start-up, steps) differ from small-signal behaviour. Integrator charge accumulated while the amplifier is saturated can persist after the rail reaches regulation.
- Resistor values in practice come from E96 series; film resistors 1%, ceramic NP0/X7R capacitors 5 to 20%.
- Simulation conventions: the harness source and the load are ideal. The output ripple is measured at the vout node, not at the load terminals through any extra trace.
