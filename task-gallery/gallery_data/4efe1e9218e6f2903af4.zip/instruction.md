I need the input stage for a field sensor board: a regulator that turns the 24 V harness feed into a 5 V rail for a switching-load sensor module. The board hangs off a long cable and the ceramic input capacitor cannot be removed. Sometimes the board powers up from rest, sometimes after a brownout with its capacitors still charged. Both cases must end at the same rail with no lingering oscillation.

Fixed interfaces:
- Harness: ideal source anywhere from 18 to 32 V, through 8 uH series inductance (tolerance +/-30%) and 0.35 ohm to board node vin.
- Input ceramic at vin: 4.7 uF nominal (+/-20%), 5 mohm ESR, fixed. Its capacitance falls with DC bias (handbook, model in file).
- Load on vout: current sink alternating between 40 mA and 600 mA, 50% duty, 2 us linear edges, repetition rate anywhere from 1 to 50 kHz.
- /app/input_assets/fixed_parts.cir holds the pass element, error amplifier, reference and ceramic-capacitor models. Use them by name and do not redefine them. Exactly one pass element, one error amplifier and one reference block are used. Everything else is resistors, inductors, diodes (model dgen) and the supplied ceramic-capacitor model. All capacitors, including compensation, use that model.

Requirements. Each must hold at nominal and at corners: cable inductance +/-30%, capacitor values +/-20%, resistors +/-1%, inductors +/-20%, harness voltage anywhere in 18 to 32 V.
1. Cold start: all nodes at 0 V, harness ramps 0 to its value in 50 us. Vout peak is at most 5.5 V. With a constant 40 mA or 600 mA load, vout is 4.90 to 5.10 V at 5 ms and later.
2. Warm start: harness already at its value, vout pre-charged anywhere in 0 to 5.5 V, input ceramic pre-charged anywhere in 0 to 32 V. Vout never exceeds 5.5 V. The settled DC rail (mean over 0.5 ms after 5 ms, constant load) is within 20 mV of the cold-start value for the same harness voltage, load and corner.
3. Toggling load, 1 to 50 kHz, from either start: rail ripple at most 150 mV peak to peak over the last 5 cycles after 4 ms.
4. Same condition: cycle-to-cycle variation of the rail's maximum and of its minimum over those 5 cycles is at most 3 mV each.
5. Harness step 18 to 32 V and 32 to 18 V (10 us linear), constant 40 mA or 600 mA load: vout returns to within 50 mV of its pre-step value within 200 us and stays there.
6. The measured ripple and recovery time must not depend on time resolution: with the time resolution of the simulation doubled, the ripple changes by at most 3 mV and the recovery time by at most 10 us.
7. Parts: at most 25 resistors, inductors, diodes and capacitors in total, excluding the three supplied blocks. Total nominal capacitance of the added capacitors is at most 22 uF.

Deliverable: /app/output/regulator.cir, a SPICE netlist containing one subcircuit named reg with ports vin vout gnd (gnd is ground), one component per line. Capacitor, resistor and inductor values are written as plain numbers or parameters.
