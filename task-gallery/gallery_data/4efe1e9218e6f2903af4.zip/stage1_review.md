### 00-harness-fed-5v-regulator-stage · Start-state-independent 5 V regulator stage — advance, rank 8

Design decision as written: yes — "a regulator that turns the 24 V harness feed into a 5 V rail ... Deliverable: /app/output/regulator.cir, a SPICE netlist containing one subcircuit named reg with ports vin vout gnd". The agent chooses the loop topology, compensation, input damping, soft-start and all added R/L/D/cdr values.

Forge task: Design a 24 V-harness-fed 5 V linear regulator input stage (one supplied pass element, one error amplifier, one reference block, plus at most 25 R/L/dgen/cdr parts and at most 22 uF total added nominal capacitance) whose cold-start peak, warm-start peak and warm-vs-cold settled-rail difference, load-toggle ripple and cycle-to-cycle spread, harness-step recovery and timestep-insensitivity all hold at nominal and at declared tolerance corners. Output is /app/output/regulator.cir.

Why it fits:
• It is a configuration design task: a netlist with chosen topology and values, not an analysis or measurement exercise.
• Every requirement row maps to a scripted ngspice bench plus Python metric extraction (peak, settled mean, ripple, per-cycle maxima/minima spread, settling time, timestep-difference deltas) and static netlist parsing for R7.
• Difficulty is engineering-real: coupled input LC resonance, class-II capacitance derating with DC bias, transconductance-amplifier integrator saturation/windup, and identical end state from cold and warm starts across corners — a genuine trade-off space, not hidden rules.
• Bounded deliverable (one netlist, one subckt) fits a single agent run of design + local sweeps.

What stops it:
• Structural: none identified. The device and core decision (topology + compensation + damping + values for a harness-fed 5 V regulator) stay intact.
• Unresolved feasibility risks (author claims, unverified): the joint R3 150 mV ripple and R4 3 mV cycle-to-cycle spread at 560 mA steps over 1-50 kHz, with only 22 uF added capacitance and 200 us recovery, may be simultaneously unreachable; the draft itself states "No passing reference has been demonstrated" and its claimed public-design failures are hypotheses, not evidence.
• Unresolved checkability risks: the supplied behavioural models use max/min/pow/tanh expressions; discontinuous derivative behaviour at clamp edges may make R6 (timestep and integrator-method independence) a numerical artefact rather than a design property, and may force timestep-independent results regardless of design — needs demonstration in ngspice before the row is trusted.
• Unresolved runtime: the corner x Vin x load x pre-charge x toggle-frequency matrix is verifier-side and unstated; measured wall time is unknown.

How to check it:
• Python netlist parser (G1): counts R/L/D/X lines in reg excluding pass, ea, vrefblk, sums cdr c0, rejects other element types or redefinitions, verifies exactly one of each supplied block.
• ngspice (G2-G5, G7): cold-start ramp, warm-start initial-condition grid and random points, toggling load at held-out frequencies, harness 18<->32 V steps, run at nominal and at mixed-sign corners (cable L x0.7/x1.3, c0 x0.8/x1.2, R +/-1%, added L +/-20%) applied to the delivered netlist text; Python extracts the stated metrics.
• ngspice (G6): rerun with maximum timestep halved and with a different integration method; compare ripple and recovery deltas.
• Note: these are the proposed checks; none has been executed or validated here.

Simulation gaps:
• LEVEL=1 square-law pass device and tanh transconductance amplifier are idealised: no mobility/temperature effects, no real error-amplifier supply rejection, no MOSFET SOA, self-heating or package parasitics.
• The ceramic model derates only with DC bias per a fixed law; no temperature, ageing, tolerance-of-ESR, or piezoelectric effects; added capacitors are all forced to this one model.
• Harness and load are ideal; no cable resistance tolerance (0.35 ohm fixed), no harness capacitance, no PCB trace/loop parasitics, no conducted-EMI or stability with a real sensor module beyond the stated current sink.
• Real silicon loop stability (phase margin with device capacitance variation, PCB layout coupling) is not covered by a netlist-only check.

Why frontier models fail:
• A plausible hypothesis (the draft states it, unverified): a model that tunes from rest at nominal and checks its own timestep sees a clean 5 V rail, while the hard rows sit at derated 32 V bias, +30% cable L, toggle rates near the ~40 kHz input resonance, and pre-charged warm starts where error-amplifier integrator windup persists.
• Meeting R4 (3 mV cycle-to-cycle) and R6 together demands deliberate damping plus a loop that is both fast (R5) and periodic at 50 kHz; this is a coupled trade-off, not a single analytic fix.

Real-world risks:
• A design that passes the behavioural benches may still ring or overheat with real component spread, real ESR/ESL and real load transients; netlist-level success does not establish manufacturability or EMC.
• Passing R2 only at the sampled pre-charge grid does not prove start-state independence everywhere in the continuous 0-5.5 V x 0-32 V box.

Milestones (if too big): not required; the deliverable is one netlist and one agent run is plausible, subject to the runtime question above. If corner runtime proves excessive, split as: 1. nominal cold/warm/toggle/step benches: passes R1-R5 at nominal; 2. full corner + held-out frequency + timestep sweep: passes R1-R6 at corners.

What to change (reshape): nothing structural. Pin down the open items listed below.

Numbers to supply next:
  • Requirement: base maximum timestep and integration methods for R6 — e.g. default .tran with max step 5 ns, comparison runs at 2.5 ns, methods trap and gear; state whether absolute tolerances (reltol/vntol) are fixed too.
  • Requirement: simulation horizon and window anchors — e.g. run to 10 ms; settled mean over [5.0 ms, 5.5 ms]; toggle metric window "last 5 load cycles after 4 ms" anchored at verifier-chosen cycle boundaries.
  • Requirement: minimum corner sampling policy for G7 — e.g. at least 12 mixed-sign corner combinations plus the extremes, and at least 3 held-out toggle frequencies per bench.
  • Requirement: whether added resistor/capacitor values must be E96/E24 series values or may be any number — e.g. E96 for R, any value for cdr c0/esr; state the allowed esr range for added cdr instances (currently only 5 mohm shown).
  • Interface: exact bench netlist snippets (harness source with 50 us ramp, 8 uH/0.35 ohm cable, load current sink 40/600 mA with 2 us edges at verifier-chosen 1-50 kHz, and how .ic pre-charges are applied to vout and the input-ceramic node) so the agent can reproduce the checker benches locally.
  • Interface: confirm /app/input_assets/fixed_parts.cir is delivered byte-identical to the embedded text and that it parses in the pinned ngspice version; output schema as stated (one component per line, plain numbers/parameters).
  • Handbook data: pinned ngspice version and behavioural-expression support (pow, max, min, tanh in B-sources); whether diode dgen may be used unlimited within the 25-part cap; tolerance application convention (all corners combined simultaneously as stated in G7).
  • Verification still needed (not missing specifications): demonstrate in ngspice that the supplied models converge and that R6 metrics are numerically meaningful (repeat a known netlist at 2x/0.5x step and two integrators and confirm deltas are dominated by design, not solver noise); demonstrate at least one netlist meeting R1-R5 at nominal before treating feasibility as established; measure verifier-side runtime of the full corner matrix.

Evidence status: draft-only input. The reference outline, distinct_valid_designs, public-design failure claims, mechanism-survival narrative and provisional thresholds are author claims, unverified. The fixed_parts.cir content is supplied text establishing what models are specified, not proof the file exists on disk or that it has been simulated. No simulation, corner sweep, passing design, runtime measurement or numerical-noise study has been inspected.

Checks before full-task readiness: (1) run one netlist end-to-end through the proposed benches at nominal to prove the bench definitions are executable and the metric windows resolve; (2) reproduce at least one claimed public-design failure on R3/R4 to confirm the rows discriminate; (3) test R6 sensitivity on a known netlist to separate design dependence from solver noise; (4) measure full corner-matrix runtime and set a sampling policy; (5) fix the R6 timestep/integrator conventions and the parts-series policy.