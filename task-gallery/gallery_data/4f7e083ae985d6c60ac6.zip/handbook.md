# Handbook

## Constants and conventions
- Boltzmann constant 1.380649e-23 J/K. At 85 C (358.15 K), kT = 4.94e-21 J.
- Sampled thermal noise on a capacitor C: v_rms = sqrt(kT/C). Resistance does not change the integrated value. 22 uV rms corresponds to a total node capacitance of about 10.2 pF at 358 K.
- LSB = 2 V / 65536 = 30.52 uV. Half an LSB is 15.26 uV. A 2 V step settled to 0.5 LSB needs a residual below about 7.6e-6 of the step, i.e. roughly 11.8 time constants of a single-pole decay.
- Half period: 7.41 ns at 67.5 MHz, 6.06 ns at 82.5 MHz. The shortest acquisition window is at the top of the band.

## Second-order sample node
A series resistance R, inductance L and node capacitance C form a second-order network. Natural frequency w0 = 1/sqrt(LC), damping ratio zeta = (R/2)*sqrt(C/L). A step residual decays as exp(-zeta*w0*t) when under-damped. The ring phase at a fixed time depends on the damped frequency, which moves with L and C. When over-damped, the slow pole is approximately 1/(R*C) and settling becomes slow. The settling error at a fixed hold time therefore depends on both the decay rate and the oscillation phase. Component tolerances, the signal-dependent switch resistance and the clock period all shift these quantities. Series resistance in the loop includes the source resistance, any series damping resistor, the switch on-resistance and the added return-path resistance.

## Memory mechanisms in sampled stages
- Incomplete settling: charge from the previous sample remains on the node capacitances. The fraction left equals the settling residual.
- Dielectric absorption: a small fraction of capacitance sits behind a long time constant. The spec file gives this branch (0.1 % of the sampling capacitor, 5 us). It holds a slow average of past samples and leaks it back.
- Initial charge: with the settling times involved, its influence has decayed by cycle 21.

## Reading the spec file
- Switch resistance is a function of the node voltage v in volts: ron_ohm*(1 + 0.2 v + 0.1 v^2). It runs from about 0.9 to 1.3 times the setting over +/-1 V.
- The split fraction f scales the loop inductance to L*(1 - 0.5 f), adds 3f ohm to the series resistance and adds 0.3f pF at the sample node.
- Charge injection from the switch is not modelled. The buffer input is a pure capacitance, and the buffer is not part of the held-value measurement.
- Resistor tolerance applies to rd, rz, ron and the 20 ohm source. Capacitor tolerance applies to cs, cz and the fixed capacitances. Inductance tolerance applies to the 18 nH. Every tolerance is taken as a uniform range, and the corners are the extremes.
- The clock band is continuous, so intermediate frequencies matter, not only the band edges.
