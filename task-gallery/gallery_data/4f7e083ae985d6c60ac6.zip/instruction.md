I need the analog sampling stage for our precision acquisition board. It tracks a +/-1.0 V sensor step through a switch, then the switch opens and the held value is read. The board runs unattended in an 85 C chamber for hours, alternating between idle and bursts, so the held value has to be right from the first sample after a transition and every sample after it, anywhere in the clock band.

Fixed inputs are in /app/input_assets/frontend_spec.json: circuit topology, parasitics, switch law, tolerances, and bounds on every design value. In short: clock 67.5 to 82.5 MHz, 50 % duty, switch closed during the first half period and the hold edge at its end. Source resistance 20 ohm. Sample-path loop inductance 18 nH nominal, +/-20 %. Resistors +/-1 %, capacitors +/-5 %.

You choose: sampling capacitor, an optional series R-C damping branch from the sample node to return, a series damping resistor in the signal path, the switch on-resistance setting, and the return-path split fraction (0 to 1; the spec file says what it does).

Definitions. LSB = 2 V / 65536. Held value = sample-node voltage at the hold edge. Held-value error = |held value - input level applied in that cycle|. The input sequence is 40 idle cycles at 0 V, then a 200-cycle burst alternating +1 V / -1 V every cycle (starting at +1 V), then 40 idle cycles at 0 V. At the start of the sequence the capacitors may hold any uniform charge voltage within +/-1 V.

Requirements. Each holds at every clock frequency in the band and across the stated tolerance and inductance ranges.
1. Burst: held-value error <= 0.5 LSB (15.3 uV) in burst cycles 21 to 200.
2. Transitions and idle: held-value error <= 0.5 LSB in the first burst cycle, the first idle cycle after the burst, and idle cycles 21 to 40 of each idle block.
3. Hold-edge timing: requirements 1 and 2 still hold when the hold edge arrives anywhere from 150 ps early to 150 ps late.
4. Noise: sampled kT/C noise at 85 C, computed on the total sample-node capacitance (sampling capacitor at its -5 % corner, parasitic, buffer, switch and split capacitance; damping-branch capacitor excluded), <= 22 uV rms.
5. Capacitor budget: sampling capacitor plus damping-branch capacitor <= 8 pF.
6. Every design value lies inside the bounds given in the spec file.

Deliverable: /app/output/design.json, a JSON object with numeric fields cs_pf, cz_pf (0 if no damping branch), rz_ohm (damping-branch resistor), rd_ohm (series damping resistor in the signal path), ron_ohm (switch on-resistance setting) and split_fraction, in the units named in the spec file.
