Transducer model: motional Rm, Lm and Cm in series, in parallel with C0, all at the bridge output node. The bridge is an ideal source of +Vrail, 0 or -Vrail behind a total series resistance Rsw (10 ohm). Zero means both low-side switches on. States are i_m (motional current), v_cm and v_t (terminal voltage). The equations are L di/dt = v_t - Rm i - v_cm; Cm dv_cm/dt = i; C0 dv_t/dt = (Vs - v_t)/Rsw - i. Typical motional Z0 = sqrt(Lm/Cm) is about 12.6 kohm. The amplitude envelope time constant is 2L/R, about 0.48 ms at nominal. The half-bandwidth is fs/(2Q), about 0.83% of fs. Steady current at resonance for a fundamental drive amplitude Vf is about Vf/(Rm+Rsw).

Drive waveform. Drive cycles are numbered from 0, and each cycle has period T = 1/f_drive. The first half-cycle is positive and the second negative. In each half-cycle the bridge applies +Vrail (first half) or -Vrail (second half) for pulse_width_frac of the half-cycle, centred in that half-cycle, and is otherwise at zero. Segments run back to back, and cycle numbering is continuous across them. The fundamental amplitude is (4/pi)*Vrail*sin(w*pi/2). A brake starts gap_cycles after the last main-burst cycle. It uses the same waveform with the sign inverted (first half negative), so the brake acts as a half-cycle-continuing phase reversal. The last drive edge is the end of the brake, or of the burst if brake cycles is 0. Timing starts at the wake edge (t=0). The first drive edge occurs at td = 0.69*r_hold*Cg after t=0, with Cg = 200 pF. Edges are aligned to a grid of T/400.

Residual-ring initial state: i_m = A cos(phi), v_cm = -A sin(phi)*Z0, v_t = 0, with phi measured against the drive's cycle-0 start. A is 0 to 3.6 mA. The verifier picks phi and A inside the declared range and includes the extremes.

Offsets: a series-resonance shift s scales Cm by 1/(1+s)^2. An Rm scale multiplies Rm only. Lm and C0 are unchanged.

Amplitude window: the last 4 drive cycles of the main burst, taken as the maximum of |i_m| (the brake follows it).

Battery energy: the integral of Vrail*max(0, i_bat) dt, where i_bat = sign(Vs)*(Vs - v_t)/Rsw while Vs is nonzero. Reverse flow is not credited. Add Cg*Vrail^2 per drive pulse as gate energy. Frame average power = (burst energy + gate energy)/1 s + standby power.

Standby power = Vrail*(I_leak(T) + Vrail/r_hold). I_leak is 20 nA at 25 C, 150 nA at 55 C and 900 nA at 85 C (switch devices combined, independent of rail). During the burst, standby power is counted for the full 1 s frame.

Reality checks: piezo discs commonly have Q of 30 to 150 and a series-resonance drift of a few tenths of a percent over life. Free ringing decays as exp(-t/tau), and a residual left at burst start decays at the same rate no matter how the burst is driven. Antiphase drive removes motional current at a rate of about Vf/(2 Lm).
