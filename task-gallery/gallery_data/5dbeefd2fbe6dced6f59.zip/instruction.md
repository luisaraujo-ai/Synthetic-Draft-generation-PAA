We are adding an ultrasonic level sensor node to the product line and I need the drive stage values for its resonant piezo disc. A 3.0 V battery (3.6 V max) pings the disc once per second with a short burst from a full-bridge drive, then the stage sits in standby. The echo level has to be repeatable. The disc may still be ringing slightly when a burst starts, and its resonance and loss drift as it ages.

Transducer (motional branch plus clamped capacitance) and the bridge and leakage data are in /app/input_assets/input.json. Nominal values: Lm 50 mH, Cm 316.63 pF, Rm 209.44 ohm (series resonance 40.0 kHz, Q 60), C0 1.2 nF. Bridge series resistance is 10 ohm in total.

Requirements. Amplitude means the peak motional current in the last 4 drive cycles of the main burst (brake excluded). Ring-down means the peak motional current from 1.6 ms after the last drive edge to 20 ms after it.

R1: cold start, all states zero, 3.0 V, nominal transducer: amplitude 11.4 to 12.6 mA.
R2: same, but starting with residual free ringing of 0 to 3.6 mA at any phase: amplitude 11.4 to 12.6 mA.
R3: ring-down <= 0.3 mA for the R1 and R2 cases.
R4: at 3.0 V with the same residual ringing, for series resonance shifted by -0.4% and +0.4% and Rm scaled by 0.9 and 1.1 (all four combinations): amplitude 9.6 to 14.4 mA.
R5: ring-down <= 0.3 mA for the R4 cases and for the cold start at 3.6 V.
R6: cold start at 3.6 V, nominal transducer: amplitude 8.4 to 15.6 mA.
R7: the last drive edge (burst plus brake) occurs <= 2.0 ms after the wake edge, in every case above.
R8: standby power, drive idle, at 3.6 V and 85 C: <= 6.0 uW.
R9: average battery power over the 1 s frame, cold start, 3.0 V, 25 C: <= 20 uW.
R10: same frame average at 3.6 V, 85 C: <= 30 uW.

Fixed interfaces: full-bridge drive from the rail, no other rails, no energy recovery into the battery, maximum burst end 2.0 ms after wake. The open values are the drive frequency, the burst segments (cycles and pulse width), an optional brake (inverted-phase drive after an optional gap), and the gate-hold resistor, which sets both standby current and turn-on delay. The waveform conventions are in the handbook.

Deliver /app/output/design.json with these fields: f_drive_hz (36000 to 44000); segments (list of up to 6 objects, each with integer cycles 1 to 80 and pulse_width_frac 0.05 to 1.0 in steps of 0.05); brake (object with gap_cycles 0 to 5, cycles 0 to 10, both in steps of 0.5, and pulse_width_frac 0.05 to 1.0 in steps of 0.05); r_hold_ohm (1e5 to 2e7).
