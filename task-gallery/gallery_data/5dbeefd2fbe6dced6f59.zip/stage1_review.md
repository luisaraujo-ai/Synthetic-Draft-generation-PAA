### 13 · Piezo burst drive and standby stage — advance, rank 8

Design decision as written: yes — "The open values are the drive frequency, the burst segments (cycles and pulse width), an optional brake ... and the gate-hold resistor, which sets both standby current and turn-on delay."

Forge task: Select f_drive_hz, up to 6 burst segments (cycles, pulse_width_frac), an optional antiphase brake and r_hold_ohm for a battery-powered full-bridge drive of a resonant piezo disc, such that burst amplitude is held in tight windows across cold/warm starts and ±0.4% fs / ±10% Rm corners, ring-down is suppressed below 0.3 mA by 1.6 ms after the last edge, the last edge lands within 2.0 ms of wake, and standby plus frame-average battery power stay under 6/20/30 µW limits.

Why it fits:
• It asks for a design (waveform schedule + a component value), not an analysis: the deliverable is a parameter set in /app/output/design.json that a physical drive stage would use.
• The full physics that matters (three-state linear RLC model, switching-level propagation, gate energy, leakage, battery rectification of current) is stated in the handbook and can be integrated exactly headlessly.
• The hard content is real engineering: a burst long enough to wash out a 3.6 mA arbitrary-phase residual must fit inside a window squeezed between standby-imposed minimum r_hold and the 2.0 ms last-edge deadline, while an antiphase brake must kill ring-down at four parameter corners and at two rails, and energy budgets forbid brute-force long bursts.

What stops it:
• Structural: none. The decision, the model, the acceptance limits and the output schema are all given.
• Unresolved feasibility risks: no passing reference exists yet — the draft's reference_outline is explicitly "provisional estimates ... not confirmed by a passing reference". Whether the stated windows (11.4–12.6 mA at nominal warm start, 0.3 mA ring-down at 1.6 ms, ≤20 µW frame) are jointly satisfiable at the corners is an open engineering question, not a demonstrated fact. The claimed failures of the four public designs are author claims with no supplied simulations.
• Fidelity risk: the task's ground truth is the supplied linear model; real piezo nonlinearity at drive level, temperature coefficient of Cm/Lm, and real MOSFET gate behavior are outside the model.

How to check it:
• Proposed checker (as specified in grader_plan): exact matrix-exponential propagation of the three-state ODE on a T/400 switching grid, from zero state (R1/R6), from verifier-chosen residual states (R2/R4), continuing undriven for ring-down (R3/R5), plus exact schedule arithmetic for R7 (G4) and analytic energy integration for R8–R10 (G5).
• ngspice: transient of the equivalent RLC + switch network cross-checks one case; the draft allows 0.5% slack for this cross-check only.
• Separately, in principle vs. implemented: the tools are suitable in principle; no implementation, no runtime measurement and no cross-check result has been inspected. Residual draws are held out from the solver (24 per corner per G2), which is specified but not yet demonstrated to be sufficient coverage of phase.

Simulation gaps:
• The model is linear and ideal: no piezo nonlinearity or drive-level dependence of Rm/Cm, no switch dead-time or body-diode conduction detail beyond i_bat = sign(Vs)(Vs−v_t)/Rsw, no EMI or supply-impedance effects, no self-heating.
• Numerical: a T/400 grid with T/800 halving and a 1% amplitude-change rule is specified but unproven; peak |i_m| between grid points could be missed, and the acceptable error at the ±20% R4 corners is not quantified beyond the grid rule.
• Ring-down measured from 1.6 ms onward is easy to game relative to real acoustic ringing; the model's exp(−t/τ) with τ ≈ 0.48 ms is an assumption.

Why frontier models fail:
• Hypothesis, not verified: a cold-start-tuned short burst passes a solver's own convergence checks while failing held-out warm-start phases and fs/Rm corners; the amplitude window (±5% nominal, ±20% corners) is narrow relative to residual-phase sensitivity.
• The r_hold trade-off is genuinely coupled: standby forces r_hold ≳ 4.7 MΩ at 3.6 V/85 °C while R7 then consumes ~0.65–0.8 ms of the 2.0 ms budget, so burst + brake must be built and validated inside ~1.2 ms — a packaging-style squeeze across four requirement families.

Real-world risks:
• A design passing the stated model may ring longer in hardware (acoustic loading, coupling to the liquid, housing) or drift further in fs over life than ±0.4%.
• Leaky real drivers at 85 °C and gate leakage may exceed the prescribed leakage table; r_hold temperature coefficients matter.
• Battery internal resistance and rail droop during the burst are not modeled; the rectified i_bat integration assumes a stiff rail.

Milestones (if too big): not needed — the parameter space and simulation cost are plausible within one ~2 h run, subject to a measured full-sweep runtime.

What to change (reshape): • Nothing structural. Keep the same device and the same core decision (drive schedule + r_hold); only pin down remaining conventions (below).

Numbers to supply next:
  • Verification (not spec): reproduce one baseline failure from public_designs (e.g. the fixed 2 ms constant-width burst should trip R7 and the energy limits) and demonstrate one passing schedule, with measured checker runtime and T/400 vs T/800 amplitude deltas — needed before full-task readiness.
  • Requirement: exact residual-draw policy — e.g. "24 draws per corner, seeded PRNG seed 0, always including A = 0 and A = 3.6 mA at phases 0, π/2, π, 3π/2".
  • Requirement: peak measurement convention — e.g. "peak of |i_m| evaluated on the T/400 grid, with a 0.1% relative tolerance on the window edges".
  • Requirement: whether an empty segments list is legal and whether any segment may have zero effective drive — e.g. "at least one segment required".
  • Interface: one example /app/output/design.json instance and one example /app/input_assets/input.json echo — e.g. {"f_drive_hz": 40000, "segments": [{"cycles": 20, "pulse_width_frac": 1.0}, {"cycles": 20, "pulse_width_frac": 0.35}], "brake": {"gap_cycles": 0.0, "cycles": 2.0, "pulse_width_frac": 0.25}, "r_hold_ohm": 5500000} (illustrative only, not a validated design).
  • Handbook data: already supplied (Lm 50 mH, Cm 316.63 pF, Rm 209.44 Ω, C0 1.2 nF, Rsw 10 Ω, Cg 200 pF, leakage table 20/150/900 nA) — confirm these are fixed constants for grading, and confirm the gate-energy term Cg·Vrail² per pulse is independent of r_hold.

Evidence status: Draft-only input. All physics constants, requirements, grader plan, reference outline, distinct_valid_designs and public_designs failure claims are author-supplied text; nothing has been executed or inspected. Internal consistency spot-checks (fs ≈ 40.0 kHz from Lm·Cm; Q ≈ 60 from Z0/Rm; R8 implying r_hold ≳ 4.7 MΩ; td ≈ 0.76 ms at 5.5 MΩ) are my arithmetic on the stated numbers, not verification of feasibility.

Checks before full-task readiness: (1) build and run the stated checker and ngspice cross-check on a candidate design; (2) confirm the nominal and corner windows are jointly satisfiable with a demonstrated passing schedule; (3) confirm at least one listed public design fails for the stated reason; (4) measure full-sweep runtime and grid convergence noise; (5) fix the held-out draw policy and peak-measurement convention.