Conventions and data for the rail.

Capacitor model. Each capacitor is a series R-L-C branch from its node to ground. Its effective capacitance is C_eff = C_nominal x bias_factor x (1 + cap_offset), where the bias factor is the derating at the 1.8 V rail. ESR and ESL come from the table. The ESR offset scales ESR only. The series-inductance offset scales the feed 800 nH and the trace 100 nH by the same factor; the resistances are not scaled. For the damper, Rd is in series with each damper capacitor's own ESR. A count of n means n identical parts in parallel. Capacitors start at the stated common initial voltage and inductors at zero current.

Load waveform. For burst period T = 1/f, the current rises linearly from 0 to 1.2 A over 0 to 20 ns. It holds 1.2 A until 0.35 T, falls linearly to 0 over the next 20 ns, and stays at 0 until T. Burst k covers (k-1)T to kT. The per-burst minimum and maximum are the extreme node-B voltages in that interval.

Numerical consistency. Each per-burst minimum and maximum at node B must be resolved accurately enough that refining the time resolution by a factor of two changes it by at most 2 mV, in every case above.

Tolerance combinations. Offsets can lie anywhere in the stated ranges, not only at the endpoints. Burst frequency can take any value in 180 to 260 kHz.

Physics worth knowing. The feed inductance and the bulk capacitance form a series RLC with characteristic impedance Z0 = sqrt(L/C). Its damping ratio is zeta = (R/2) x sqrt(C/L). A step into this circuit gives overshoot that falls with zeta, and a stored residual decays with time constant about 2L/R. Ceramic classes lose much of their capacitance under DC bias. Polymer classes are mostly flat but have higher ESR and ESL. A resistor in series with a capacitor at node A damps the mode without carrying the load's DC current. A series resistor in the load path does carry that current and costs voltage during bursts.

DC reference. Average load current is 0.42 A. The burst-on current is 1.2 A. The total DC loop resistance without added parts is 30 mohm.

Feasibility note. The limits in the brief are provisional estimates and have not been confirmed with a passing reference design.
