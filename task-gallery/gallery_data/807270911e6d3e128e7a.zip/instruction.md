I need the 1.8 V core rail for our burst-mode radio/processor board. The load pulls periodic current bursts through a long, inductive feed. The rail has to come up the same way after a cold start, after a brownout where the capacitors still hold charge, and when the burst rate drifts. I need a passive decoupling and damping network from you.

Fixed inputs:
- Feed: ideal 1.90 V source, 0.02 ohm in series with 800 nH, switched on at t = 0. It feeds node A.
- Trace from node A to the load pins (node B): 100 nH in series with 10 mohm. You may add a series resistor Rs, 0 to 0.5 ohm, in this path.
- Load at node B: ideal current source, 0 to 1.2 A bursts, 35% duty, 20 ns rise and fall. Burst repetition frequency can be anywhere from 180 to 260 kHz. The load is already running at t = 0.
- Capacitors come from the classes in /app/input_assets/capacitor_classes.json (C, ESR, ESL, bias factor and area per part). Place them at node A or node B, at most 12 in total including any damper capacitors, and at most 60 mm2 total area. The optional damper is a series resistor Rd (0 to 1 ohm) plus capacitors of one class at node A.
- Passive parts only; no regulating element.
- Tolerances, applied in any combination: capacitance -20% to +10%, ESR +/-30%, series inductance (feed and trace together) +/-20%.
- Start states: all capacitors at 0 V (cold start), or all capacitors at one common residual voltage anywhere from 0 to 1.5 V, with zero inductor current (brownout recovery).

Requirements, at node B and valid for every start state, every burst frequency in the band and every tolerance combination. Bursts are numbered from 1 at t = 0.
1. Per-burst minimum voltage during bursts 60 to 80: at least 1.74 V.
2. Maximum voltage during bursts 60 to 80: at most 1.98 V.
3. Maximum voltage during the first 60 bursts: at most 2.10 V.
4. Difference between consecutive per-burst minima during bursts 60 to 80: at most 3 mV.
5. For identical frequency and tolerances, the spread of per-burst minima between cold start and any residual-charge start, during bursts 70 to 80: at most 4 mV.
6. Network limits: the count, area, Rs and Rd limits above, with classes from the supplied table only.

Deliverable: /app/output/design.json with these fields:
- "rs_ohm": number.
- "capacitors": list of {"class": string, "node": "A" or "B", "count": integer}.
- "damper": null, or {"class": string, "count": integer, "rd_ohm": number}.

The damper's capacitors count toward the 12-part and 60 mm2 limits.
