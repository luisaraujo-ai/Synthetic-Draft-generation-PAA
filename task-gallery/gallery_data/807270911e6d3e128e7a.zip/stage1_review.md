### 05-burst-rail-decoupling-start-independent — burst rail decoupling and damping network — advance, rank 7

Design decision as written: yes — "I need a passive decoupling and damping network from you" with deliverable "\"rs_ohm\": number; \"capacitors\": list of {class, node 'A'|'B', count}; \"damper\": null or {class, count, rd_ohm}"

Forge task: Select the passive network for the 1.8 V burst-load core rail (Rs in the A→B trace, capacitor classes and counts from the supplied table at node A and node B, optional Rd+cap damper at node A, ≤12 parts, ≤60 mm²) so that node-B per-burst minima/maxima meet R1–R5 for every start state, every burst frequency in 180–260 kHz and every tolerance combination, with R7 timestep convergence; deliver the network as /app/output/design.json.

Why it fits:
• A configuration design decision (topology + discrete part selection + one series damping element) with a machine-readable output, not an analysis report.
• Fully checkable in principle with ngspice alone: the whole plant is ideal sources, series R-L, R-L-C capacitor branches and a piecewise-linear current load; a transient run yields per-burst extrema at node B directly.
• The difficulty is genuine engineering: a series RLC mode (zeta = (R/2)sqrt(C/L)) that must be damped enough for the 2.10 V start-up limit and the 3 mV/4 mV history rows, while damping elements must not eat the 1.74 V droop budget (30 mohm nominal loop plus 1.2 A burst edges).
• Robustness requirements (interior tolerance points, a whole frequency band, residual-charge starts from 0–1.5 V) force corner reasoning rather than a nominal-only tune; the 12-part / 60 mm² budget creates a real packaging/sizing trade-off between bulk at A and local ceramics at B.

What stops it:
• Structural: nothing structural blocks the task — it is a design decision, and the required physics is all linear RLC transient behaviour.
• Unresolved feasibility risks: (a) no passing reference design has been run — the brief itself says the limits are provisional; it is unknown whether any arrangement in the class table meets R1–R5 simultaneously (the R1 droop vs R3/R4/R5 damping window may be empty or razor-thin). (b) Grader runtime is unmeasured: 80 bursts at 180 kHz span ~0.45 ms; a timestep fine enough to resolve 20 ns edges and satisfy R7's 2 mV convergence, repeated over tolerance corners + interior points × frequencies × start states × two timesteps, could be tens to hundreds of runs. (c) The claim that naive designs fail (R3/R4/R5) is an author hypothesis, not inspected evidence.

How to check it:
• ngspice: parse design.json, build the netlist (1.90 V source, 0.02 Ω + 800 nH feed, 100 nH + 10 mΩ trace plus Rs, R-L-C branches per part from the class table with C_eff = C·bias_factor·(1+cap_offset), damper Rd in series with damper ESR, piecewise-linear 0→1.2 A burst current with 20 ns edges at 35% duty), run transient from cold start and from each residual voltage, and extract per-burst min/max at node B for bursts 1–80; enforce R1–R5 over the tolerance/frequency/start-state grid and R7 by repeating at half timestep.
• Static checks (script): class/node validity, part count ≤12 including damper, area sum ≤60 mm², 0 ≤ Rs ≤ 0.5 Ω, 0 ≤ Rd ≤ 1 Ω.

Simulation gaps:
• Linear RLC + ideal current source omits capacitor DC-bias nonlinearity beyond the table's fixed bias_factor, temperature dependence, ESL mutual coupling between branches, PCB plane spreading inductance/resistance, load-regulator interaction and any real source impedance of the 1.90 V feed.
• Per-burst extrema of a 20 ns-edge waveform are timestep-sensitive; R7 only bounds the change under one halving, not convergence to the true value. Trapezoidal ringing in ngspice can pollute sub-mV minima; the checker's own timestep must be stated and justified.
• Corner + random-interior tolerance sampling cannot prove the requirement holds for 'any combination' of offsets; passing the grid is evidence of robustness, not proof over the continuous box.

Why frontier models fail: plausibly (hypothesis, not tested) because the design couples a lightly damped feed mode to edge-local droop at node B, must hold across a continuous tolerance box, a 180–260 kHz band and a family of residual-charge initial states, and the fix for history persistence (more damping) directly worsens the burst droop limit — so a nominal-parameter or single-warm-start check passes while the low-C / high-L / low-ESR corner plus residual start breaks R4/R5. The task also demands the solver run and interpret its own sweeps and retune, not just emit a plausible recipe.

Real-world risks:
• The 60 mm² budget assumes the class table's area per part is a fair proxy for footprint plus keep-out; real placement at node B limits local ceramic count, and ESL of the shared via/ground path is not modelled.
• Bias derating is applied as a fixed factor at 1.8 V; during the 2.10 V startup transient and the 1.74 V droop the effective capacitance actually varies.
• 'All capacitors at one common residual voltage' is an idealisation of a brownout; real boards show non-uniform residuals and non-zero inductor current.

Milestones (if measured runtime forces a split):
1. Cold-start nominal network: design.json meeting R1–R3 at nominal tolerances and band corners — grader runs nominal cold-start transients only.
2. Tolerance-robust network: same deliverable meeting R1–R4 across the tolerance box — grader adds corner and interior tolerance points.
3. Start-independent network: full R1–R7 including residual-charge starts and timestep halving — grader adds G3 and G4.

What to change (reshape): nothing yet; keep the single task. Split into the milestones above only if measured ngspice runtimes show the full sweep exceeds the run budget.

Evidence status: author draft only. The capacitor class table is supplied as embedded text (it establishes specified data, not that /app/input_assets/capacitor_classes.json exists or is valid). The reference outline is a proposed approach, not a passing design. The 'public_designs' failure claims, the mechanism-survival narrative, and the provisional limits are unverified author claims; no simulation has been run or inspected. Distinguish: R1–R7 and the class table are stated requirements/data; feasibility, failure modes and the narrowness of the design window are engineering inferences awaiting execution evidence.

Checks before full-task readiness:
• Reproduce a baseline failure: run at least one naive recipe (e.g. maximum polymer bulk with no damping) and confirm the claimed R3/R4/R5 breakage at the low-C/high-L/low-ESR corner with a residual-charge start.
• Demonstrate one passing design.json under the checker's own grid before freezing limits; if none exists in the class table, report that honestly rather than widening R1–R5.
• Measure ngspice runtime and timestep convergence on the final grid (single run wall time, total sweep time, and the R7 2 mV margin in practice, including trapezoidal ringing behaviour).
• Fix the grader's timestep pair, extremum extraction window, tolerance/frequency/residual sampling sets and area accounting so R7 is deterministic.
• Confirm the design.json schema (number formatting, damper null semantics, whether damper caps sit at node A) is unambiguous for the parser.

Numbers to supply next:
• Requirement (verification still needed): a demonstrated passing design within the stated limits — e.g. a design.json that passes a full grid sweep, plus the baseline failure run above; limits themselves are already specified and must not be relaxed to obtain a pass.
• Requirement (specification): grader timestep pair and extremum extraction — e.g. dt = 2 ns and 1 ns, extrema taken over the exact burst-k interval [(k-1)T, kT], interpolation rule at interval endpoints stated.
• Requirement (specification): tolerance and frequency sampling — e.g. all 8 sign corners of (cap_offset, ESR_offset, L_offset) plus 20 fixed-seed interior points, frequencies {180, 197, 213, 233, 260} kHz plus 3 fixed-seed interior frequencies, residual voltages {0, 0.4, 0.9, 1.5} V plus 4 fixed-seed values in 0–1.5 V; state whether the damper capacitors share the same common residual (assumed yes).
• Requirement (specification): area and counting rules — e.g. total area = Σ (class area × count) including damper caps, hard limit 60 mm²; counts are positive integers; Rs/Rd defaults of 0 allowed; capacitors must be listed at most once per (class, node) row.
• Interface: inputs = /app/input_assets/capacitor_classes.json (as embedded in the brief) and the brief text; output = /app/output/design.json with exactly {"rs_ohm": number, "capacitors": [{"class": string, "node": "A"|"B", "count": integer}], "damper": null | {"class": string, "count": integer, "rd_ohm": number}} — e.g. {"rs_ohm": 0.05, "capacitors": [{"class": "P330", "node": "A", "count": 2}, {"class": "X47", "node": "B", "count": 4}], "damper": {"class": "X10", "count": 2, "rd_ohm": 0.35}}.
• Interface: checker netlist contract — e.g. ground node 0, node A and node B named as in the brief, ideal 1.90 V source switched on at t = 0 with zero initial inductor currents; a sample reference netlist line per branch.
• Handbook data: the capacitor class table is already supplied (e.g. X47: 47 uF, 3 mohm, 1.2 nH, 9 mm², bias 0.5); if real parts are intended later, add package/height limits and manufacturer bias-curve data. Verification still needed: confirm that per-branch C_eff, ESR, ESL and the shared L-scaling rule are implemented identically in agent and checker models.
• Verification still needed: budget check — measured wall time of one full G2+G3+G4 sweep vs the ~2 h agent budget (e.g. 60 runs × measured seconds each).