We are building a bridge-sensor data-acquisition board and need the front-end block to meet the datasheet numbers below at the connector. The cable can pick up a 10 V transient and the board is power-cycled daily, so the block has to come up and recover the same way every time.

Block: differential input IN_P/IN_N, single-ended output OUT referred to GND, rails VCC = +5 V and VEE = -5 V, load on OUT 10 kohm in parallel with 100 pF. Sensor: two 175 ohm legs (350 ohm differential) joined at a midpoint that is connected to GND; one leg goes to IN_P, the other to IN_N. The sensor signal is 0 to 20 mV differential, DC to 1 kHz. Overload pulse: a voltage source of 10 V, 100 us width, 10 ns edges, positive polarity, inserted in series with the IN_P leg (between the 175 ohm resistor and IN_P). Build the block from the amplifier macro LNA and the clamp diode model DCLAMP in /app/input_assets/lna.lib (at most three LNA instances, noise data in the file header), plus resistors, capacitors (no inductors) and DCLAMP diodes. No other active parts.

Spread: resistors 1 %, capacitors 5 % plus a further +/-3 % drift over temperature, temperature 0 to 70 C, each sensor leg resistance +/-10 %. Every requirement below must hold for every combination inside these ranges, including combinations not named here. Differential gain means OUT / (V(IN_P) - V(IN_N)).

Requirements:
R1. Gain at 100 Hz between 92 and 108 V/V.
R2. Gain at 1 kHz at least -0.5 dB relative to the gain at 100 Hz; gain at 100 kHz at most -66 dB relative to the gain at 100 Hz.
R3. Input-referred rms noise, 1 Hz to 1 kHz, sensor thermal noise included, at 27 C with nominal values: at most 215 nV.
R4. Same noise at any combination of the spread ranges, including 70 C: at most 240 nV.
R5. Power-up with the rails ramping from 0 to +/-5 V in 1 ms, all capacitor voltages initially zero, 10 mV DC differential at the input: OUT within 50 uV of its final value from 20 ms to 40 ms.
R6. Same power-up from any initial capacitor voltages between -4 V and +4 V: same 50 uV limit, and final value within 50 uV of the R5 final value.
R7. Overload: the 10 V, 100 us pulse, applied at any instant after settling: OUT within 50 uV of its pre-pulse value from 5 ms to 20 ms after the pulse starts.
R8. Peak-to-peak ripple on OUT from 15 ms to 20 ms after the pulse starts at most 20 uV.
R9. During the overload, peak current in any DCLAMP diode at most 12 mA and peak current into any LNA input pin at most 2 mA.
R10. Average current drawn from VCC at 10 mV input at most 3 mA.
R11. The OUT values judged in R5 to R7 must be numerically converged: they change by at most 10 uV when the numerical resolution of the time-domain analysis is made four times finer.

Deliverable: /app/output/frontend.cir, a SPICE subcircuit named FRONTEND with ports IN_P IN_N OUT VCC VEE GND, containing only the subcircuit definition. Use literal numeric values (no parameters, no initial-condition statements) and element names starting with R, C, D or X.
