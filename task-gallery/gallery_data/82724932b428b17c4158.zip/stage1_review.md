### 08 · Protected bridge-sensor front end — advance, rank 8

Design decision as written: yes — "Build the block from the amplifier macro LNA and the clamp diode model DCLAMP ... plus resistors, capacitors (no inductors) and DCLAMP diodes"; deliverable is "/app/output/frontend.cir, a SPICE subcircuit named FRONTEND".

Forge task: Design a two- to three-amplifier bridge front end (topology and literal R/C values, rail clamping) that delivers 92–108 V/V at 100 Hz with the specified 1 kHz/100 kHz shape, ≤215/≤240 nV input-referred noise, start-state-independent settling within 50 µV, 5 ms overload recovery from a 10 V/100 µs pulse with ≤12 mA diode / ≤2 mA pin peak currents, ≤3 mA VCC current, all corners of ±1 % R, ±5 %±3 % C, ±10 % sensor legs, 0–70 °C, and dt-converged judged values — emitted as one ngspice subcircuit.

Why it fits:
• The deliverable is a component-value and topology decision, not a report or a simulation of a fixed system.
• Every requirement row has a named headless check: AC sweeps (R1, R2), AC-transfer-weighted noise integration in numpy (R3, R4), ngspice transient with 1 ms rail ramp and checker-injected .ic (R5, R6, R10), pulsed transient with current probes (R7, R8, R9), paired dt / dt/4 runs (R11), netlist parse (G6).
• The physics that matters (op-amp macro poles, diode clamping, RC/Q of the low-pass section, thermal and 1/f noise, resistor-loading gain tolerance) is exactly what the stated tools model.
• The requirement set is genuinely coupled: the droop and −66 dB rows fix the low-pass corner within roughly ±8 %, overload current sets a minimum series resistance, and the noise budget caps it — a real packaging/trade-off problem.

What stops it:
• Structural: none — the task is a design decision and all rows are checkable in principle with ngspice + numpy.
• Unresolved feasibility risks (not missing numbers): (a) runtime — G3/G4/G5 ask for many 60–80 ms transients over tolerance interiors and two time steps; with 10 ns pulse edges this could exceed the agent's own verification budget within a 2 h run; (b) ngspice robustness of checker-injected .ic on arbitrary capacitor states and of 10 ns edges driving a clamped input; (c) R11's reference time step is undefined, so "four times finer" is not yet reproducible; (d) R6 wording leaves open whether LNA-internal capacitors are part of the precharge set; (e) the noise limit sits close to the handbook-derived floor — rough arithmetic on the supplied densities gives order 170–190 nV at 27 °C nominal with ~300 Ω per leg and gain ~100, consistent with the author's unverified 185–200 nV claim but with little margin at 70 °C corners.

How to check it:
• ngspice (AC): differential gain magnitude at 100 Hz, 1 kHz, 100 kHz vs the 100 Hz reference, at nominal, grouped corners and seeded random interior samples.
• ngspice (AC) + numpy: transfer functions from each LNA's VEN/IIP/IIN (unit amplitude) and resistor thermal noise to OUT, divided by differential gain squared, integrated 1 Hz–1 kHz with the stated white + 1/f formula; 27 °C nominal and 70 °C/tolerance interiors.
• ngspice (transient): 0–60 ms run with 1 ms rail ramp, 10 mV DC input, zero and random .ic capacitor states; deviation from mean(55–60 ms) final value over 20–40 ms, cross-start final-value difference, mean VCC current 40–60 ms.
• ngspice (transient): 10 V/100 µs, 10 ns-edge PWL in series with the IN_P leg at checker-chosen instants; OUT deviation 5–20 ms, p–p 15–20 ms, diode and VSP/VSN peak currents.
• ngspice (transient, repeated) at max step dt and dt/4 for R11; Python netlist parse for element/port constraints.

Simulation gaps:
• The behavioural LNA macro (tanh swing limiter, clamp B-source, 50 Ω output, fixed 19.9 pF internal pole) is a model, not silicon: no input capacitance, no PSRR/CMRR, no supply-dependent bias, no diode self-heating, no PCB parasitics, so real EMI on the cable and actual clamp energy are not represented.
• The noise route is AC-transfer weighting, not a native .noise run; agreement between the two must be demonstrated, and 1/f noise of the macro is applied externally rather than by the model itself.
• Convergence/accuracy at 10 ns edges and near-diode conduction, and the numerical noise floor of the 50 µV judgments (relative to R11's 10 µV allowance), are untested here.
• Corners-plus-random sampling cannot prove all-combinations compliance; interior worst cases (e.g. Q and corner drifting together) may be missed.

Why frontier models fail:
• Plausible, not demonstrated: the window is narrow and multi-constraint — a first-order filter cannot meet both R2 rows, a high-Q section fails R7/R8, AC coupling fails R5/R6 and 1/f noise, large input resistors fail R4, small ones fail R9, three-amplifier instrumentation topologies fail R10. Correctly trading gain tolerance (±10 % legs enter the gain), noise, clamp current and settling time through a whole power-up and overload cycle, and then converging transient numerics, is real engineering reasoning rather than pattern completion.

Real-world risks:
• Model-to-hardware gaps above; plus cable-transient common-mode coupling is only represented as a series differential pulse, real clamps need surge/energy consideration beyond 12 mA peak, resistor tolerance is treated as independent scaling (real parts correlate), and the LNA macro's unspecified input capacitance could change clamp/settling behaviour in a build.

Milestones (if too big): Not required if checker sweep runtimes are measured first; if they are not, split as (1) gain/noise stage design with G1/G2 graders and (2) protection plus settling/recovery with G3–G5 graders, each with its own starting testbench and reference netlist.

What to change (reshape): None — pin down the items under "Numbers to supply next"; these are specification fill-ins, not a change of device or core decision.

Numbers to supply next:
  • Requirement: R11 time-step basis — e.g. max step dt = 2 µs in G3/G4 transient runs, compared against dt = 0.5 µs; state that pulse edges are ideal 10 ns PWL in the checker testbench.
  • Requirement: R6 precharge scope — e.g. .ic applied only to capacitors declared inside frontend.cir, LNA-internal C1 left at model default; 12 random precharge vectors within ±4 V.
  • Requirement: temperature and drift coverage for R5–R8 — e.g. judged at 27 °C nominal plus 4 grouped corners at 0 °C and 70 °C, or full interior sampling; state explicitly.
  • Requirement: sample counts and seeds — e.g. 60 random interior samples for G1/G2, 13 starts × 20 spread samples for G3, 30 pulse instants × 20 spread samples for G4, fixed seed, plus an upper bound on total checker CPU (e.g. 4 h) so the agent can mirror it.
  • Interface: inputs /app/input_assets/lna.lib and the checker-built testbench (two 175 Ω legs at GND midpoint, 10 kΩ ‖ 100 pF load, ±5 V rails); output /app/output/frontend.cir containing only '.subckt FRONTEND IN_P IN_N OUT VCC VEE GND ... .ends'; state the exact metric extraction (e.g. final value = mean OUT over 55–60 ms).
  • Handbook data: already supplied (k = 1.38e-23, white + 1/f integral, LNA and DCLAMP parameters, tolerance convention). Add: whether arbitrary literal values are allowed or an E-series grid applies (e.g. E24 for R), and the max element count if any.
  • Verification still needed before full-task readiness: reproduce at least one passing design in ngspice and record the judged values; measure runtime of the G4/G5 sweeps at the stated dt; confirm ngspice accepts .ic on the design's capacitor nodes and converges the 10 ns pulse; cross-check the numpy noise combination against a native ngspice .noise run at nominal; confirm the 70 °C corner noise stays under 240 nV in an actual run, not just handbook arithmetic.

Evidence status: draft-only input. The reference outline, the 185–200 nV / 2.4 mA / 9 mA estimates, the listed public-design failures and the mechanism-survival narrative are author claims, unverified; no simulation output, netlist artifact or runtime measurement has been inspected. Handbook arithmetic above is my engineering inference, not measured evidence. lna.lib text is supplied content establishing the model text, not physical fidelity.