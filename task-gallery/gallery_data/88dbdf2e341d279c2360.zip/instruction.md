I need a floating supply for the high-side gate driver of a half-bridge in a motor drive. The only energy source is the 12 V low-side rail: no transformer, no isolated bias. The drive idles, then runs at any duty from 5% to 90% at 100 kHz and steps between duties. Sometimes it holds the high side on for many cycles. The driver rail Vb (VB relative to SW) must be right from a cold start, from a pre-charged state and after every such step. Undervoltage lockout and gate overstress are both unacceptable.

Deliver a netlist of a subcircuit GATE_SUPPLY with pins VIN SW VB GND, using only resistors, capacitors, and the diode and switch models in /app/input_assets/models.cir. One element per line, plain numeric values, no initial conditions on capacitors. Capacitors are listed as ideal; 50 mohm ESR is added in series with each one, and each is 25 V rated.

Fixed externals: the 12 V rail (+/-5%) reaches VIN through 0.5 ohm in series with a 20 nH (+/-20%) loop with 0.3 ohm. SW is forced from 0 to 400 V with 20 ns edges at 100 kHz (+/-3%), duty D 0.05 to 0.90, each period starting low. Capacitors are +/-10%. The driver load sits between VB and SW: 1.0 mA constant plus 20 nC drawn as a 0.2 A, 100 ns pulse at each SW rising edge.

Requirements. Each must hold at every tolerance, rail, frequency and loop-inductance value in the stated ranges, at any duty in range, and with every capacitor starting at 0 V, 6 V or 12 V:
1. Vb reaches 10.0 V within 200 us of the start of the first switching period.
2. After first reaching 10.0 V, Vb stays at or above 9.0 V at all times.
3. After a duty step in either direction between any two duties in range, Vb is back inside 10.0 to 13.0 V within 300 us and stays there.
4. Vb never exceeds 13.5 V.
5. At fixed duty, once settled, the Vb spectrum over 64 cycles has at most 60 mV amplitude at 100 kHz, at most 30 mV at each of the 2nd to 10th harmonics, and at most 10 mV at every other non-DC frequency bin.
6. At fixed duty, once settled, end-of-cycle Vb differs by at most 20 mV between consecutive cycles.
7. If SW is held at 400 V for up to 250 us, Vb stays at or above 9.0 V, and returns to 10.0 to 13.0 V within 5 cycles after SW falls.
8. Current drawn from the 12 V source (before the 0.5 ohm), averaged over 50 ns, never exceeds 0.2 A, including start-up.
9. At most 12 parts in total, at most 2 uF total nominal capacitance, and no capacitor voltage above 25 V.
10. Rerunning any scenario with half the integration step changes the minimum Vb, maximum Vb and settled spectral amplitudes by at most 20 mV.

Output: /app/output/gate_supply.cir, the netlist.
