### 17 · Floating high-side gate supply from the 12 V low-side rail — advance, rank 8

Design decision as written: yes — "Deliver a netlist of a subcircuit GATE_SUPPLY with pins VIN SW VB GND, using only resistors, capacitors, and the diode and switch models in /app/input_assets/models.cir"

Forge task: Design the topology and component values of a transformerless floating gate-driver supply subcircuit (VIN SW VB GND, R/C/D/S only, ≤12 parts, ≤2 uF) that regulates Vb = V(VB)−V(SW) to 10.0–13.0 V with bounded ripple, current draw ≤0.2 A and no UVLO or overstress, from any of the three capacitor start states, at any duty 0.05–0.90 at 100 kHz, across stated tolerances.

Why it fits:
• It asks for a physical design decision (a circuit topology with numeric part values), not an analysis of a fixed system; the deliverable is a netlist the agent must invent.
• The whole design is ≤12 elements, so the artifact is small while the design reasoning is not: start-up speed, current limiting, high-duty hold-off, ripple, and history dependence all bind at once.
• Every requirement is stated as a measurable quantity with a limit (time-to-10 V, min/max Vb, re-entry time, spectral bin amplitudes, end-of-cycle delta, source current, part/cap/voltage budgets, timestep convergence), so a script can grade it without a human.
• The harness conventions (Vb definition, settled definition, end-of-cycle sampling, Hann single-sided spectrum, ESR insertion, same-voltage start states) are given in the handbook.

What stops it:
• Structural: nothing structural blocks it — it is a bounded synthesis problem with a specified device set and a specified bench.
• Unresolved feasibility risk (not a structural objection): the numeric window is asserted, not demonstrated. The author's reference outline (30–50 ohm from VIN into ~0.5–1 uF) appears inconsistent with R8 at a 0 V start: 12 V / (30 + 0.5 + 0.3) ohm ≈ 0.39 A, above the 0.2 A limit, before any diode or switch is considered (my arithmetic on the author's stated numbers, not a simulation result). Pushing the resistor above ~60 ohm keeps start-up current under 0.2 A but makes the 200 us time-to-10 V and the 90%-duty hold harder; a current-limited charge path (as in the second listed design family) may be needed. Whether any topology in the permitted set meets R5/R6 (≤60/30/10 mV bins, ≤20 mV end-of-cycle) together with R1/R8 is unknown.
• Unresolved runtime risk: the grader grid (duty pairs both directions, three start states, tolerance corners plus interior points, rail 11.4/12/12.6 V, f 97/100/103 kHz, L 16/20/24 nH, 64-cycle FFT records, plus full re-runs at half step) is a large sweep; each 1 ms record at ≤5 ns sampling is on the order of 10^5–10^6 timepoints. Per-run and total wall time are not established.

How to check it:
• Netlist parse (Python): element types limited to R/C/D/S with the two named models, no IC=/.ic, ≤12 elements, ≤2 uF nominal, .subckt pin order — checks R9.
• ngspice transient: time-to-first-10 V, min/max Vb, 50 ns-averaged source current, capacitor voltages vs 25 V — checks R1, R2, R4, R8, R9.
gspice transient sweeps over duty steps both directions and the 250 us SW-high hold — checks R3, R7.
• ngspice transient records of ≥64 settled cycles fed to a Hann-windowed numpy FFT (single-sided, window-gain corrected) plus end-of-cycle deltas — checks R5, R6.
• Re-run every scenario with the integration step halved and compare min Vb, max Vb and bin amplitudes — checks R10.
Simulation gaps:
• The bench is the specified model, not hardware: diode reverse recovery is explicitly not modelled; the diode has fixed IS/RS/CJO and no leakage or temperature dependence; the switch is ideal RON/ROFF with a fixed threshold and hysteresis; ESR is a fixed 50 mohm per capacitor; the load is a fixed 1 mA plus a 0.2 A/100 ns pulse.
• The ≤10 mV "other bins" limit sits near the noise floor of a numerical FFT of a switched waveform; aliasing of 20 ns edges and solver ringing can move bin amplitudes, and R10's 20 mV timestep check is the intended guard but does not prove bin-level convergence.
• Real-layout parasitics beyond the stated 20 nH/0.3 ohm loop, gate-drive ground bounce, and diode recovery transients are outside the model; a passing netlist is validated against the model, not against hardware.
Why frontier models fail:
• The design is history-dependent: the same netlist must reach 10 V within 200 us from 0 V, and hold ≥9.0 V after a 250 us SW-high hold, and settle within 300 us after duty steps in both directions — a solution tuned to one natural start state fails the held-out states.
• Several constraints pull in opposite directions (R8 current limit wants a large series impedance; R1 start-up and R7 recovery want a small one; R5/R6 want large capacitance; R9 caps total C at 2 uF), and the duty range 0.05–0.90 plus the 20 nH resonance near 1 MHz add tolerance-corner behaviour that one nominal simulation will not reveal.
• The author's claimed failure mechanism (self-consistency-only verification, caught by R1/R3/R5/R6/R8) is a hypothesis about solver behaviour, not verified evidence; treat it as the design pressure to check, not as a proven property.
Real-world risks:
• Passing the model does not establish hardware behaviour: diode reverse recovery, real driver supply current vs. the 1 mA/20 nC abstraction, and temperature drift of the diode drop are unmodelled and can move Vb by more than the 9.0 V floor.
• The 25 V capacitor budget leaves headroom only under the modelled excitation; 20 V/ns edges plus loop overshoot could exceed it in hardware.
• Components at ±10% capacitance and ±5% rail must be sampled at corners in hardware too; a design that only passes at interior values is fragile.
Milestones (if too big): Not required — one netlist, one grader. If runtime proves too large, split the grader instead of the design task: (1) netlist parse + start-up/current/min-max checks; (2) duty-step and hold checks; (3) settled spectrum and periodicity; (4) halved-step convergence, each with a reduced representative scenario set as a development aid while the full held-out grid remains the acceptance run.
What to change (reshape): • Nothing structural; proceed as written. Keep the device set (R/C/D/S from models.cir) and the single netlist output. Do not widen any limit to make a passing design easier.
Numbers to supply next:
  • Requirement — clarify whether harmonics of 100 kHz above the 10th fall under the ≤10 mV "every other non-DC bin" limit (literal reading says yes; example: 11th harmonic of a 64 mV-pk-pk sawtooth ≈ 1.9 mV).
  • Requirement — R8 filter definition: 50 ns boxcar or moving average of the source current before the 0.5 ohm (example: boxcar, inclusive endpoints).
  • Requirement — the baseline integration step for G5 and its halved value (example: 2 ns → 1 ns), and whether edge-region step limiting is imposed.
  • Verification — the tolerance grid: which corners are mandatory and how many interior random points (example: 2^N corners for C, rail, f, L plus 5 seeded random interior points per scenario).
  • Verification — runtime budget: number of scenarios in the acceptance sweep and measured per-run wall time for one 1 ms record at the stated sampling (needs an actual timing measurement; the reference outline gives none).
  • Verification — reproduce a baseline failure of one public design (e.g. plain bootstrap diode + capacitor) and demonstrate one passing reference run, including a start from 0 V, to show the window is non-empty and the R8 arithmetic tension is resolved (e.g. by a current-limited charge path).
  • Interface — confirm /app/input_assets/models.cir exists on disk with exactly the quoted models (the embedded text establishes supplied text, not asset availability or validity); example output: /app/output/gate_supply.cir containing `.subckt GATE_SUPPLY VIN SW VB GND` with one element per line.
  • Interface — output schema is given; confirm that checker-side added series ESR counts toward the 12-part and 2 uF caps or not (example: excluded, since the checker inserts it).
  • Handbook data — device models (given: DBOOT, SWG); confirm no additional allowed parts (e.g. no dependent sources, no ideal transformers) and the diode polarity convention relative to the netlist node order.
Evidence status: Draft-only input. All limits, tolerances and grader methods are stated requirements or author claims; no filesystem inspection, no ngspice execution and no passing design run are in evidence. The reference outline is a proposed solution that the author explicitly marks as unverified, and its 30–50 ohm resistor range appears to conflict with R8 at a 0 V start by simple arithmetic. Claimed public-design failures and the self-consistency failure mechanism are unverified hypotheses.
Checks before full-task readiness: 1) Confirm models.cir exists and matches the quoted content. 2) Reproduce at least one listed public-design failure under the harness. 3) Demonstrate one reference netlist passing at least R1/R2/R4/R8 from a 0 V start and one held-out duty, with measured runtime. 4) Measure per-scenario wall time and total acceptance-sweep time. 5) Resolve the R5 harmonic-bin ambiguity and the R8 filter convention. 6) Check timestep convergence at the proposed base step on one spectrum scenario before fixing the G5 numbers.