I need a one-bit retention storage cell for an always-on sensor hub. In standby the cell sits on a slowly modulated supply, and our power firmware infers cell health from the supply-current trace. The trace must be a constant level plus a supply-synchronous ripple and must not creep as the devices age, and the bit must survive standby and read correctly on wake. I need a transistor-level cell.

Fixed interface: subcircuit RETCELL with ports VDD VSS BN BP D WE Q, in that order. Every NMOS bulk goes to BN and every PMOS bulk to BP. D is data in, WE is write enable (active high), Q is the read output, loaded with 10 fF to VSS. Use only the models in /app/input_assets/models.lib (nmos_g, pmos_g, nmos_hv, pmos_hv), referenced by name, and do not include the library in your file. Allowed elements: at most 14 MOSFETs (L >= 60 nm, 120 nm <= W <= 2 um) and at most 2 ideal resistors (100 Mohm to 20 Gohm). No sources, capacitors, diodes or behavioural elements. Temperature is 27 C. Logic levels for D and WE are 0 and 1.0 V.

Operating conditions: Active supply is 1.0 V. Standby supply is V(VDD) = 0.60 V + 0.100 V * sin(2*pi*t/100 us + phi), with phi anywhere in 0 to 2*pi, so 200 mV peak to peak. The window is 2000 modulation periods (200 ms) and starts after the supply has sat at 0.60 V for 5 ms. Ageing over the window is a linear ramp of forward body bias on BN (relative to VSS) and on BP (below VDD), from 0 up to a final value between 0.05 and 0.07 V; I will also check with no ramp. The wake-up is a linear supply ramp from the standby level to 1.0 V in 200 ns.

Requirements (D and WE held low in standby; each holds for a stored 0 and a stored 1):
R1. Write: with WE high for 10 ns at 1.0 V, Q is within 0.1 V of the written level 20 ns after WE rises.
R2. Residual: fit the raw VDD supply current (positive into VDD) over the full window with exactly a constant plus one sinusoid at the modulation frequency (amplitude and phase free, no other terms). RMS residual divided by the constant is <= 0.05, with and without ageing.
R3. The fitted constant is between 40 pA and 150 pA.
R4. Fitted sinusoid amplitude divided by the constant is between 0.05 and 0.50.
R5. Retention: at the lowest-supply instant in the last modulation period, Q is >= 0.7*V(VDD) for a 1 and <= 0.3*V(VDD) for a 0.
R6. Wake read: 20 ns after the wake ramp ends, Q is >= 0.9 V for a 1 and <= 0.1 V for a 0.
R7. Peak current into VDD during the wake ramp and the 50 ns after it is <= 150 uA.
R8. Netlist obeys the element, size, bulk and port rules above.

Deliver /app/output/cell.sp: a SPICE netlist containing the RETCELL subcircuit and nothing else.
