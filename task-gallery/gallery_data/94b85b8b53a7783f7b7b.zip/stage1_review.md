### 07 · Drift-free standby retention cell — advance, rank 8

Design decision as written: yes — "I need a transistor-level cell" / "Deliver /app/output/cell.sp: a SPICE netlist containing the RETCELL subcircuit and nothing else."

Forge task: Design a <=14-MOSFET (+<=2 ideal Gohm resistors) one-bit retention cell as a SPICE subcircuit RETCELL VDD VSS BN BP D WE Q, using only nmos_g/pmos_g/nmos_hv/pmos_hv, that writes at 1.0 V, holds both bits through a 200 ms supply-modulated (0.60 V + 0.100 V sin, 10 kHz) standby window with a 0-0.07 V body-bias ageing ramp, reads back after a 200 ns wake ramp, and whose raw VDD current over the window fits constant + one sinusoid at the modulation frequency within RMS/c <= 0.05, c in 40-150 pA, A/c in 0.05-0.50, wake peak <= 150 uA.

Why it fits:
• It is a physical design decision (transistor sizing and topology) whose every stated requirement is checked by scripted transient simulation: write/read levels (R1, R6), spectral fit of the supply trace (R2-R4), retention margin at the lowest supply instant (R5), wake inrush (R7) and netlist rules (R8).
• The difficulty is real engineering, not hidden rules: sub-pA leakage budgeting against ageing-driven Vth shift, resistive-bleed dominance versus ripple band, loop gain of a cross-coupled pair at 0.5 V, and displacement current from a nonlinear-C node — a multi-constraint analog trade-off frontier models typically get wrong.
• Bounded output: one netlist file; topology freedom is preserved (grader accepts any compliant topology).

What stops it:
• Structural: none — no analysis-only or out-of-scope-tool element.
• Unresolved feasibility risks (not structural objections): (a) no passing reference exists yet — the reference_outline is a proposed solution, not a passing design, and the limits are explicitly "provisional to be calibrated"; (b) runtime of a 200 ms transient at sub-fA abstol with a bounded max step is unmeasured — if one run takes >10 min, the iterative design loop inside ~2 h is at risk; (c) the 0.05 RMS/c band against a 1.4-1.8x drift is only plausibly reachable via resistor-dominated offset, which then pressures R3/R4 — the working window is asserted narrow but never demonstrated.

How to check it:
• ngspice (headless, BSIM3v3 level=8 from /app/input_assets/models.lib): transient of write, 5 ms settle, 200 ms modulated standby with body-bias ramp, 200 ns wake ramp; samples i(VDD) and Q at the stated instants.
• Python/numpy: least-squares fit of i(t) to constant + a*sin + b*cos at the modulation frequency over the full window; RMS/c, c, A/c; peak wake current — matching the grader plan (G1-G5), which is a plan, not implemented evidence.
• Static parse (Python): R8 element counts, model names, L/W ranges, bulk nodes, port order, forbidden elements.
• What a simulation would get wrong: BSIM3v3 here omits gate/junction tunnelling and all mismatch/variation, so the absolute pA floor and its bit-to-bit asymmetry are optimistic versus silicon; the fit's numerical noise floor (must sit well below 0.05*c, i.e. a few pA RMS) is uncharacterised; angular discretisation and max-step choice can alias harmonics into or out of the residual.

Simulation gaps:
• Numerical: need abstol/gmin/max-step settings that reproduce a sub-pA noise floor below ~1 pA RMS on a known-current test case; current tolerances in the plan ("1%") are tight relative to a 40 pA floor and may be dominated by solver noise.
• Physical: single temperature (27 C), no process corners, no device mismatch, ideal zero-TC resistors; 100 MOhm-20 Gohm on-chip resistors are area-impractical in a real 65 nm flow — the scenario is a modelling abstraction.
• Behaviour through the cycle is checked at four instants (write, min-supply, post-wake, wake peak); slow internal-node relaxation between instants enters the fit but is not separately bounded.

Why frontier models fail:
• Author hypothesis (mechanism_survival), unverified: a solver fitting its own basis can absorb secular drift with an extra linear term and see a clean trace while the grader's fixed two-term basis does not — self-checking masks the failure.
• Engineering reasons: simultaneous satisfaction of R2/R3/R4 requires a resistive current floor dominating an ageing-sensitive leakage floor while keeping ripple in a 10x band and retaining loop gain at 0.5 V under 0.07 V body bias; small devices, DIBL-dependent asymmetry and displacement-current harmonics from voltage-dependent junction caps all push on the same budget.

Real-world risks:
• Ideal Gohm resistors and tunnelling-free models make absolute pA currents a simulation artefact rather than a silicon-realistic target; a fabricated cell would show gate leakage dominating and different ageing behaviour (NBTI/HCI, not a body-bias ramp).
• The premise (firmware inferring cell health from a supply-current trace) is unvalidated; no evidence it discriminates ageing in hardware.

Milestones (contingency if measured runtimes exceed the run budget):
1. Retention/write/wake cell: netlist meeting R1, R5, R6, R7, R8 only — grader checks the four levels/peak on a 200 ms transient.
2. Standby-current shaping: add resistor/bleed design to meet R2, R3, R4 on the same topology — grader runs the fit on the raw trace with held-out ramp finals and phi.

What to change (reshape): nothing structural. Keep the same device and core decision; only supply the numbers below and confirm runtime before freezing the task.

Evidence status: draft-only. The model cards are supplied text (existence of /app/input_assets/models.lib is a specified dependency, not inspected); reference_outline, distinct_valid_designs, public-design failure claims, the 1.4-1.8x ageing multiplier, the 0.29*D residual relation and the stated leakage bands are author claims or handbook-style modelling notes, not verified measurements. No reference netlist, no simulation output and no runtime data were supplied or executed here. Checkability is plausible in principle (ngspice implements BSIM3v3 level=8), not demonstrated.

Checks before full-task readiness:
• Simulate a candidate passing reference and show it meets R1-R8 with margin (esp. R2 and R3/R4 simultaneously); reproduce at least one claimed baseline failure (e.g. the minimum-size latch on R2) to validate that the catching row actually catches.
• Measure one full 200 ms transient wall time and the whole grader matrix (2 bits x ramp finals x phi) on the target machine; verify the fit residual noise floor with an analytic-current testbench.
• Confirm the calibration of the provisional limits against the reference, per the author's own note — without widening limits merely to admit a passing design.

Numbers to supply next:
• Requirement: confirm or calibrate the provisional limits after a passing reference — e.g. keep R2 <= 0.05 and R3 40-150 pA only if the reference passes each with >=2x margin; report the reference's actual RMS/c, c, A/c.
• Requirement: write/standby handoff timing — e.g. write at 1.0 V, then supply transition to 0.60 V as a 1 us linear ramp, then the stated 5 ms settle before the window; also specify when WE and D fall (e.g. 10 ns after the write pulse ends).
• Requirement: simulation settings as a spec, not just practice — e.g. abstol 1e-15 A, gmin 1e-18 S, max step 1 us, trap/gear integration, and the resampling grid (20 us).
• Requirement: retained-value sequence for the aged window and wake (e.g. bit written once before standby; WE=D=0 throughout standby and wake), and whether both bits are tested in the same or separate runs.
• Interface: inputs /app/input_assets/models.lib (as supplied); output /app/output/cell.sp with exactly `.subckt RETCELL VDD VSS BN BP D WE Q` ... `.ends`, instance parameters `m`/`w`/`l` and `r` values with SPICE suffixes — the existing output schema is adequate; additionally name the grader bench file or state that the grader builds its own bench from cell.sp.
• Handbook data: supplied BSIM3v3 cards stand as the model source; additionally confirm ideal-resistor semantics (zero TC, linear) and provide the body-effect coefficient gamma/n-factor reference values used to predict the 13-20 mV Vth drop at 0.05-0.07 V bias so a solver can pre-size devices.
• Verification still needed (distinct from missing specs): a passing reference netlist, a failing-baseline reproduction, measured runtimes, and a measured numerical noise floor for the pA-level fit.