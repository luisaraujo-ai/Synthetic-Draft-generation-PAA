Hi, our system team is adding a pulsed ultrasonic transducer drive stage to the existing 12 V board, and I need the board-side network sized. The drive clock (3.3 V, 50 % duty, 2 ns edges) drifts anywhere in 4.8 to 5.2 MHz. The stage has to come up settled and phase-locked every time, with no retuning.

Fixed parts are in /app/input_assets/fixed_parts.cir: the 12 V harness and source, the half-bridge stage with its stacked low-side pair, and the resonant load tank (which contains the 1.2 ohm load resistor). Nothing in that file may change.

Deliver /app/output/design.json with these fields:
- rail_caps: list of at most 6 objects {c_uF 0.1 to 10, esr_mohm 3 to 300, esl_nH 0.5 to 4}. Each is a capacitor with its series ESR and ESL, from the rail node to ground.
- snubbers: list of at most 2 objects {node one of "rail","sw","tin","mid", r_ohm 0.1 to 100, c_nF 0.1 to 100}. Each is a series R-C branch from that node to ground.
- r_series_ohm (0 to 5): between the stage switch node sw and the tank input tin.
- r_gate_ohm (1 to 100): between the inverted-clock node clkb and the stack gate node gl.
- c_mid_nF (0 to 10): from the stack middle node mid to ground.

Every simulated run lasts 150 clock cycles from the start (or from the step, for R3, which is applied after 150 settled cycles and also run for 150 cycles). Every requirement below must hold at every clock frequency in the band, with rail 11 to 13 V, tank inductance and capacitance each within plus or minus 3 %, every rail capacitor at minus 30 % of its stated value, and for any start state described.

R1. Cold start (all tank and stack states zero, rail capacitors charged to the rail voltage): settling time at most 60 clock cycles.
R2. Perturbed start (tank inductor current and capacitor voltage set to a random state of either polarity holding up to 50 % of the final peak tank stored energy, 0.5*L*Ipk^2 + 0.5*C*Vpk^2 with the final clock-frequency amplitudes Ipk and Vpk): settling time at most 60 clock cycles, and the tank-current waveform over cycles 110 to 130 must match the cold-start waveform over the same cycles, i.e. RMS of the pointwise difference divided by RMS of the cold-start waveform at most 5 %.
R3. Clock step between any two frequencies in the band at least 250 kHz apart, applied after the design has settled: re-settling time at most 70 clock cycles, with no cycle slip, meaning exactly one sw falling 6 V crossing in every clock cycle from 10 cycles after the step to 60 cycles after it.
R4. Periodicity: sqrt(mean over time of (i(t) - i(t+20T))^2) over window 90 to 110 cycles, divided by sqrt(mean over time of i(t)^2) over that same window, at most 1 %. Here i is the tank inductor current and T the clock period.
R5. Phase lock: spread (max minus min, after removing a linear trend) of the sw falling-edge 6 V crossing time relative to the clock edge over cycles 110 to 150, at most 3 degrees of clock period.
R6. Rail ripple: peak-to-peak voltage at the rail node over cycles 110 to 150, at most 150 mV.
R7. Efficiency: mean power in the 1.2 ohm load resistor divided by mean power delivered by the 12 V source terminals, over cycles 110 to 150, at least 42 %.
R8. The file parses, respects the part counts and ranges above, and every simulation completes without non-convergence.

Definitions: the tank-current envelope is the amplitude of its clock-frequency component in each clock cycle. Settling time is the number of cycles after the start (or step) until the envelope stays within 5 % of its final value, where final is the mean over the last 10 simulated cycles (cycles 140 to 150). Cycle 0 begins at the clock start or step.
