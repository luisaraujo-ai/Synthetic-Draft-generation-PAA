### 06 · Resonant drive board network across a drifting clock band — advance, rank 8

Design decision as written: yes — "Deliver /app/output/design.json with these fields: rail_caps ... snubbers ... r_series_ohm ... r_gate_ohm ... c_mid_nF" and "The stage has to come up settled and phase-locked every time, with no retuning."

Forge task: Size the board-side network for a pulsed half-bridge resonant ultrasonic drive — at most 6 rail capacitors (C/ESR/ESL), at most 2 RC snubbers, a series damping resistor, a gate resistor and a mid-node bypass — so that the fixed stage and tank settle within 60 cycles from cold and perturbed starts, re-lock without cycle slip after a clock step, meet periodicity and phase-lock limits, keep rail ripple ≤ 150 mV and deliver ≥ 42 % efficiency, at every clock in 4.8–5.2 MHz over rail 11–13 V and L/C ±3 % corners.

Why it fits:
• The deliverable is a set of component values that change real physical behaviour of a built circuit — not an analysis, not a solver, not a report.
• Every requirement is a deterministic output of a transient simulation of a fully specified netlist (fixed_parts.cir + design.json), so a script can check function, drive integrity and power balance with no human in the loop.
• The design tension is real engineering: damping shortens the envelope time constant (R1/R2/R4) but directly eats the Rl/Rtotal efficiency share (R7), and the added knobs (r_gate, c_mid, snubber placement, rail bank) couple stack edge timing to body effect and rail ringing.
• It is self-contained: one input netlist, one JSON output, ngspice as the only tool.

What stops it:
• Structural: none — the task is a bounded parameter-selection problem over a fully specified model.
• Unresolved feasibility risk (not verified): the claimed window of total series resistance ~2.5–2.85 ohm is author arithmetic from the handbook, and the handbook's own reference outline states "Thresholds are provisional until a reference simulation is run." The 1.2/Rtotal efficiency share ignores switching loss into Csw/Cgd, rail ESR/ESL loss, and edge loss, which are counted as input power in R7; at band edges where the handbook says current is "several times lower", fixed switching losses are a larger share of input power and could push R7 below 42 % precisely where the clock is most detuned.
• Unresolved runtime risk: 150 cycles at 5.2 MHz is ~29 us of transient at a forced max step of T/400 (~0.48 ns) — on the order of 6e4 accepted points per run, times ~5 held-out frequencies x both band edges x L/C ±3 % combinations x rail extremes x caps −30 % x two integrators x two step sizes x cold/perturbed starts, plus the R3 step runs. That is plausibly 100+ ngspice runs. Measured per-run wall time is unknown; if a run takes more than ~30–40 s the full self-check matrix will not fit a two-hour loop.
• Unresolved spec risk: R2's perturbed start says "a random state" — the number of seeds, the sampling distribution of the 50 %-energy state, and whether the orbit comparison is time-aligned are not stated.

How to check it:
• ngspice: build the netlist from fixed_parts.cir plus design.json; run 150-cycle transients and extract the per-cycle tank-current envelope (settling, R1/R2), perturbed-vs-cold RMS orbit mismatch (R2), clock-step re-settling and sw falling-6V-crossing counts (R3), the 20T periodicity ratio (R4), detrended sw crossing spread (R5), rail peak-to-peak (R6), and mean power in Rl vs mean source power (R7); repeat with trap and gear integration at T/200 and T/400 and across held-out frequencies and corners.
• Python: schema/part-count/range validation of design.json (R8).
What a simulation would get wrong: Level-1 MOSFET with no gate charge, no package or layout inductance, no temperature; ideal C+ESR+ESL capacitors with no DC-bias derating; behavioral sources that deliver gate-drive power from nowhere, so R7's denominator excludes gate-drive consumption that a real board would pay; the SHS ideal switch; discrete corner sampling is not proof over the continuous 4.8–5.2 MHz band; forced time steps can mask or manufacture edge-sensitive behaviour.

Simulation gaps: see above; additionally the envelope demodulation method (per-cycle DFT, Hilbert, or peak detect) is unspecified and changes settling counts near a 5 % boundary, and numerical noise between T/200 and T/400 must be characterized before a 1 % R4 or 3° R5 limit can be treated as resolvable.

Why frontier models fail: the damping window is narrow and efficiency moves opposite to settling, so a design tuned on nominal corners sits on the edge and fails held-out L +3 % / 5.2 MHz / caps −30 % cases (author hypothesis, not trial-verified); passing requires deliberately giving up efficiency margin for robustness, which an agent optimizing for R7 alone will not do. The start-up beat between the tank natural frequency and the clock only decays at tau, the same time constant the budget constrains; body-effect-dependent stack turn-off interacting with r_gate/c_mid can create edge glitches, cycle slips and rail spikes that only appear across corners; R2 additionally forces a unique converged orbit.

Real-world risks: ceramic capacitance loss under 12 V DC bias not modeled; layout ESL beyond the assumed ~1 nH; level-1 on-resistance and switching loss optimistic/pessimistic vs silicon; thermal rating of the damping resistor and snubbers (0.9 ohm at ~2 A RMS is ~3.5 W of dissipation — real parts and copper area needed); gate-drive power not counted in R7; solder and harness parasitics beyond the fixed 50 mohm/100 nH.

Milestones (if too big): 1. Damping-window selection at nominal corners: a design.json meeting R1/R7 at 5.0 MHz, 12 V — grader checks settling ≤ 60 cycles and efficiency ≥ 42 %. 2. Band-and-corner robustness with gate/mid tuning: same file extended to held-out frequencies and L/C ±3 %, R1–R5. 3. Rail bank sizing: R6/R7 with caps −30 % and rail 11/13 V. Each milestone is standalone only if measured per-run time forces a split; otherwise one run is plausible.

What to change (reshape): none required at Stage 1. If measured runtimes force it, split into the three milestones above; do not relax limits to obtain a passing design.

Evidence status: draft-only. All requirements, handbook values, reference outline, public-design failure claims and the 2.5–2.85 ohm window are stated requirement or author claim; the embedded fixed_parts.cir text establishes supplied text, not physical fidelity; no simulation has been run and no artifact has been inspected. The feasible window, the claimed failure modes of public designs, and two-hour fit are unverified hypotheses. My own arithmetic (tau = 2L/Rtotal = 3.55 us at Rtotal 2.65 ohm vs 60 cycles = 11.5 us at 5.2 MHz; 1.2/2.65 = 45 % nominal load share) supports plausibility only.

Checks before full-task readiness:
• Run one reference design through the full grader matrix and confirm it passes all of R1–R8; record actual margins on R1, R4, R7.
• Reproduce at least one claimed public-design failure (e.g. undamped tank missing settling) to validate the harness and metric extraction.
• Measure per-run ngspice wall time and total corner-matrix time; trim the agent's self-check set to fit ~2 hours.
• Characterize numerical noise between T/200 and T/400 and between trap/gear for a reference design; confirm R4's 1 % and R5's 3° are above the noise floor.
• Verify efficiency decomposition (load vs stack vs harness vs rail network vs switching) at the band edges to confirm R7 is achievable where the clock is most detuned.

Numbers to supply next:
• Requirement: number of random perturbed-start seeds per case and the sampling rule — e.g. 8 seeds, energy drawn uniform in [10 %, 50 %] of final peak stored energy, both polarities, fixed seed list for the grader.
• Requirement: envelope demodulation and settling edge conventions — e.g. per-cycle DFT of i(t) at the clock frequency, settling counted in whole cycles, first cycle whose envelope is within 5 % of the cycle-140–150 mean and stays there.
• Requirement: corner enumeration for the pass rule — e.g. all four combinations of L ±3 % and C ±3 % at each of 5 held-out frequencies, rail 11/12/13 V, rail caps at nominal and −30 %; state whether these are crossed or one-at-a-time.
• Requirement: tolerance of the added network parts — e.g. r_series, r_gate and snubber R/C treated as exact values as written in design.json (no tolerance).
• Requirement: clock convention — e.g. clk starts with a rising edge at t = 0, 50 % duty, 2 ns edges, and the R3 step occurs on a rising edge 150 cycles after the start.
• Interface: input files /app/input_assets/fixed_parts.cir (fixed) and /app/output/design.json (schema exactly as specified: rail_caps[{c_uF,esr_mohm,esl_nH}], snubbers[{node,r_ohm,c_nF}], r_series_ohm, r_gate_ohm, c_mid_nF); the grader-built netlist and per-case metrics JSON (settling cycles, orbit mismatch %, slips, periodicity %, phase spread deg, ripple mV, efficiency %) — e.g. {"case_id": "f5.043_L+3_C-3", "metrics": {...}, "pass": true}.
• Handbook data: capacitor part classes with typical ESR/ESL — e.g. 10 uF X7R 25 V, ESR 3–20 mohm, ESL 0.5–2 nH, as already stated; confirm whether DC-bias derating is applied (currently not).
• Verification still needed (not spec): reference-passing design through the full matrix, baseline-failure reproduction, per-run runtime measurement, integrator/step noise floor.