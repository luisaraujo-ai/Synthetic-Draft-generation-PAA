I need a 3.3 V input block for a sensor-board radio that transmits in bursts. It runs from an adapter-plus-battery rail that is soft and noisy. We have had field resets from rails that ring or settle into a different pattern depending on how the board was powered up, so the numbers below must hold from any starting charge state.

Fixed: the source is 4.5 to 5.5 V open-circuit behind 1.0 ohm. The load is an ideal current sink on vout, either constant at 20 to 600 mA, or a burst between 50 and 600 mA (30% duty, 1 us edges, burst rate anywhere in 8 to 14 kHz). Use only the parts in components.json and models.lib. Capacitors vary by +/-10% and inductors by +/-15%, in any combination. Use at most 25 parts and 150 mm2. The ports are vin, vout, gnd. The 'rail signal' is vout low-passed at 200 kHz, zero-phase. Every requirement below holds over the whole source range, burst-rate range and tolerance range.

Requirements:
R1: raw vout stays within 3.201 to 3.399 V at constant 20 mA and at constant 600 mA.
R2: cold start (all capacitor voltages and inductor currents zero, source ramped to its value in 1 ms, burst load running from t=0): the rail signal is inside 3.3 V +/-3% and stays there from at most 5 ms after the ramp starts.
R3: cold start: rail signal peak at most 3.45 V.
R4: warm restart, with capacitor voltages anywhere in 0 to 3.6 V and inductor currents anywhere in 0 to 1 A, otherwise as R2: the rail signal is inside the window from at most 8 ms.
R5: warm restart: over the last burst period before 20 ms, the rail signal differs from the cold-start run (same burst rate, source and tolerances) by at most 5 mV at any instant.
R6: burst load: raw vout ripple at most 60 mV pk-pk over the burst periods between 15 and 20 ms.
R7: burst load: |rail(t+Tb) - rail(t)| at most 5 mV for all t between 15 and 20 ms, where Tb is the burst period.
R8: load step 20 to 600 mA in 1 us: raw droop below the pre-step value at most 120 mV.
R9: the same step: the rail signal returns within +/-1% of the pre-step value in at most 100 us and stays inside it for the next 2 ms.
R10: constant 300 mA load, the source falls to 3.8 V in 50 us, holds 2 ms, then recovers in 50 us: raw vout stays at or above 3.135 V throughout.
R11: the same event: from 100 us after recovery ends for 2 ms, the rail signal stays within 40 mV of its pre-dropout value.
R12: a 50 mV pk-pk sine at any frequency from 100 kHz to 1 MHz on the source, 300 mA constant load: the output component at that frequency is at most 5 mV pk-pk.
R13: the burst ripple, the mean rail and the R5 difference each change by at most 2 mV when the time resolution of the evaluation is made twice as fine.
R14: at 5.5 V source and constant 600 mA, average dissipation in any single active device or resistor is at most 0.8 W.
R15: the parts list has at most 25 parts and at most 150 mm2 in total.

Deliver /app/output/design.sp, a SPICE netlist with a .subckt DESIGN vin vout gnd. It may reference only the models.lib subcircuits, resistors and the parts in components.json. Deliver /app/output/parts.json, a JSON list of {ref, class, value} for every instance, with refs equal to the netlist instance names.
