### 27-27 · Burst-radio 3.3 V rail from any start state — advance, rank 7

Design decision as written: yes — "I need a 3.3 V input block for a sensor-board radio that transmits in bursts... Deliver /app/output/design.sp, a SPICE netlist with a .subckt DESIGN vin vout gnd"; the deliverable is a circuit topology and part selection, not an analysis.

Forge task: Synthesize a 3.3 V input block (buck, LDO, or combination) from the allowed components.json parts and models.lib subcircuits, with chosen damping, compensation and start-up behaviour, meeting R1–R15 on regulation, cold/warm-start settling and convergence, burst ripple, periodicity, load step, dropout, injected-sine rejection, timestep convergence, device dissipation and part/area limits; output a SPICE netlist plus a matching parts list.

Why it fits:
• It asks for a design artifact (netlist + parts.json) whose topology, inductor/capacitor choice, damping branch and compensation are the engineer's decision; every row is a numeric pass/fail a script can compute.
• ngspice can run the wrapped transients headless; scipy can apply the zero-phase 200 kHz Butterworth, compute ripple, periodicity and Fourier amplitude; Python can parse the netlist and sum area (R15).
• The rows are genuinely coupled: damping buys R4/R5/R7/R11/R13 but costs R8 droop, R6 ripple, R14 dissipation and R15 area; a diode buck loses headroom against R10 dropout; fsw trades R7 filtered ripple against R13 timestep convergence (100 ns max step is only ~10 points per 500 kHz cycle, ~5 per 2 MHz cycle).
• Held-out burst rates (8.6–13.4 kHz), source voltages, tolerance draws and warm states reward a design that is robustly contractive, not one tuned to a single nominal run.

What stops it:
• Structural objection: none — this is design synthesis with scripted checking, not analysis or measurement.
• Unresolved feasibility risks: (a) models.lib is supplied text only and has not been shown to run: CAP uses `ddt()` inside a behavioural source and IND uses `tan()` with `max/min` clamping, both non-smooth; parsing and convergence, especially from imposed warm states on CAP n2 / IND ph nodes, must be demonstrated in the pinned ngspice version. (b) Runtime arithmetic does not yet establish a two-hour fit: one 25 ms run at max step 100 ns is ≥2.5e5 timepoints, and the handbook's "seconds to minutes per case" is an author claim; 30–50 corner cases at 1–3 minutes is 30–150 minutes of simulation alone, before design and debugging. (c) No passing reference design has been simulated (reference_outline is explicitly "not yet run"), so R5's 5 mV warm-vs-cold match and R7's 5 mV periodicity against non-commensurate switching ripple are plausible, not demonstrated: after a 200 kHz 2nd-order LPF, residual ripple must be only a few mV, which pushes fsw up and R13 down. (d) R12 (≤5 mV pk-pk at 1 MHz from a 50 mV pk-pk source through 1 Ω) is a demanding PSRR target where the EA loop is out of band and ESL dominates the ceramics. (e) The claimed failures of the listed public designs are author hypotheses, unverified.

How to check it:
• ngspice: transient runs with verifier-built source, 1 Ω source resistance, constant and burst current sinks, initial states imposed on CAP n2 and IND ph nodes, for R1–R11 and R14; Fourier extraction over integer cycles after 3 ms for R12.
• scipy: zero-phase 2nd-order Butterworth at 200 kHz for the rail signal, pk-pk and |rail(t+Tb)-rail(t)| metrics, warm-vs-cold difference, and the 100 ns vs 50 ns comparison for R13.
• Python: parse design.sp/parts.json, check instance refs, table-row parameters (0.1%), resistor range, part count and summed area for R15.

Simulation gaps:
• Behavioural models only: no layout parasitics, thermal model, core loss, temperature or ageing, real ESR/ESL drift, EMI, or a real radio load (the load is an ideal current sink); PASS and SW are idealized conductances and EA is a single pole, so loop stability margins are inferred, not measured.
• The 200 kHz filtered rail deliberately hides switching ripple, so a design can pass R2–R5/R7/R9/R11 and still put millivolts of raw ripple at the radio.
• R13 measures solver convergence, not physical accuracy; a design can agree at 100 ns and 50 ns yet be wrong versus finer integration or hardware. Tolerance is one scalar per part, not a real distribution.

Why frontier models fail: hypothesis, untested — the trap is self-consistent simulation at nominal values, one burst rate and zero initial states, which plausibly shows all rows passing while verifier-held warm states, off-nominal burst rates and derated LC corners reveal slow ringing, distinct periodic orbits and subharmonic content (R4/R5/R7/R11), and limit-cycle jitter breaks R13; fixing these costs damping, which collides with R6/R8/R14/R15.

Real-world risks: no loop-gain/stability verification; dropout behaviour of a diode buck near D≈0.95 at Vin=3.8 V; 0.8 W per device leaves little thermal margin in a small board block; real startup into a radio's dynamic impedance may differ from an ideal sink; component derating and lifetime unmodelled.

Milestones (if measured runtime exceeds one run):
1. Steady-state and step block (R1, R6, R8, R9, R14, R15): supplied netlist graded on constant loads, burst ripple, load step, dissipation and area.
2. Start-state robustness (R2–R5, R7): cold/warm sweeps at held-out burst rates, source voltages and tolerance corners.
3. Dropout, injection and convergence (R10–R13): source dropout profile, 100 kHz–1 MHz injection, and 100 ns vs 50 ns comparison.
Each milestone would need its own starting files, grader and a reference design.

What to change (reshape): • Nothing structural at Stage 1; pinning down runtime, corner counts and the wrapper template is specification work, not a reshape. • If measured per-case runtimes make the full sweep exceed roughly two hours, split into the three milestones above rather than trimming requirements.

Numbers to supply next:
• Requirement: verification case budget and measured runtime — e.g., number of random tolerance corners per grader (say 8 random + 2 extremes), burst-rate samples (say 5 values between 8 and 14 kHz), warm-state seeds (say 6), and measured ngspice wall time per 25 ms / 100 ns run (need ≤60 s to plausibly fit).
• Requirement: simulator settings — e.g., ngspice TRAP with maxstep 100 ns and 50 ns for R13, specified reltol/abstol, and the metric window for "mean rail" (e.g., mean over 15–20 ms).
• Interface: exact wrapper template — source ramp subcircuit, 1 Ω series resistance, burst load definition (30% duty, 1 µs edges, phase 0 at t=0), .ic syntax for CAP n2 and IND ph, and the transient output schema (e.g., ASCII columns time, v(vout) at ≤100 ns spacing).
• Interface: outputs confirmed as /app/output/design.sp (`.subckt DESIGN vin vout gnd`) and /app/output/parts.json (`[{"ref","class","value"}]`), with value semantics (c0/l0/ohm/f) and the parameter-match tolerance (e.g., 0.1%).
• Handbook data: confirmed support in the pinned ngspice build for `ddt()` in B-sources and the clamped `tan()` IND model, plus a smoke-test bench showing models.lib parses and a trivial circuit converges from imposed warm states.
• Verification still needed (not specifications): a reference design run through G1–G9 showing the limits are attainable, especially R5 (5 mV warm-vs-cold), R7 (5 mV periodicity), R12 at 1 MHz and R13 (2 mV at halved timestep); and a baseline reproduction of one claimed public-design failure (e.g., undamped ceramic LC failing R7) to confirm the rows discriminate as claimed. Never widen a limit to obtain a passing design.

Evidence status: Draft-only author content. Requirements and units are stated specifications; components.json/models.lib are supplied text establishing the declared library, not validated simulator behaviour. reference_outline, budget_fit, "seconds to minutes per case", distinct_valid_designs and public_design failure claims are unverified author assertions; no simulation was run and no filesystem was inspected, so no design is known to pass and no runtime is measured. Rank reflects idea value subject to these unresolved assumptions.