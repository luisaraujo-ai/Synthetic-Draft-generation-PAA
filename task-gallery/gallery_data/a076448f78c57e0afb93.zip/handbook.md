## Fixed parts (as in fixed_parts.cir)
Transducer: series Rm 300 ohm, Lm 9.55 mH, Cm 66.3 pF (series resonance about 200 kHz, bare Q about 40) in parallel with a 470 pF port capacitance. The antiresonance is near 213 kHz. The clamp is two anti-parallel strings of five identical diodes (IS 1e-12, N 1.8, RS 1 ohm, CJO 4 pF, BV 30 V). Each string starts conducting noticeably at about 4.5 to 5 V peak, and the current rises roughly tenfold per 8 percent rise in voltage amplitude.

## Useful background
- Power available from the source into a matched load is Vpk^2/(8*50) = 62.5 mW. Voltage at a resistive port of equivalent parallel resistance Rp cannot exceed sqrt(2*P*Rp).
- The motional branch is driven from the Thevenin impedance of the source plus network. The envelope time constant is 2L/(Rm+Rth), and loaded Q = omega*L/(Rm+Rth).
- A lossless reactive network can transform the 50 ohm source to a higher effective source resistance, which sets loaded Q and amplitude together.
- Frequency drift of 3 percent either side is a large fraction of the bare transducer bandwidth (about 5 kHz).
- Ideal elements: no parasitics. Source phase starts at zero at burst start.

## Measurement definitions
- Steady state: analysed over a window of 20 whole source cycles starting after cycle 60.
- Fundamental amplitude: the peak amplitude of the Fourier component at the drive frequency over that window.
- THD: sqrt(sum of squared harmonic amplitudes, orders 2 to 10) divided by the fundamental amplitude.
- Envelope: the peak absolute value of OUT in each source cycle. The envelope settles at cycle N if it stays within 2 percent of its steady-state value from cycle N onward.
- Periodicity error: RMS of (v(t) - v(t - 10T)) over a 10-cycle window starting after cycle 60, divided by the RMS of v over the same window.
- Ring-down: the envelope after the source is set to 0 V, relative to the steady amplitude just before.
- Tolerance corners: each element independently takes any value in [nominal*(1-tol), nominal*(1+tol)], including all-low, all-high and mixed extremes.
- Held-out frequencies: points inside 194 to 206 kHz not necessarily on a regular grid, including the centre and band edges.

## Standard series
E12 (1.0 1.2 1.5 1.8 2.2 2.7 3.3 3.9 4.7 5.6 6.8 8.2) and E24 (those plus 1.1 1.3 1.6 2.0 2.4 3.0 3.6 4.3 5.1 6.2 7.5 9.1), times decades. The series come from IEC 60063.

## Practice
A design checked only at a few nominal frequencies, with thresholds placed just inside the limits, is fragile. Frequency offsets, tolerances and different numerical step sizes all move the operating point. Amplitude, clamp conduction and settling interact because the diode current depends exponentially on amplitude.
