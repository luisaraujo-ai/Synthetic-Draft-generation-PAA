We are adding a ruggedised ultrasonic proximity transducer to an existing control board and need the passive interface between the excitation driver and the transducer port. The driver is a 5 V peak sine source with 50 ohm output impedance. Its frequency drifts with temperature anywhere in 194 kHz to 206 kHz. The transducer is lightly damped, and a surge clamp sits permanently across its port. The transducer and clamp models are in /app/input_assets/fixed_parts.cir. Do not modify them. Amplitude at the transducer must stay steady and clean at every frequency in the band, because a ring-up that drifts or never settles corrupts the sensor reading.

Fixed interface: your network is a subcircuit named IFACE with ports IN, OUT, GND. The source drives IN through its 50 ohm. OUT connects to the transducer port, where the clamp also connects. GND is the common return. The network is passive, R, L and C elements only, ideal, at most 10 elements. Values must sit on standard grids: E24 for resistors (1% tolerance), E12 for capacitors (2%) and E12 for inductors (2%). Series or parallel combinations are allowed.

Scope: unless a requirement says otherwise, every requirement holds at every frequency in 194 kHz to 206 kHz, both with nominal parts and with every element at any value inside its stated tolerance. Voltages are at OUT relative to GND.
1. Fundamental amplitude between 3.6 V and 4.7 V peak, measured in steady state.
2. Total harmonic distortion (harmonics 2 to 10 relative to the fundamental) of at most 1.0 percent.
3. Burst start: the envelope is within 2 percent of its final value within 20 source cycles, from a zero initial state and from a transducer starting with 20 mA motional current and 10 V on its motional capacitor.
4. Periodicity: after 60 cycles, the waveform differs from itself shifted by 10 cycles by at most 0.5 percent RMS, relative to the RMS of the waveform.
5. Burst end: when the source drops to zero after an 80-cycle burst, the peak of OUT in the 15th source cycle after the drop (cycle 15 counting the first cycle after the drop as cycle 1) is below 5 percent of the steady amplitude.
6. Resistor power: with the source running at any band frequency, each resistor dissipates at most 0.25 W average in steady state, nominal parts and tolerance extremes.
7. Build limits: only R, L and C, at most 10 elements, values on the stated grids.

Deliverables under /app/output/:
- interface.cir: a SPICE netlist containing the .subckt IFACE IN OUT GND definition and whatever is needed to run it.
- design.json: fields topology_tag (short string) and components (list of objects with ref, type R, L or C, and value in SI units), matching the netlist.
