### 03-03 · Passive drive interface for a clamped ultrasonic transducer across a drifting band — advance, rank 8

Design decision as written: yes — "need the passive interface between the excitation driver and the transducer port" with "Values must sit on standard grids ... at most 10 elements", delivered as ".subckt IFACE IN OUT GND" plus "design.json: fields topology_tag (short string) and components". The agent designs a network; it is not asked to analyse or measure a fixed circuit.

Forge task: Design a passive R/L/C network (max 10 elements, E24 resistors / E12 L and C, SI values) between a 5 V-peak, 50 ohm driver and a lightly damped ~200 kHz transducer with a permanent 10-diode antiparallel clamp, so that across 194–206 kHz and all element tolerance corners the OUT fundamental stays 3.6–4.7 V peak, THD(2–10) <= 1.0%, envelope settles within 2% in <= 20 source cycles from both zero and residual transducer state, 10-cycle periodicity error <= 0.5%, the 15th post-burst cycle peak < 5% of steady amplitude, and every resistor dissipates <= 0.25 W; deliver interface.cir and design.json.

Why it fits:
• Physical design decision: topology and parameter selection for a real board-level interface, with a fixed external system (source, transducer, clamp) the network must be designed against.
• Fully checkable in principle: every requirement is a waveform/power quantity obtainable from headless ngspice transients plus FFT and per-element power averaging.
• Coupled trade-offs give real difficulty: loaded Q sets band flatness, amplitude ceiling, settling and ring-down simultaneously, while the diode clamp couples amplitude exponentially to THD.
• Bounded output: <= 10 ideal elements, explicit schema (topology_tag + components list) cross-checkable against the netlist.
• Internal arithmetic in the brief is self-consistent (my check: series resonance 200.7 kHz, bare Q ~40, port Z ~290-j51 ohm at 200 kHz, P_avail = 25/(8*50) = 62.5 mW) — these are my computations from the stated model, not verified simulation.

What stops it:
• Structural, spec-vs-check gap: R1–R6 say 'every element at any value inside its stated tolerance' (an uncountable corner set). G2/G4/G6 sample 40 draws; a pass on samples does not establish the universal claim. Either narrow the requirement to the named corner/sample set or add an interval/sensitivity argument.
• Unresolved budget risk (arithmetic, not measured): a G2-equivalent sweep is roughly 375 transients x 2 timesteps (each ~80 cycles at T/1000, nonlinear diodes) — plausibly 15–125 minutes of solver time for one gate, before G4/G6 and before the agent's own design sweeps. Runtime per run must be measured before claiming a two-hour fit.
• Unverified assets and claims: /app/input_assets/fixed_parts.cir is text supplied in the draft; I have not inspected the filesystem or run it. The reference outline, the four 'public designs fail' statements, the 'tenfold current rise per 8% amplitude' figure and the provisional 4.2–4.4 V centre amplitude are author claims. (My own level-1 diode estimate for five series junctions gives a current factor of order 5–10 per 8% string-voltage rise, so the claim is order-consistent but unverified.)
• Residual-state IC specification is ambiguous: '20 mA motional current and 10 V on its motional capacitor' needs an explicit sign/direction convention and an ngspice-usable application method (.ic on named internal nodes vs. injected sources).
• Feasibility tension to demonstrate, not assume: the 3.6 V floor and 4.7 V ceiling differ by only 1.3x while the ceiling sits at clamp onset (~4.5–5 V), so tolerance-robust margin may be thin. A passing reference must be shown before this is treated as achievable.

How to check it:
• ngspice: transient of 5 V-peak sine through 50 ohm into IFACE + XDUCER + CLAMP at OUT; FFT over 20 whole cycles after cycle 60 for R1 (fundamental) and R2 (harmonics 2–10); per-cycle peak envelope for R3 (both initial states); RMS of v(t)-v(t-10T) over a 10-cycle window for R4; 80-cycle burst then source = 0 with peak in the 15th post-drop cycle for R5; resistor average power over 20 cycles for R6. Take the worse of T/400 and T/1000 steps.
• Python parser for R7 (ports, R/L/C only, <= 10 elements, E12/E24 grid with 0.5% slack, design.json consistent with netlist).
• Reproduce one baseline failure (e.g. direct drive: expected settling ~40 cycles vs 20-cycle limit) and demonstrate one passing design before freezing thresholds.

Simulation gaps:
• Ideal elements: no parasitic ESR/ESL/self-capacitance, no inductor saturation or tolerance asymmetry; real parts will shift resonance and Q.
• Level-1 diode model only (IS, N, RS, CJO, BV): junction grading, self-heating, leakage spread and clamp tolerance are absent; BV=30 V is far from the operating point so clamping onset accuracy rests on N/RS.
• Transducer model is fixed and idealised (fixed Rm/Lm/Cm/Cp, no mechanical coupling, no drift with temperature, no unit-to-unit spread) even though the brief's premise is a drifting driver — temperature drift of the transducer itself is not modelled.
• Transient numerics: timestep sensitivity, diode convergence, initial-condition loading and FFT window/whole-cycle alignment can move extracted metrics by more than the stated margins; two timesteps reduce but do not bound this error.
• Tolerance sampling is discrete; no proof over the continuous box. Held-out frequencies are random draws, not a guarantee over the band.

Why frontier models fail:
• Plausible, subject to trials: the correct operating point sits inside a narrow coupled window — flatness over a 6% band forces loaded Q <= ~8, while amplitude margin, clamp conduction (exponential in amplitude), settling from a residual state and ring-down all move together. Naive moves (raise Q for amplitude, conjugate-match to 300 ohm, resistive damping) each break a different gate, and a centre-tuned design that passes nominal grid points usually fails on held-out frequencies, tolerance draws or a different timestep. This is a hypothesis about model failure modes, not a measured result.

Real-world risks:
• Ideal-element designs may not survive real inductor tolerance, DCR, self-resonance near 200 kHz and capacitor C0G/X7R derating; E12 snapping via series/parallel pairs eats the 10-element budget.
• Clamp conduction near the amplitude ceiling risks heating and long-term diode parameter drift; no thermal/energy rating is specified.
• Driver output impedance is assumed purely 50 ohm and resistive; source phase at burst start is prescribed as zero — real driver phase/start-up jitter is unmodelled.
• A design validated only on the supplied fixed transducer may fail against transducer unit spread; a real build needs measured impedance data over temperature.

Milestones (if too big): 1. Schematic-level topology + grid-snapped values: grader checks R1/R2/R6 at 3 band + 12 held-out frequencies, nominal only. 2. Full transient/robustness pass: R3/R4/R5 plus tolerance draws and dual timestep. Only split if measured solver runtime forces it.

What to change (reshape): none required at Stage 1. Pin down the tolerance quantifier (named corner set vs. universal claim) and the residual-state sign convention in the full task text rather than reshaping the device or the core decision.

Evidence status: Draft-only input. Fixed-part netlist text, handbook values, reference outline, public-design failure claims and mechanism_survival text are author claims; my resonance/Q/impedance/power figures are my own arithmetic from the stated model and are not simulation-verified. No filesystem inspection, no ngspice execution, no runtime measurement, no passing reference design observed. Checkable-in-principle (ngspice/Python) is established; implemented and validated coverage is not.

Checks before full-task readiness:
• Verify /app/input_assets/fixed_parts.cir exists as stated and parses in ngspice; confirm the clamp actually conducts in the 4.5–5 V peak region with the stated parameters.
• Produce a simulated passing reference design and reproduce at least two claimed public-design failures; recalibrate thresholds only from measured data (never widen limits to obtain a pass).
• Fix the tolerance quantifier: either enumerate a declared corner set or add an interval/sensitivity sweep; state exactly which draws and seeds the checker uses.
• Specify the ngspice IC mechanism and sign convention for the residual state, and the exact timestep values ('about T/400, T/1000' must become exact).
• Measure per-transient runtime and total grader wall time; record metric numerical noise vs. timestep so margins are sized against measured noise.

Numbers to supply next:
- Requirement: exact tolerance handling — e.g. 'the 40-draw set with seed 12345: all-low, all-high, 2 mixed corners, 16 random-extreme, 20 uniform draws' (currently qualitative).
- Requirement: timestep values and solver settings — e.g. 'T/400 = 12.5 ns and T/1000 = 5 ns at 200 kHz, ngspice default method, reltol 1e-3, abstol 1e-12'.
- Requirement: residual initial state convention — e.g. '20 mA flowing from node a to b through Lm at t=0 (positive into the port), 10 V with + on node b relative to N on Cm', plus the ngspice method (.ic V(xducer.b)=10 etc.).
- Requirement: definition of 'steady amplitude' used as R5's denominator — e.g. 'fundamental peak from the cycle-60–80 FFT window' vs. 'peak envelope'.
- Requirement: part ratings/derating — e.g. 'inductors >= 50 mA Isat, capacitors C0G, resistors >= 0.5 W rating'.
- Interface: input files — /app/input_assets/fixed_parts.cir (as supplied) and a checker bench template; output files /app/output/interface.cir (.subckt IFACE IN OUT GND, SI values) and /app/output/design.json ({topology_tag: string, components: [{ref, type: R|L|C, value: number}]}) — schema already mostly stated; confirm units and that series/parallel pairs are listed as separate refs.
- Handbook data: E12/E24 grids (IEC 60063) and diode level-1 parameters as in fixed_parts.cir — supply the ngspice version to be used and confirm BV=30 V is intentional.
- Verification still needed (not specifications): measured solver runtime for the full corner sweep; measured metric noise vs. timestep; a demonstrated passing design with margin over R1–R6 at held-out frequencies and tolerance draws.