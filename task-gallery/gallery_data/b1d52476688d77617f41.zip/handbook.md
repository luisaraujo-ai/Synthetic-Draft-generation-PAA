REFERENCE NOTES (normalized units: full scale FS = 1, equal to fs_volts in input.json).

Nominal loop model. Per clock cycle n, with input x[n] (signal plus noise) and quantizer output y[n]. Stage k has state (u_k, v_k) and updates:
[u_k;v_k][n+1] = g_k * R(theta_k) [u_k;v_k][n] + [1;0] * ( b_x_k*x[n] - b_f_k*y[n] + c_k*u_(k-1)[n] ).
Here R(theta) = [[cos, -sin],[sin, cos]], g_k = leak_g, and c_k = c_prev for k=2 (zero for k=1). Quantizer input q[n] = sum_k ff_k*u_k[n] + d_x*x[n]. Quantizer: q' = kq*q; y = clip(step*(floor(q'/step)+0.5), -1, 1) with step = 2/7 (eight levels, +/-1/7, 3/7, 5/7, 1). Nominal kq = 1. The quantizer uses the current q[n], so the loop has no extra delay beyond the one in the stage update. theta = 2*pi*f/fs, so 160 kHz is 0.3927 rad.

Model-form variation. Different implementations differ in how the resonance and loss land. Treat the effective theta_k as theta_k*(1+delta_k), delta_k in [-1.5%, +1.5%], independently per stage. Treat effective loss as g_k*(1-eps), eps in [0, 0.005]. Treat input gains b_x, b_f, c as scaled by (1+gamma), gamma in [-5%, +5%], common to the loop. These ranges, together with kq in [0.8, 1.25], define the R1 corner space. Tone frequencies and the offset values inside these ranges are sampled by the verifier at points you are not told, including interior points.

Noise (input-referred, added to x[n]). Per-sample white variance = 2*kB*T/C_in + (opamp rms)^2, in V^2, divided by fs_volts^2. Flicker has one-sided PSD Kf/f (V^2/Hz), generated for frequencies from about 1 kHz up to fs/2. Chopping multiplies the flicker PSD by 0.05 and the white variance by 1.2. The noise scale factor multiplies all noise amplitudes (variances scale as its square).

SNDR definition. Take a 32768-sample record after settling, coherent or Blackman-Harris windowed. Signal power is the tone's bins within +/-3 bins of the peak. Noise plus distortion is the sum of all other bins whose frequency is inside 150 to 170 kHz. SNDR is the ratio in dB. Average the spectrum of the output code stream (y values) over at least 8 records of independent noise draws.

State rms is sqrt(mean of u_k^2 + v_k^2 over all stages and samples in the window). R3 windows use a tone frequency that is an exact bin of the 4096-sample window. The fundamental's phase is the angle of the DFT bin at that frequency, referenced to the input tone phase.

Practice (ranges, not instructions). A 4th-order bandpass loop at an oversampling ratio of 64 with a multibit quantizer usually reaches 70 to 90 dB SQNR for ideal zeros. Pole radius close to 1 gives slow decay: the time constant is about 1/(1-r) cycles. Lightly damped resonators move the closed-loop poles strongly with small angle errors, and settling and phase consistency can change by large factors for 1% angle shifts. Quantization-noise spectral density depends on the zero spread across the band. kT at 300 K is about 4.14e-21 J.

Limits are in the brief. SNDR figures here are provisional estimates; the stated limits govern.
