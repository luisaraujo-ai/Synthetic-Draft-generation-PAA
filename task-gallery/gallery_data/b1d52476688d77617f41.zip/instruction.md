We need a loop-filter design for a narrowband sensor-readout converter. It digitizes a 20 kHz band centred on a 160 kHz carrier (150 to 170 kHz) at a 2.56 MHz clock, and the loop filter is built from at most two resonator stages. It ships without trimming, so the real resonances will sit somewhat off the design values from lot to lot and over temperature, and it has to keep working anyway.

Fixed inputs are in /app/input_assets/input.json (clock, full scale, quantizer, noise numbers, burst and initial-state settings). The loop model that defines the design parameters is in the reference notes. Please deliver /app/output/design.json with these fields: n_res (1 or 2); stages (a list of n_res objects with theta_rad, leak_g, b_x, b_f, c_prev); ff (list of n_res feedforward weights); d_x; c_in_pf; chopping (true or false). c_prev is used only in stage 2.

Requirements (tone 0.5 FS unless stated; SNDR is measured on the output code stream in 150 to 170 kHz):

R1. In-band SNDR lies between 68 and 74 dB for every tone frequency in 150 to 170 kHz, with each stage's resonance angle off nominal by up to +/-1.5%, integrator input gains off by up to +/-5%, effective quantizer gain from 0.8x to 1.25x, extra resonator loss up to 0.5%, and noise amplitude at 1.0x and 1.5x. Measured after settling, on a 32768-sample record.

R2. From zero state and from random initial integrator states up to 0.3 FS, the integrator-state rms over cycles 1500 to 2000 is within 5% of its value over cycles 8000 to 16000. This holds under every R1 condition.

R3. Over 8 consecutive coherent 4096-cycle windows after settling, the output fundamental's phase has a standard deviation of at most 0.5 degrees. The amplitude change between consecutive windows is at most 0.1 dB. This holds under every R1 condition at 1.5x noise.

R4. After a 200-cycle burst of a 1.2 FS in-band tone, the loop returns within 1000 cycles to integrator-state rms within 10% of steady state, in every 100-cycle window thereafter. The SNDR measured later, after 3000 cycles, is within the R1 window.

R5. With the 0.5 FS tone, no more than 0.5% of samples have quantizer input magnitude above full scale, and every integrator state stays below 5 FS. This holds under every R1 condition.

R6. Parameters stay in bounds: theta_rad 0.30 to 0.50; leak_g 0.90 to 1.00; every b_x, b_f, c_prev, ff and d_x magnitude at most 4; c_in_pf 0.5 to 2.0.

No trimming or digital calibration is available.
