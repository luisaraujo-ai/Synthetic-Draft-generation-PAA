### 28 · Narrowband resonator delta-sigma loop filter — advance, rank 7

Design decision as written: yes — "We need a loop-filter design for a narrowband sensor-readout converter ... the loop filter is built from at most two resonator stages" plus "deliver /app/output/design.json with these fields: n_res ... stages ... ff ... d_x; c_in_pf; chopping".

Forge task: Choose n_res (1 or 2), per-stage theta_rad, leak_g, b_x, b_f, c_prev, feedforward weights ff, d_x, c_in_pf and the chopping flag so that a 20 kHz band centred on a 160 kHz carrier at a 2.56 MHz clock holds in-band SNDR inside 68-74 dB and satisfies settling, phase/amplitude consistency, burst recovery and overload limits (R2-R5) under per-stage resonance-angle offsets up to +/-1.5%, input-gain spread +/-5%, quantizer gain 0.8-1.25x, up to 0.5% extra resonator loss and noise at 1.0x and 1.5x, with no trimming or digital calibration, and all coefficients inside R6 bounds.

Why it fits:
- It is a design decision, not an analysis: the deliverable is a parameter set (configuration design) for a loop filter, not a measurement or a solver.
- The handbook gives complete discrete-time state equations, quantizer law, noise model and SNDR definition, so a headless Python/numpy simulator can evaluate every requirement deterministically once corner points, seeds and noise draws are fixed.
- The artifact is a single JSON of ~10 bounded numbers; search and verification fit one agent run if the simulator is fast.
- The engineering difficulty is real: robust loop design where damping, zero spread and loop gain trade against SNDR floor/ceiling, settling, phase consistency and overload.

What stops it:
- Structural objections: none identified. The idea is a design decision, and the model is specified in enough detail to simulate.
- Unresolved feasibility risks (author claims, not verified): the reference outline is a proposed solution whose own text says "thresholds are provisional until a passing reference is run"; the feasible window may be empty or razor-thin with only two resonators when the 68 dB floor must hold at 1.5x noise and worst-case angle/loss/kq corners while the 74 dB ceiling must hold at favourable corners; R3's 0.5 deg phase std and 0.1 dB window-to-window amplitude limits at 1.5x noise may be noise-limited rather than design-limited; the three "public design" failure claims are hypotheses with no measured margins.
- Runtime is an estimate only: the corner/interior sample count and Monte Carlo cost are unspecified, and 8 noise draws x 32768 samples per condition across many conditions can dominate a two-hour budget.

How to check it:
- Python/numpy (bespoke simulator, not one of the tabulated tools): parse design.json, enforce R6 bounds and types; implement the handbook loop, quantizer and noise; sweep the declared corner grid plus random interior samples of delta_k, gamma, kq, eps, noise scale and held-out tone frequencies in 150-170 kHz.
- SNDR from 32768-sample output-code spectra averaged over 8 independent noise draws (R1); quantizer overload fraction and peak states (R5); state-rms ratio cycles 1500-2000 vs 8000-16000 from zero and random initial states (R2); phase std and amplitude change over 8 coherent 4096-cycle windows at 1.5x noise (R3); 200-cycle 1.2 FS burst recovery and post-3000-cycle SNDR (R4).
- The simulator itself needs independent validation (a second implementation of the same loop, or a textbook bandpass delta-sigma NTF/SNR check) before its verdicts count.

Simulation gaps:
- The model is normalized and behavioural: no finite opamp DC gain, GBW, slew, switch charge injection, clock jitter, quantizer metastability or capacitor-ratio mismatch; only the lumped given noise terms are represented.
- kT/C and flicker are applied as specified, but the mapping from c_in_pf to a real switched-capacitor or Gm-C resonator, and whether +/-1.5% resonance spread is realistic on-chip, is not checked.
- SNDR averaged over 8 noise draws carries Monte Carlo noise that may be comparable to the stated 0.2 dB grading resolution; the pass/fail rule at the 68/74 dB boundary needs defining.
- Interior-corner sampling density decides pass/fail and is unspecified; a design can pass a coarse grid and fail held-out points.
- Checkable in principle is not the same as implemented and validated: no simulator has been run or inspected here.

Why frontier models fail:
- Narrow robust-feasibility window: tuning leak toward 1 and zeros to the carrier raises nominal SNDR but makes settling, phase consistency and recovery collapse under ~1% angle shifts; heavy damping forfeits the 68 dB floor.
- Per-stage independent angle offsets combined with interior kq, loss and gain spread mean corner-only tuning fails; the agent must reason about the whole Monte Carlo envelope of a nonlinear clipped multibit loop, where no closed-form NTF argument covers overload recovery or state excursions.
- Coupled requirements (SNDR ceiling and floor, settling ratio, windowed phase/amplitude, overload fraction) must hold simultaneously; trade-offs are not separable per stage.

Real-world risks:
- A model-level pass need not survive a real implementation; coefficient spread, finite gain and thermal noise in an actual 2.56 MHz switched-capacitor loop could break R1/R2.
- The stated 68 dB floor at 1.5x noise in an 8-level, OSR-64 bandpass converter may be close to the achievable SQNR plus thermal-noise budget without trimming.
- Untrimmed +/-1.5% resonance-angle spread may be optimistic for on-chip RC/Gm tolerances; the reverse risk (spec too loose to be meaningful) also exists.

Milestones (if too big): not required at this stage; if the corner budget proves large, split as: 1. nominal-model coefficient design: grader checks R1 at nominal and R6 bounds; 2. robustness sweep: grader checks R1-R3 across the corner/interior set; 3. overload and recovery: grader checks R4-R5 plus full R1 rerun.

What to change (reshape):
- Nothing structural. Pin down (in Numbers to supply next) the enumeration of "every R1 condition", the held-out sampling and seed policy, the initial-state distribution, R2/R4 settling indexing, R3 window placement and phase wrapping, and the borderline SNDR rule.

Numbers to supply next:
- Requirement (missing spec): enumeration of the R1 condition space — e.g. all 2^4 declared corners x 2 noise scales plus 48 random interior points per stage angle, gamma, kq and eps, with a fixed seed list; and how many held-out tone frequencies per condition (e.g. 12).
- Requirement (missing spec): noise Monte Carlo policy — e.g. 8 records x 32768 samples per condition as stated, and a pass/fail rule when the mean SNDR lands within 0.2 dB of 68 or 74 dB.
- Requirement (missing spec): R2 initial-state distribution and measurement indexing — e.g. each u_k, v_k drawn uniformly in +/-0.3 FS, N seeds (e.g. 20), settling time zero at n=0, windows as written.
- Requirement (missing spec): R3 window placement (e.g. 8 consecutive 4096-cycle windows starting at cycle 2000), tone chosen as an exact bin inside 150-170 kHz, phase wrapped to +/-180 deg as the grader plan states.
- Requirement (missing spec): R4 recovery definition — start of the 100-cycle window series, which cycles count as "after 1000 cycles", and the burst frequency set (e.g. one interior in-band frequency).
- Interface: inputs /app/input_assets/input.json (as supplied: fs_hz 2560000, band_hz [150000,170000], fs_volts 0.2, quantizer step 2/7 with kq_range [0.8,1.25], c_in_pf_range [0.5,2.0], opamp_white_rms_uV 60, Kf_V2 4e-10, noise_scale_amplitude [1.0,1.5], burst 1.2 FS / 200 cycles); output /app/output/design.json with a published schema (field names, types, list lengths, c_prev ignored for stage 1) and a validator script.
- Handbook data: confirm the noise normalization (variances divided by fs_volts^2), the chopping factors (flicker x0.05, white variance x1.2), kT = 4.14e-21 J at 300 K, and the quantizer law y = clip(step*(floor(q'/step)+0.5), -1, 1) with step = 2/7.
- Verification still needed (not missing specs): run one passing reference design and record its margins at every corner; reproduce the three claimed public-design failures with measured margins; validate the numpy simulator against an independent implementation or a known bandpass delta-sigma benchmark; measure simulator runtime and Monte Carlo noise to establish the two-hour fit.

Evidence status: draft-only. The reference outline, distinct_valid_designs, public-design failure claims, provisional SNDR figures, catching rows, mechanism-survival narrative and grader_plan are author claims reproduced here as such. No filesystem inspection, simulator run, measured margin or passing design has been supplied; nothing in this review is verified evidence beyond the stated requirements and the embedded input.json text.

Checks before full-task readiness: 1) reproduce the three claimed public-design failures and quantify their margins; 2) obtain one passing reference design with corner margins recorded; 3) validate the simulator against an independent reference implementation; 4) fix corner/interior sampling, seed, initial-state and borderline-SNR policies; 5) measure runtime and Monte Carlo noise for the full condition set.