# Handbook: conditioning block

## Supplied models (models.spice)
The file defines:
- global parameters RON and A0DB (defaults 1000 Ohm and 70 dB);
- switch model SWM, a voltage-controlled switch with Roff = 1e12 Ohm, threshold 1.65 V and hysteresis 0.05 V;
- subcircuit OPAMP with ports inp inn out vdd gnd and parameter GBW.

OPAMP is a single-pole transconductance stage with DC gain 10^(A0DB/20). Its output is clamped to 0.1 V above gnd and 0.1 V below vdd, with 100 Ohm of series output resistance. It draws a constant 0.4 mA x GBW/20 MHz from vdd. Your netlist must not redefine SWM, OPAMP, RON or A0DB.

The checker substitutes RON anywhere from 200 Ohm to 5 kOhm and A0DB anywhere from 60 to 80 dB. Switches close when their control exceeds about 1.65 V. Charge injection and leakage are not modelled.

## Environment seen by BLOCK
- Each input leg is driven through exactly 1 kOhm from an ideal source. The differential voltage vd = V(inp) - V(inn), and the common mode is the mean of the two legs.
- The clock has 1 ns edges. Each phase is high for half a period minus 5 ns, and phi1 is high first.
- The differential input changes only at the start of a period (phi1 rising edge) for step and DC tests. The tone is a continuous sinusoid. The input is constant within each slot.
- The sampling instant is 5 ns before the falling edge of phi2. Every metric uses the output sampled once per period at that instant. The clock period for each run is 1/f_clk, with f_clk anywhere from 0.98 to 1.02 MHz.
- Capacitor handling: each capacitor C n1 n2 value is multiplied by (1 + 0.001 g), with g a Gaussian draw, independently per capacitor and per run. A parasitic capacitor of 0.05 x value is then added from n2 to gnd.
- Initial state: every node touching a capacitor is initialised to a random voltage between 0 V and VDD, set by the checker.

## Metric definitions
- **Gain (R1):** amplitude of the output component at 10 kHz, divided by the 10 kHz input amplitude, with a 1.0 Vpp differential tone. It is found by least-squares fit after 20 settling slots.
- **SNDR (R2):** the 2048 samples are windowed with a 4-term Blackman-Harris window. Tone power is taken in the 9 bins around the tone. Error power is all remaining bins from bin 3 to the Nyquist bin, which excludes DC and offset; everything except the tone and DC counts as error. Noise is not simulated. SNDR = 10 log10(tone/error).
- **Memory (R3):** y0 is the first output sample after the input changes from +1 V to 0 V at a period boundary. yss0 is the settled zero-input output, taken after 40 further slots. yss1 is the settled output with +1 V input. Memory error = |y0 - yss0| / |yss1 - yss0| x 100 %.
- **State return (R4):** the reference value is the mean of samples 290 to 300 of the same run. Samples 20 to 40 are compared with it, for every random start and for the zero start.
- **Rejection (R5):** the output sequence (sampled at f_clk) is fitted by least squares with a sinusoid at |f - f_clk|, plus a constant, over 1024 slots after 20 settling slots. Tones within 3 kHz of f_clk are not used for the alias fit. The rejection is 20 log10( G10k x 1.0 V / alias amplitude ), with G10k from the same corner.
- **Current (R6):** the mean of the current out of the vdd source over the whole tone-test window.
- **Capacitance (R7):** the sum of all capacitor values written in the netlist before the checker's modifications.
- **Numerical consistency (R8):** the checker re-runs each case with the simulation timestep halved and compares the metrics. The gain must change by at most 0.2 %, the SNDR by at most 0.5 dB, and the memory error by at most 0.05 percentage points.

## Ranges used for checking
The checker draws start states, corner values and seeds inside the declared ranges, including values between the extremes. Do not rely on the extremes alone.
- f_clk: 0.98 to 1.02 MHz
- VDD: 3.0 to 3.6 V
- common mode: 1.45 to 1.85 V
- RON: 200 to 5000 Ohm
- A0DB: 60 to 80 dB

## Background
- An ideal sampled output of a signal with energy near f_clk folds to |f - f_clk|.
- A switch with on-resistance Ron discharging a capacitor C leaves a fraction exp(-t/(Ron C)) of the initial voltage after time t.
- Capacitor mismatch between parallel signal paths shows up as spurs at multiples of f_clk/2 plus or minus the tone frequency.
- An op-amp integrator or switched-capacitor stage with finite gain A transfers charge with a relative error of about 1/A.
- kT/C noise and thermal noise are not part of any metric.
