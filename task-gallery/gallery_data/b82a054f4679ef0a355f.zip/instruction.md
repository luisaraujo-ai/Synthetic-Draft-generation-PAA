Conditioning block for a 16-bit multiplexed data-acquisition card, shared by all channels, one sample per 1 us slot. No memory of the previous slot; clean start without warm-up samples.

Interface: subcircuit BLOCK, ports inp inn phi1 phi2 vdd vref out gnd.
- inp/inn: differential inputs behind 1 kOhm source resistance per leg; common mode 1.45 to 1.85 V.
- phi1/phi2: 1.000 MHz (+/-2 %) two-phase non-overlapping clock, 0 to VDD, 5 ns non-overlap.
- VDD 3.0 to 3.6 V; vref is an ideal VDD/2.
- out: single-ended, loaded by 10 pF in parallel with 100 kOhm to gnd, sampled 5 ns before end of phase 2 each period.

Allowed parts: resistors 100 Ohm to 1 MOhm; capacitors; switches of model SWM (on-resistance 200 Ohm to 5 kOhm); instances of subcircuit OPAMP (open-loop gain 60 to 80 dB, GBW 1 to 40 MHz, supply current 0.4 mA per 20 MHz of GBW), from models.spice; ideal logic sources driving only switch controls.

Each capacitor has 0.1 % (1 sigma) random error plus a parasitic of 5 % of its value from its second-listed node to gnd. Put no analysis commands, initial conditions or model definitions in the netlist.

Each requirement holds over all stated ranges and start states.

R1. Gain, differential input to (out - vref) at 10 kHz: 1.88 to 2.12 V/V.
R2. SNDR, 10 kHz 1.0 Vpp differential tone, 2048 consecutive slots after 20 settling slots: at least 60 dB.
R3. Input +1 V differential for 40 slots, then 0 V: first output sample at 0 V, relative to the settled zero-input output, at most 0.3 % of the settled +1 V output.
R4. Input held at 0 V or +0.8 V differential: every output sample from slot 20 to 40 within 1 mV of the value after 300 slots.
R5. 1.0 Vpp differential tone from 960 kHz to 1.04 MHz: sampled output component at the alias frequency at least 20 dB below 1.0 Vpp times the 10 kHz gain.
R6. Average vdd current during the tone test at most 1.2 mA.
R7. Total capacitance at most 60 pF.
R8. Numerical consistency: gain, SNDR and memory error must be insensitive to simulation resolution, within the limits in the handbook.
R9. Construction: only the allowed parts above.

Deliverable: /app/output/block.cir containing BLOCK; conventions in the handbook.
