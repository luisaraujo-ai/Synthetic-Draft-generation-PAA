### 14-mux-daq-conditioning-block-no-memory · Shared-channel differential-to-single-ended conditioning block — advance, rank 8

Design decision as written: yes — "Conditioning block for a 16-bit multiplexed data-acquisition card, shared by all channels, one sample per 1 us slot" with "Deliverable: /app/output/block.cir containing BLOCK"; the agent chooses the topology and sizes every resistor, capacitor, switch and OPAMP instance.

Forge task: Design a differential-to-single-ended conditioning subcircuit BLOCK (ports inp inn phi1 phi2 vdd vref out gnd) from R, C, SWM switches and OPAMP instances that meets R1 gain 1.88–2.12 V/V at 10 kHz, R2 SNDR ≥ 60 dB over 2048 slots, R3 slot memory ≤ 0.3%, R4 start-state return ≤ 1 mV by slot 20, R5 ≥ 20 dB rejection of 960–1040 kHz tones at the alias, R6 ≤ 1.2 mA average vdd current, R7 ≤ 60 pF total capacitance, R8 timestep insensitivity, over f_clk 0.98–1.02 MHz, VDD 3.0–3.6 V, vcm 1.45–1.85 V, RON 200–5000 Ohm, A0 60–80 dB, random capacitor errors/parasitics and random start states.

Why it fits:
• The deliverable is a design artifact (netlist topology and component values in a fixed part library), not a measurement, analysis or tool.
• ngspice runs headless and reproduces every stated metric: transient of the checker bench with 1 ns clock edges and the defined sampling instant; numpy then does the least-squares 10 kHz gain, the 4-term Blackman-Harris SNDR with the fixed bin convention, the alias sinusoid-plus-constant fit, memory/state-return errors and mean vdd current; a static Python parse covers R7 and R9.
• The constraints are coupled through mechanisms the supplied models do capture (sinc/alias null placement vs clock spread, dump completeness vs RON and C, finite-gain charge transfer vs memory, GBW vs current, two-path mismatch vs SNDR spurs), so this is genuine mixed-signal trade-off work rather than hidden-rule tedium.
• The brief already fixes ports, environment, metric definitions and ranges, so the design problem is well posed as written.

What stops it:
• Structural: nothing in the idea requires physics that a headless tool cannot check, since the model world is explicitly self-consistent and noise/charge injection are declared out of scope.
• Unresolved feasibility risk: no passing design has been shown. The reference outline is labelled untested with provisional thresholds, and the stated margins are narrow (author-estimated ~24 dB worst-case alias rejection against a 20 dB limit; R3 memory 0.3% against finite-gain charge error ~1/A ≈ 0.1% at 60 dB and dump residual exp(-t/(RON*C)) at RON 5 kOhm; R2 60 dB against 0.1% capacitor mismatch spurs). If no configuration satisfies R1–R8 at once, the task has no solution and would need re-scoping.
• Unresolved runtime risk: the grading suite runs 20+2048 slot transients plus 1024-slot alias runs across corners, starts and seeds and repeats at a halved timestep; measured ngspice runtime is unknown and could break the one-run budget.

How to check it:
• ngspice: wrap block.cir in the checker bench (models.spice with RON/A0DB overridden, 1 kOhm source legs, two-phase 1 ns-edge clock, 10 pF || 100 kOhm load, per-run 0.1% Gaussian capacitor error plus 5% bottom-plate parasitic, checker-supplied .ic), transient across the declared ranges, sample 5 ns before the phi2 falling edge.
• Python/numpy: gain fit, Blackman-Harris SNDR per the handbook bins, alias fit at |f - f_clk| excluding tones within 3 kHz of f_clk, memory error and state-return error, mean vdd source current.
• Static parse: element whitelist, logic sources feeding only switch controls, no .tran/.ic/.model/.param lines, capacitance sum with 0.5% allowance; timestep-halved repeats for R8.

Simulation gaps:
• Charge injection and leakage are not modelled (stated in the handbook), yet they are exactly the effects that set real slot-to-slot memory.
• Noise (kT/C, thermal) is not simulated, so R2's 60 dB SNDR is a distortion/spur limit only; a 60 pF budget with 1 kOhm sources sits near the real thermal floor.
• The OPAMP macro has no slew rate, no input common-mode limit, no output current limit (only a clamped behavioural output and 100 Ohm Ro), no PSRR/CMRR; the switch has no parasitic capacitance.
• Real capacitor voltage/temperature coefficients, layout parasitics and component matching are absent; only a 0.1% Gaussian plus a fixed 5% parasitic is applied.

Why frontier models fail:
• Hypothesis, not evidenced by trials: one set of values must satisfy alias rejection, complete slot reset, current and capacitance simultaneously over RON 200–5000 Ohm, A0 60–80 dB, f_clk ±2% and random starts/mismatch.
• Ordinary continuous-time filters and naive track-and-hold fail R3 or R5 (author's claimed public-design failures, unverified); a single-path integrate-and-dump over phase 2 gives only a few dB of alias rejection; two-path ping-pong trades mismatch spurs against reset completeness.
• Expect nominal-corner designs to look clean and then fail on held-out seeds and interior corner points; only solver-run trials would confirm this.

Real-world risks:
• A passing netlist is validated only inside the declared model world; a build would face charge injection, kT/C noise, real amplifier settling/slew and capacitor matching, plus PCB/layout parasitics.
• The constant 0.4 mA per 20 MHz GBW bias model understates real amplifier current under a 10 pF load, so R6 is a proxy rather than a real power spec.

Milestones (if too big):
1. Short-window design: topology and sizing validated on 64–128 slot runs; grader checks R1, R3, R4, R6, R7, R9 on those windows.
2. Full-length validation: 2048-slot SNDR (R2), 1024-slot alias rejection (R5) across corners and seeds, plus the timestep-halved repeat (R8).
Keep the split only if measured full-length runtime breaks the one-run budget.

What to change (reshape):
• None as written. Only if the reference simulations show the R1–R8 window is empty should the vendor reconsider a limit or the allowed part set; that would be a spec change to propose, not one to make at this stage.

Numbers to supply next:
• Requirement (missing specification): checker timestep policy for R8 — e.g. nominal maximum timestep 2 ns, repeat at 1 ns.
• Requirement (missing specification): corner and seed sampling plan per grader case — e.g. zero start plus 3 seeded random starts x 5 interior corners (f_clk 1.013 MHz, RON 3.3 kOhm, A0 66 dB, VDD 3.17 V, vcm 1.80 V).
• Interface (missing specification): the checker bench as an input asset — e.g. /app/input_assets/bench.cir including models.spice plus the measurement script, so the agent can reproduce the metrics.
• Interface (missing specification): netlist scope — state whether BLOCK may contain helper .subckt lines and whether any OPAMP instance count is capped (e.g. helper subcircuits allowed, no instance cap).
• Handbook data (missing specification): ngspice version and .tran options used by the checker — e.g. ngspice 42, transient run without uic, .ic supplied by the checker.
• Verification still needed: build the reference candidate and run the full R1–R8 suite to show at least one netlist passes with margin (report worst-case alias rejection, memory error and SNDR).
• Verification still needed: measured runtime and memory of one 2048-slot transient at the checker timestep and of the whole suite on the grading hardware.
• Verification still needed: calibrate R8's numerical noise floor on a known-good design across the two timesteps so the 0.2% / 0.5 dB / 0.05 pp limits do not grade the solver's numerics.

Evidence status: Draft-only input. The models.spice content and handbook metric definitions are supplied text, not verified as runnable files or as reproducing the stated behaviour. The reference outline is untested per the author's own wording; the ~24 dB and 4 dB rejection figures, the public-design failure rows and the mechanism-survival narrative are author claims or hypotheses, not measured results. No simulation outputs, runtime measurements or passing designs were supplied or inspected; no execution evidence is verified.

Checks before full-task readiness:
1. Simulate a candidate through the R1–R8 suite across the declared ranges and seeds to confirm a solution exists in the stated window.
2. Measure full-suite ngspice runtime and memory on the grading hardware.
3. Confirm ngspice accepts the supplied OPAMP macro (min/max in a B source) as written, and lock the bench conventions: clock edges, sampling instant, mismatch/parasitic application and .ic injection.
4. Calibrate R8 against the chosen timestep policy so the drift limits sit above the numerical noise floor.
5. Test the R7/R9 parser on valid and invalid netlists (element whitelist, capacitor sum, forbidden lines).