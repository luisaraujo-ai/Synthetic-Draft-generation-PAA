We are specifying a clocked sampling latch for our front end and need your sizing to meet our datasheet numbers. The topology is fixed (cross-coupled inverter latch, input pair, clocked tail, clocked reset pull-ups, output load capacitors; described in the handbook). You choose the values. Fixed inputs are in /app/input_assets/input.json (burst, beat, noise and thermal numbers) and /app/input_assets/mos_model.lib (device model).

Fixed conditions: supply 0.9 V nominal, also tested at 0.828 V (-8%); clock period 400 ps, 50% duty, 20 ps edges; burst of 4096 events. Events 1-3584 use the nominal overdrive in input.json with the stated beat modulation; events 3585-4096 use the 10x lower overdrive. Latch bias self-heats through the stated first-order thermal model driven by the latch's own dissipation.

Decision time t_d[k] is the time from the clock evaluation edge to the differential output reaching 90% of supply. Our residual metric is the RMS, over events 501-3584, of t_d[k] minus the least-squares fit of exactly two components: A*sin(2*pi*f_b*k*T + phi) with free A and phi at the beat frequency f_b in input.json, plus one constant. Nothing else is removed from the series. It is averaged over noise realizations.

Requirements, each at both supplies unless stated:
1. Residual RMS <= 1.2 ps (noise realizations other than those listed in input.json will be used).
2. Nominal-overdrive events: t_d <= 160 ps (40% of the period) for every event 1-3584.
3. Low-overdrive events 3585-4096: every event reaches 90% of supply before the end of its evaluate phase; zero unresolved events.
4. Before each evaluation, residual precharge error at the outputs <= 1 mV.
5. Average supply power over the burst <= 120 uW.
6. Peak tail current <= 300 uA.
7. Sum of all device widths (counting every device instance) <= 40 um; every channel length >= 30 nm.

Deliver /app/output/design.json with these fields: for each of the input pair, the cross-coupled NMOS pair, the cross-coupled PMOS pair, the tail device and the reset pull-ups, a width_um and a length_nm; tail_gate_bias_v; reset_release_offset_ps (reset release relative to the rising clock edge, -50 to +50); load_cap_ff (per output, 0 to 30).
