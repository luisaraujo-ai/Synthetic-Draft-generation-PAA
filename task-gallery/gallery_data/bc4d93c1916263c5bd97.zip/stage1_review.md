### 22 · Sampling latch with bounded decision-time residual — advance, rank 7

Design decision as written: yes — "You choose the values… for each of the input pair, the cross-coupled NMOS pair, the cross-coupled PMOS pair, the tail device and the reset pull-ups, a width_um and a length_nm; tail_gate_bias_v; reset_release_offset_ps …; load_cap_ff". The deliverable is a parameter vector that fixes a physical cell implementation, not an analysis.

Forge task: Size a fixed-topology clocked sampling latch (5 device groups × W/L, tail gate bias, reset release offset, per-output load cap) in a 0.9 V, 400 ps process so that, across both supplies and a 4096-event burst with self-heating drift and noise, the decision-time residual after removing only a beat sinusoid and a constant is ≤ 1.2 ps, all nominal events decide within 160 ps, all 10x-lower-overdrive events resolve, precharge error ≤ 1 mV, average power ≤ 120 µW, peak tail current ≤ 300 µA, and total width ≤ 40 µm with L ≥ 30 nm.

Why it fits:
• It is a real parameter-selection design problem: the delivered design.json fully determines a buildable cell, and every requirement is a property of that geometry/bias.
• The physics is genuinely coupled: tail current shortens tau_reg (helping R2/R3) but raises dissipation, which drives the first-order thermal drift that the two-component residual explicitly does not remove (hurting R1), while width/length set flicker noise area and power. Reset release offset trades initial imbalance against precharge completeness (R4). This is the kind of trade-space frontier models handle poorly without a disciplined simulation loop.
• The metric trap is real and stated honestly: a solver that fits a linear or polynomial term absorbs the drift and optimizes toward high-tail designs that fail the specified two-term fit. R1 also bounds power-side cheating.
• The task is self-contained: topology, model card, burst definition, bounds and output schema are all specified text.

What stops it (structural objections vs. feasibility risks):
• Structural: none fatal at Stage 1 — the idea is a design decision with a plausible headless check path.
• Unresolved feasibility risk — numerical noise floor: the residual limit is 1.2 ps while t_d is extracted from a transient crossing on a 400 ps clock. ngspice timestep/tolerance settings are not specified; interpolation error and solver noise could be of the same order as the limit, making the metric unmeasurable or seed-dependent. Needs a measured noise floor (rerun one candidate twice with tightened reltol/tstep and compare t_d series).
• Unresolved feasibility risk — noise model underdetermination: the handbook gives input-referred formulas with "about" language ("gamma about 1-2", a shift of "about -tau_reg*v_n/DeltaV_in"), and it is unspecified whether noise perturbs t_d post hoc or is injected as circuit noise. The grader's held-out-seed behavior cannot be predicted precisely until this mapping is nailed down.
• Unresolved feasibility risk — runtime: the grader plan implies transient sweeps over a (supply, dT, overdrive) grid plus event-by-event thermal stepping and ≥10 noise seeds, done inside the agent's own loop for candidate designs. 30-50 candidate evaluations at an unknown per-evaluation cost could exceed the ~2 h budget. Estimate arithmetic: a 4096-event per-event transient is clearly infeasible; the grid-plus-interpolation approach is required, and its fidelity is unproven.
• Unresolved feasibility risk — reference feasibility: the reference_outline explicitly states no passing reference has been demonstrated, and the residual limit is marked provisional. Whether any sizing exists inside the 7-requirement window is an open question, not an established fact.

How to check it:
• ngspice (headless, .tran) with the supplied level-1 models: builds the latch netlist from design.json; extracts per-event t_d (output threshold crossing), precharge error at end of reset, tail current waveform, and per-event energy.
• Python (numpy least squares): fits exactly [sin(2*pi*f_b*k*T), cos(2*pi*f_b*k*T), 1] over events 501-3584 and computes residual RMS, averaged over held-out seeds; steps the first-order thermal model (Rth=2e5 K/W, Cth=1e-11 F) event by event from measured energy and applies the -1.0 mV/K threshold shift and the stated mobility law.
• Schema/bounds check (pure parsing) for R7.

Simulation gaps:
• Level-1 square-law at 30 nm channel lengths omits velocity saturation, DIBL, subthreshold conduction, and real short-channel gm behavior; a design passing here may not behave the same in a real 30 nm process.
• The single-pole self-heating model with uniform junction temperature ignores spatial thermal gradients and package effects.
• Post-hoc noise perturbation (if that is the intended method) does not capture noise-modified regeneration dynamics or the correlation between noise and the thermal state; in-sim noise is stochastic and needs many repetitions.
• Grid-interpolated t_d vs. per-event simulation can hide beat-phase-dependent effects; corner coverage (supply × dT × overdrive × seeds) is asserted, not demonstrated.

Why frontier models fail (hypothesis, not trial-verified):
• The natural shortcut — fit away the slow drift or optimize tau_reg alone — fails the exactly-two-component residual held out from the agent's own fit.
• Meeting R2/R3 (regeneration speed at 2 mV overdrive, worst supply) pushes toward larger tail current, which violates R1/R5/R6 via self-heating; the viable window is narrow and requires disciplined multivariable search, not one-shot sizing.
• Beat-harmonic content and event-window selection (501-3584) reward actual per-event simulation over analytic estimation.

Real-world risks:
• Square-law model fidelity (above) is the dominant gap; also the noise formulas are textbook approximations, and Rth/Cth are stylized.
• A design that passes this grader is validated against the stated models only, not against silicon or a PDK.

Evidence status: Everything in the payload is a draft/specification and author claim. Specifically unverified: the public_designs failure narratives (R1 drift "several times 1.2 ps", R2/R3 and R5/R6 failures), the stated margins, the reference_outline strategy, and all runtime/budget implications. Verified evidence supplied: only the text of input.json, mos_model.lib, the requirement list and the grader plan. No simulation output, netlist, or passing design artifact exists in the input.

Checks before full-task readiness:
1. Define precisely: t_d threshold (falling output < 10% Vdd vs |X-Y| ≥ 0.9 Vdd), beat modulation form, and the noise-to-t_d mapping (post-hoc vs in-sim).
2. Measure the numerical noise floor on t_d and on residual RMS with fixed ngspice options; confirm it is well under 1.2 ps (e.g., < 0.2 ps).
3. Reproduce one claimed public-design failure (e.g., a large-tail design exceeding the residual) to validate the grader pipeline end to end.
4. Demonstrate at least one design meeting all seven requirements under the grader's own settings, or confirm the window is empty at the provisional limits.
5. Time one full evaluation (grid + thermal stepping + seeds) to establish the candidate budget fits the run.

Milestones (if the full loop proves too big):
1. Static/per-event characterization task: given a fixed sizing, compute t_d grid vs. (Vdd, dT, overdrive) and energy per event; grader checks extraction accuracy against a slow high-accuracy reference run.
2. Residual-and-thermal task: given the grid, step the thermal model and produce the t_d series and residual; grader checks fit convention and RMS.
3. Full sizing task: deliver design.json meeting all seven requirements.

Numbers to supply next:
• Specification (missing): decision-time threshold definition — e.g., falling output crossing 0.1*Vdd, with interpolation rule; and whether R2/R3 use the same crossing for all seeds.
• Specification (missing): beat modulation expression — e.g., overdrive[k] = 20 mV * (1 + 0.1*sin(2*pi*7.3e6*k*400e-12)) applied to the differential input.
• Specification (missing): noise injection method and exact mapping to t_d — e.g., per-event delta t_d = -tau_reg*v_n/DeltaV_in with C_node = sum of node capacitances from the netlist; define v_n draw per seed and its units (KF = 2e-25 in what units).
• Requirement (provisional): confirm residual limit 1.2 ps and the 3% numerical margin; do not widen it to obtain a pass — instead report if the window is empty.
• Interface: input files /app/input_assets/input.json and mos_model.lib (as supplied); output /app/output/design.json with exactly the listed keys and units (width_um, length_nm, V, ps, fF); state whether extra keys are permitted and the float tolerance (draft says 1e-9).
• Handbook data: ngspice analysis settings — e.g., reltol 1e-6, max timestep 0.5 ps, tstart for settle; device counting convention (2 per pair/reset/input device, 1 tail) as in G1.
• Verification still needed: baseline failure reproduction for one public design; measured per-evaluation runtime; demonstrated passing design or an empty-window determination; noise-floor measurement.
• Handbook data (stated as practice, keep as guidance not requirement): tau_reg 8-25 ps for 0.9 V / 30 nm class; peak tail current occurs at start of evaluation.