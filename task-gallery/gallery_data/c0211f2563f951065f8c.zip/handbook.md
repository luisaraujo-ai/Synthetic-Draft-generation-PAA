# Handbook

## Leakage physics
- Reverse leakage of a silicon junction at a few volts of reverse bias is roughly constant in voltage, once the bias is well beyond kT/q (about 26 mV). It rises steeply with temperature, typically 1.8 to 2.5 times per 10 degC for generation-dominated leakage.
- The clamp parts in the environment file are behavioural diodes, with Is(T) = Is0 * LK * (T/298.15)^(XTI/N) * exp(EG*(T/298.15 - 1)/(N*k*T/q)), N = 2, XTI = 3, EG = 1.11 eV. The series Rs and junction capacitance are lumped as stated in the file.
- Forward drop of a clamp grows logarithmically with current. It is about N*Vt*ln(I/Is) plus I*Rs. Paralleled devices share the current.
- The board surface leakage in the file is a current into sn that does not depend on temperature or node voltage and grows in time. It is scaled by LK.
- The node settles quasi-statically, because the node capacitance times the bias resistance is well under a few seconds. Net DC current into the node times the DC resistance to the bias point gives the voltage offset.

## Measurement definitions
- Temperature for the metric is T(t) from the formula, evaluated at the sample times t = 2 d, 2 d + 600 s, ..., 30 d.
- Residual: with the samples V_k, solve least squares for a and b in V_k ~ a + b*(T_k - 25). The residual is r_k = V_k - a - b*(T_k - 25). Report sqrt(mean(r_k^2)).
- Supply current is the current delivered by the 3.0 V source Vdd, at a constant board temperature set through THOLD.
- DC small-signal resistance at sn: ratio of a small voltage perturbation to the resulting current, at 1 mHz, at a constant board temperature of 25 degC, with all other sources quiescent. Reverse-biased clamp conductance counts.
- Surge: a 1 ms pulse of 8 V behind 100 Ohm is injected at the in pin at t = 0+, as defined in the file.

## Practice
- Resistors of 1 MOhm to 1 GOhm are commonly available at 1 % tolerance. Use ideal values in the netlist.
- Currents of a few picoamps are comparable to default simulator conductance and tolerance settings. Relax or tighten the simulator accordingly when verifying.
- A 30-day transient can be run with a large maximum timestep (minutes) away from the surge, since the node follows the slow inputs quasi-statically.
- Component names in the netlist are free. Node names sn, vdd, in, tc and 0 are fixed by the environment file.
