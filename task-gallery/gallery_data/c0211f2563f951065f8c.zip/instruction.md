We need the input protection and bias stage for our battery-backed sensor board. The sense node is a 4.7 nF sensing capacitor plus 10 pF parasitic. It sits floating in standby for months, and clamp and board leakage slowly charge it. The reading has to stay stable over the 30-day calibration interval, and the stage has to survive one input surge at day 0.

Fixed environment: /app/input_assets/board_env.inc. It defines the 3.0 V rail (node vdd), the sense node sn, the input pin in, the temperature node tc, the surge generator, the board leakage, and two clamp parts DIODEA and DIODEB. Temperature is T(t) = 25 + 30 sin(2*pi*t/24 h) + 10 sin(2*pi*t/7 d) degC. Copy that file's contents unchanged into your netlist, including the lines `.param LK=1` and `.param THOLD=-999`. LK scales all leakage, and the stage must work for any LK from 0.5 to 4.

You may add only resistors and at most four clamp instances (DIODEA or DIODEB, any mix). One resistor must connect in to sn, at most 10 kOhm. No other parts and no analysis commands.

Requirements, each at every LK from 0.5 to 4 unless stated:
1. Peak sn voltage during the day-0 surge: <= 4.0 V.
2. sn voltage from day 0.5 to day 30: between 1.2 V and 1.8 V.
3. Residual of sn voltage over days 2 to 30, sampled every 10 min: RMS <= 2.0 mV. The residual is V(t) minus its least-squares fit to exactly two terms, a constant and a term proportional to (T(t) - 25).
4. Current delivered by the 3.0 V rail with the board held at constant temperature (THOLD) and no surge: <= 150 nA at 25 degC and <= 200 nA at 65 degC.
5. DC small-signal resistance seen at sn to ground at 25 degC: >= 40 MOhm.
6. Construction as stated above: fixed file unchanged, allowed parts only, series resistor <= 10 kOhm.
7. design.json values agree with the netlist to within 1 %.

Deliverables under /app/output/:
- stage.cir: SPICE netlist of the stage.
- design.json: {"series_resistor_ohm": number, "resistors": [{"name": string, "node1": string, "node2": string, "ohm": number}], "clamps": [{"instance": string, "model": "DIODEA"|"DIODEB", "anode": string, "cathode": string}]}.
