### 00 · Standby sense-node protection and bias stage — advance, rank 8

Design decision as written: yes — "We need the input protection and bias stage for our battery-backed sensor board ... You may add only resistors and at most four clamp instances"; the deliverable is a netlist whose topology and component values are the agent's choice, subject to the stated requirements.

Forge task: Design the added resistor/clamp network for a floating 4.7 nF sense node (surge clamp ≤ 4.0 V peak, node held 1.2-1.8 V over 30 days, two-term-fit RMS residual ≤ 2.0 mV at every LK in [0.5, 4], rail current ≤ 150/200 nA, DC resistance to ground ≥ 40 MOhm), emitted as stage.cir plus design.json, checked by scripted ngspice runs.

Why it fits:
• It is a bounded analog design decision (part selection, topology and resistor values within a fixed part whitelist), not an analysis deliverable; the agent must choose values, not characterise a given circuit.
• Every requirement is a circuit quantity a headless ngspice run can evaluate: transient peak and window (R1, R2), sampled-and-fitted residual (R3), DC supply current (R4), small-signal input resistance (R5), and parseable construction rules (R6, R7).
• The constraints genuinely interact: raising bias resistance eases R4 and R5 but worsens the surface-leakage ramp in R3; clamp leakage must be balanced above and below sn to cancel the exponential temperature term; the surge requirement pushes Rs and clamp selection. That coupling, not hidden rules, is the difficulty.
• Held-out LK points inside the declared range and a fixed two-term basis make the pass/fail surface objective; the grader plan is explicit (append analysis to the submitted netlist).

What stops it:
• Structural: nothing. The idea is a design task with scriptable checks.
• Unresolved feasibility risks (author claims, not verified): the reference outline states the feasible bias window is "about 40 to 53 MOhm" and admits thresholds are provisional until a reference run is done. R5's 40 MOhm floor and R3's 2.0 mV ceiling leave a claimed ~15% margin at the worst corner (LK = 4), against a 2% integrator-difference allowance.
• Unverified: whether ngspice, with behavioural sources at 10-140 pA and 45 MOhm-1 GOhm resistances over a 30-day transient, reproduces the residual to better than the grader's tolerance; default reltol/gmin/vntol can put pA-scale node currents inside the numerical noise floor.
• Unverified: the claimed failures of the listed public designs (1 GOhm bias, single-sided clamp, electrometer buffer) are author assertions; no run is supplied.

How to check it:
• ngspice (transient, DC op, AC 1 mHz): surge peak of v(sn) and day 0.5-30 min/max at LK 0.5/1/4 plus held-out 0.7/2.5; 30-day v(sn) resampled at 600 s for the two-term numpy fit residual; Vdd current at THOLD 25 and 65 for LK 1/4 (+2.5); |V/I| at sn at 1 mHz for LK 0.5/1/4 (+1.8).
• Python parser: board_env.inc text verbatim in stage.cir, only resistors and ≤ 4 X-instances of DIODEA/DIODEB, in-to-sn resistor ≤ 10 kOhm, no analysis commands, design.json values within 1% of the netlist.
Simulation gaps:
• The behavioural clamp (exponential with min() limiting, pow() temperature term) is an idealised junction: no breakdown, no self-heating, no real-part tolerance, no PCB surface-leakage distribution beyond the linear ramp. Matching clamps cancels leakage only as well as the two behavioural instances match — real DIODEA/DIODEB spreads would not cancel this cleanly.
• Numerical accuracy of the 30-day transient at pA currents and minute-scale timesteps is uncharacterised; integrator and gmin choices can move the residual by more than the 2% allowance. This must be measured, not assumed.
• Surge behaviour is dominated by the ideal 8 V/100 Ohm behavioural generator and lumped Rs; real ESD waveforms and clamp tolerances are not modelled.
Why frontier models fail:
• Plausible, subject to trials: the pass/fail hinges on a nonstandard residual definition (exactly two basis terms, constant plus (T-25)); a solver that fits or inspects a linear-in-time term sees a clean proxy while the ramp-driven residual fails R3 at high LK. The feasible bias window is squeezed between R5's floor and R3's ceiling, and clamp leakage must be balanced across temperature, which requires reasoning about cancellation rather than a single worst-case number. All of this is a hypothesis until a model trial is run.
Real-world risks:
• Behavioural diodes and an idealised surface-leakage ramp are stand-ins for real parts; a built board's leakage spread, humidity dependence and part tolerance could blow the ~15% residual margin.
• 1% resistors in the 80-100 MOhm range exist but their voltage coefficient, board contamination and guard layout dominate the real node resistance; the model gives no credit or penalty for layout.
• The 30-day stability claim is inferred from a quasi-static model; no physical calibration-interval data corroborates it.
Milestones (if too big): not required as written; if runtime measurements show the 30-day transient is prohibitive, split into (1) surge + DC + AC checks and (2) long transient + residual fit as standalone tasks with their own graders.
What to change (reshape): none — pin down the items below rather than reshape.
Numbers to supply next:
• Requirement (verification still needed): demonstrated feasible design inside the claimed 40-53 MOhm window at LK = 4 with measured margin to 2.0 mV, plus reproduction of a baseline failure (e.g. 1 GOhm bias) under the exact two-term fit.
• Verification: measured ngspice runtime and numerical noise of the 30-day transient at pA currents (e.g. residual shift < 0.2 mV between reltol 1e-4 and 1e-6, runtime < 10 min per LK corner).
• Interface (specification gap): whether the CLAMPG/DIODEA/DIODEB tc pin must be wired to node tc in stage.cir and whether design.json's clamp schema omits it implicitly — state "all clamp tc pins connect to node tc" explicitly.
• Interface: initial condition at t = 0 for the 30-day transient (e.g. "DC operating point at t=0 with THOLD=25, no UIC") and the transient command block the checker appends (tstop, maxstep, e.g. 30 d with maxstep 600 s away from the surge).
• Requirement: simulator tolerance set used by the checker (gmin, reltol, abstol, vntol, e.g. gmin=1e-15, reltol=1e-5) so a solver can verify against the same numerics.
• Handbook data: resistor series available (e.g. E24 values 1 MOhm-1 GOhm, 1%) and confirmation that ideal values are used in the netlist.
• Output format: confirmation of the design.json schema as given, including whether duplicate resistor values and unused nodes are permitted.

Evidence status: draft-only. The environment text, reference outline, distinct valid designs, public-design failure claims and the 40-53 MOhm window are author claims; no file has been inspected and no simulation has been run by this review. Reference outline is a proposed solution, not a passing design. "fits one run" and "frontier models fail" remain hypotheses pending a reference run and runtime measurement.

Checks before full-task readiness: (1) reproduce one claimed baseline failure under the exact two-term metric; (2) produce at least one passing netlist at LK = 0.5/1/4 and held-out 0.7/2.5/1.8 with the margin above the 2.0 mV limit quantified; (3) measure solver-noise sensitivity and runtime of the 30-day transient; (4) fix the clamp tc-pin and initial-condition interface items; (5) confirm design.json/netlist agreement checker behaviour on the reference netlist.