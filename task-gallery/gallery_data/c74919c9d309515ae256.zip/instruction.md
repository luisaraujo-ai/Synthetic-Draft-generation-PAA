I need the conditioning block between our resonant sensor (10 kHz class) and a phase-detecting ADC front end. The sensor tone wanders over 9.6 to 10.4 kHz as the sensor warms and ages, and the block's own parts drift too. The block has to give selective gain, limit large signals softly so the ADC is never overdriven, and settle and stay phase-coherent every time the tone starts or steps. I'm leaving the topology to you.

Fixed interfaces: the source is an ideal sine EMF with a 1 kOhm series resistance, amplitude 5 to 400 mVpk, at any frequency in 9.6 to 10.4 kHz. The load is 100 kOhm in parallel with 20 pF to ground. The supply is a single 5 V rail (4.75 to 5.25 V). Active parts are only the supplied op-amp subcircuit OPA (5 MHz gain-bandwidth, rail-to-rail, 0.5 mA quiescent from VCC) and diode model DLIM (Is 1e-14 A, n 1.8, Rs 10 Ohm), both in /app/input_assets/models.lib. Every R, L and C in your block may sit anywhere within +/-3 % of its value, independently or together. Diode Is may vary 0.5x to 2x, diode n 1.7 to 1.9, and op-amp GBW 4 to 6 MHz. All limits below must hold across all of these and across the whole frequency and amplitude range.

Requirements (Vout is the load voltage; gain is Vout amplitude over source EMF amplitude; the tone starts at t = 0 with the circuit at its DC operating point; cycles count at the drive frequency):
1. Small-signal gain at 5 mVpk: at least 38 dB at every frequency in the band.
2. Output amplitude about its mean: at most 1.8 Vpk at every amplitude and frequency, and Vout stays within 0.1 to 4.9 V at all times.
3. Settling: the per-cycle output amplitude at cycle 30 is within 2 % of its final value, for 5, 50 and 400 mVpk tones.
4. Periodicity: between the 10-cycle windows at cycles 40 to 50 and 50 to 60, the amplitude changes by at most 0.1 % and the phase relative to the input by at most 0.2 degrees, for 5, 50 and 400 mVpk.
5. THD at 400 mVpk, over an integer number of cycles in steady state, harmonics 2 to 9: at most 5 %.
6. Orbit return: starting from capacitor and inductor initial states perturbed up to +/-1 V and +/-1 mA, the output amplitude and phase after 80 cycles match the unperturbed start to within 0.5 % and 0.5 degrees, at 5 and 400 mVpk.
7. Amplitude step of +/-20 % (5 to 6 mVpk, 320 to 400 mVpk, 400 to 320 mVpk): output amplitude within 2 % of the new final value 30 cycles after the step, and sub-harmonic content at half the drive frequency at most 0.5 % of the fundamental.
8. Average supply current at 400 mVpk: at most 5 mA.

Deliverable: /app/output/block.cir, a SPICE netlist containing one subcircuit named BLOCK with ports VIN VOUT VCC GND, where VIN is the node after the 1 kOhm source resistance. It may contain only R, L, C, diode (model DLIM) and OPA instances, no sources, no .include and no definitions of OPA or DLIM, and no more than 40 elements. The source, load and supply are applied from outside.
