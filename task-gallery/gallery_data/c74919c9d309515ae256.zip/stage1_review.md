### 26 · Band-tolerant selective conditioning amp with soft limiting — advance, rank 8

Design decision as written: yes — "I'm leaving the topology to you" and "Deliverable: /app/output/block.cir, a SPICE netlist containing one subcircuit named BLOCK with ports VIN VOUT VCC GND". The agent chooses the topology and component values of a physical circuit; the brief fixes only interfaces, models and limits.

Forge task: Design a ≤40-element single-supply BLOCK subcircuit (R, L, C, DLIM diodes, OPA instances only) between a 1 kΩ-source 5–400 mVpk tone wandering over 9.6–10.4 kHz and a 100 kΩ ∥ 20 pF load, giving ≥38 dB small-signal gain at 5 mVpk while softly limiting to ≤1.8 Vpk about the mean (Vout inside 0.1–4.9 V at all times), settling to 2% by cycle 30, window-drifting ≤0.1% amplitude and ≤0.2° phase, ≤5% THD at 400 mVpk, returning to the unperturbed orbit within 0.5%/0.5° after ±1 V / ±1 mA state perturbations, meeting ±20% amplitude-step and sub-harmonic limits, and drawing ≤5 mA from VCC — all across ±3% R/L/C corners, diode and GBW spread, and 4.75–5.25 V supply.

Why it fits:
• Physical design decision with a machine-checkable artifact: a SPICE netlist embedded by the checker and measured by transient simulation plus numpy DFT extraction; any topology is accepted.
• Every stated requirement maps to a headless computation: gain (fundamental/EMF), peak and absolute range (waveform scan), settling and window drift (per-cycle DFT over 100 cycles), THD (DFT, integer cycles), orbit return (re-run with .ic perturbations), step response and half-frequency bin, average VCC current.
• The difficulty is real engineering: the gain floor needs peak gain across an effective detuning range of roughly ±10% (band edges ±4% plus component-driven f0 shift up to about ±6%), while R3/R4/R6 force low envelope Q; the limiter must compress more than 20x at 400 mVpk without killing small-signal gain or producing >5% THD or a half-frequency limit cycle. Placing the limiter, staggering sections and filtering harmonics afterwards are coupled decisions.
• Plausible bounded deliverable: one netlist, ≤40 elements, ~5 OPA instances fit the 5 mA budget with margin for a bias divider.

What stops it:
• Structural: none identified; the task is a design task as written and its metrics are all computable in a circuit simulator.
• Unresolved feasibility risks (not structural objections): (a) the reference outline is explicitly "provisional, not yet simulated" — no passing design has been demonstrated, so achievability of R1 + R3/R4 simultaneously under corners is an assumption; (b) the behavioural OPA (single pole, hard min/max clamp at 50 mV from rails, no slew rate, no output impedance or current limit) and DLIM with zero junction capacitance may let designs pass that would misbehave with real parts or with a differently smoothed exponential; (c) the checker's corner strategy (named mixes vs number of random draws) and its tolerance for numerically fragile designs materially change pass rates; (d) total grader sweep (21+ band points × amplitudes × corners × two time steps) may reach hundreds of 100-cycle transient runs; runtime is unmeasured.

How to check it:
• ngspice: transient from DC operating point, 100 cycles at T/400 and T/800 steps, embedding block.cir with the supplied source (EMF + 1 kΩ), load and models.lib; per-cycle fundamental amplitude and phase via numpy DFT; peak/mean/min/max of Vout; THD from DFT over integer cycles in 60–70; sub-harmonic bin over a 20-cycle window; VCC source current averaged over steady-state windows.
• Corner handling: scale each R, L, C by multipliers in [0.97, 1.03] independently and in correlated mixes (all R high with all C high, etc.), plus GBW 4–6 MHz and diode Is 0.5–2x, n 1.7–1.9, supply 4.75/5.25 V.

Simulation gaps:
• OPA is idealised: no slew rate, no output current limit, no input capacitance/bias current, output clamped by a non-smooth min/max — solver behaviour at the clamp and under diode exponential smoothing (gmin variation) can change verdicts; the brief's request for step/smoothing independence is stated but not proven.
• DLIM has no junction capacitance, so THD and settling in a real limiter differ.
• Initial-state perturbations: ngspice .ic specifies node voltages; how ±1 mA inductor-current perturbations are applied is not specified and is simulator-dependent.
• Envelope/measurement definitions are well specified in principle, but window edge effects, DC bias drift during AC-coupled start-up, and amplitude extraction near band edges within 20 Hz are numerical corner cases.

Why frontier models fail:
• Hypothesis, not verified by trials: the constraints are genuinely coupled — per-section Q must be low enough for R3/R4/R6 yet high enough that the staggered cascade keeps ≥38 dB over ±10% effective detuning, under GBW limits (5 MHz op-amp at 10 kHz gives only ~54 dB open-loop, less at 4 MHz corner), while the limiter must hold ≤1.8 Vpk with ≤5% THD after filtering and must not introduce a half-frequency orbit. Nominal-only sweeps can look passing while corner draws and held-out band-edge points fail.

Real-world risks:
• A design validated only against this model set may not survive real op-amp slew, output impedance, supply rejection, noise, diode capacitance, or parasitic coupling; ±3% R/L/C is generous versus 1% parts but the diode spread and AC-coupling corner assumptions dominate.

Milestones (optional, if the single-run sweep proves too heavy): 1. Gain-and-bandwidth milestone: cascade of selective stages meeting R1/R2 at 5 mVpk across corners, checked by frequency-sweep plus short transients. 2. Limiter milestone: add soft limiting to meet R2/R5 at 400 mVpk. 3. Full-dynamics milestone: complete BLOCK meeting R3/R4/R6/R7/R8.

Numbers to supply next:
• Requirement: exact corner sampling — e.g. named corner list (all-low, all-high, R-high/C-high, R-low/C-low) plus N=20 random draws with a stated seed; and the rule for verdicts where coarse and fine time steps disagree.
• Requirement: application of initial-state perturbations — e.g. "inductor currents perturbed by inserting a 1 ns current-source pre-phase, or .ic on designated nodes", with the exact ngspice syntax; specify whether GND-referenced node voltages are perturbed only for capacitor states.
• Requirement: measurement windows — e.g. supply-current average over cycles 60–90; amplitude-step applied at a stated integer cycle (e.g. cycle 20) with the step magnitude carried into the transient source.
• Interface: input files (/app/input_assets/models.lib as given, checker harness) and output schema (block.cir; element-count convention — does an OPA instance count as one element?); max node count and whether .param/.func lines are forbidden alongside behavioural expressions.
• Handbook data: ngspice version and options (gmin value, reltol/abstol, exponential smoothing form), simulation temperature (300 K as stated), and the maximum number of OPA instances implied by the 5 mA budget at 0.5 mA quiescent each (e.g. ≤8 plus a divider ≤2.5 mA).
• Verification still needed (not a widened limit): demonstrate one passing design on the checker; reproduce a stated public-design failure (e.g. single MFB bandpass) to confirm discrimination; measure full-sweep runtime and the T/400 vs T/800 numerical noise floor; confirm the min/max behavioural clamp and diode smoothing variants give the same verdict.

Evidence status: draft-only. The embedded models.lib text establishes supplied model text, not simulator fidelity or asset presence on disk. The reference outline is author-declared "provisional, not yet simulated"; public-design failure claims, stated margins (Q ranges, dB drops, compression factors) and the mechanism-survival narrative are author claims and hypotheses, not verified evidence. No simulations were run and no filesystem inspected for this review. Stated requirement: the eight requirement rows and the netlist contract. Engineering inference: effective detuning up to roughly ±10%, per-stage envelope time constant Q/π cycles (so R3 tolerates Q up to ~24 per slowest stage and R6 up to ~47), and the 5 mA budget implying roughly ≤8 OPA instances.

Checks before full-task readiness: (1) demonstrate a passing design at nominal and at least the four named corner mixes; (2) reproduce at least one claimed-failing public design to confirm the metrics discriminate; (3) fix and document .ic semantics for inductor currents and validate perturbation application; (4) run the coarse/fine time-step pair and the gmin/smoothing variants on one candidate to confirm verdict stability; (5) measure checker runtime and decide the corner-draw count; (6) pin down element counting and forbidden constructs in the netlist grammar.