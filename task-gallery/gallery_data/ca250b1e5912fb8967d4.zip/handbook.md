# Handbook: oscillator supply branch

## Conventions
- Phase error phi(t) = 800 ps/V x (V(osc) - 3.3 V), sampled at 100 kHz by linear interpolation of the transient output. The sample grid starts at t = 0.
- Residual: over the stated window, solve the least-squares problem phi = a sin(2 pi f_b t) + b cos(2 pi f_b t) + c with f_b fixed by the state. The residual is phi minus that fit. The fit has exactly three coefficients. It has no slope or other terms. Report RMS (zero-mean over the window) and max minus min.
- A linear ramp of total height H over the window has RMS H/sqrt(12) = 0.29 H and peak-to-peak H. At 0.8 ps/mV, 1 mV of ramp is 0.8 ps pk-pk and 0.23 ps RMS.
- A sinusoid of peak-to-peak P has RMS P/(2 sqrt 2) = 0.35 P. A 2.0 ps RMS tone is 5.7 ps pk-pk, which is 7.1 mV pk-pk at osc.
- Harmonics of the pulse repetition rate other than the fundamental are not removed by the fit.

## Library cells (/app/input_assets/models.lib)
- LREG vin vout fb gnd refin: behavioural linear regulator. The error amplifier has DC gain 100 and a pole near 3 kHz. A fixed fraction 0.5 of vin feeds through to the pass node without that pole. Dropout is 0.3 V. Output resistance is 0.3 ohm. It needs a feedback divider from vout to fb, and its output voltage obeys vout = (100 (V(refin) - V(fb)) + 0.5 V(vin)) / (1 + 100 beta) for a divider ratio beta. Line sensitivity and PSRR therefore follow from loop gain, which falls with frequency. It has no current limit.
- REF out gnd: 1.25 V reference behind 10 kohm. It carries a 1 mV peak tone at 4.7 kHz, an initial offset (+/-3 mV) and a slow downward drift in state D.
- CAP a b C=value: capacitor with ESL 1 nH and ESR = 0.015 + 0.1 sqrt(1e-6/C) ohm.
- IND a b L=value: inductor with series DCR = 0.02 sqrt(L/1e-6) ohm. Use 100 nH to 100 uH.
- Plain resistors are ideal, 0.1 ohm to 1 Mohm.
- The feed source, the loads and the stimulus are attached externally. REF reads the globals refofs (V) and refdrift (ppm), which are set per state. Defaults are 0.

## Practice and checking notes
- Closed-loop regulators set the output from the feedback divider ratio. The reference offset and the feedthrough term shift the DC level. Settling bands are measured on the actual simulated node voltage.
- Capacitive loading on a regulator output with finite output resistance adds a pole. Check ringing across the full 10 nF to 100 uF decoupling range with the ESR and ESL given.
- A series resistor in a filter drops I x R at DC. The branch carries 25 mA plus the digital load pulses (150 mA peak) if that load is connected downstream.
- The 31.25 kHz ripple is well inside the 100 kHz sampling Nyquist band. It is not a pulse harmonic, so it remains in the residual.
- Simulate with a maximum timestep of about 2 us or less and ideal-stimulus edges as in input.json.
- Windows are in seconds from the start of the run. All states begin with the feed ramping 0 to 12 V in 5 ms.
- Held-out corners: reference offset in [-3, +3] mV, sag in [0.8, 1.2] V, and drift in [300, 600] ppm.
