Hi, our system team needs a 3.3 V supply branch for the 10 MHz reference oscillator on a mixed-signal instrument board, fed from the 12 V board rail. The oscillator shares that rail with a pulsed digital load. The oscillator's supply-induced phase error must stay small in every operating state. The topology is yours.

Interface: deliver a subcircuit named pdn with ports feed, osc, dig, gnd. We attach the 12 V rail at feed (already behind 0.2 ohm + 1 uH, with 0.3 V pk-pk ripple at 31.25 kHz). We attach the oscillator load at osc (132 ohm in parallel with 10 nF) and the digital load current pulses (150 mA) at dig. Build it only from the cells REF, LREG, CAP and IND in /app/input_assets/models.lib plus plain resistors. Do not redefine those cells. Capacitors are 10 nF to 100 uF. Stimulus timing and ranges for every state are in /app/input_assets/input.json.

Phase error = 0.8 ps per mV of osc deviation from 3.3 V. The phase residual is the phase error minus a least-squares fit of a sinusoid at the stated beat frequency (free amplitude and phase) plus a constant, over the stated window. Residual RMS and peak-to-peak are measured at node osc.

Requirements, all with the reference offset anywhere in +/-3 mV:
1. State A (cold start, then steady 1 kHz, 20% duty pulses): residual RMS <= 2.0 ps and peak-to-peak <= 8.0 ps over 0.05 to 0.55 s.
2. State B (pulse load steps at 0.1 s from 1 kHz, 20% duty to 7 kHz, 40% duty): residual RMS <= 2.0 ps and peak-to-peak <= 8.0 ps over 0.2 to 0.7 s, beat 7 kHz.
3. State C (12 V feed dips to 9 V for 10 ms at 0.1 s): residual RMS <= 2.0 ps and peak-to-peak <= 8.0 ps over 0.2 to 0.7 s.
4. State D (feed sags linearly by 0.8 to 1.2 V from 0.1 to 0.7 s while the reference drifts down by 300 to 600 ppm over the same interval): residual RMS <= 2.0 ps and peak-to-peak <= 8.0 ps over 0.2 to 0.7 s.
5. State A: V(osc) within 3.3 V +/-1% from 20 ms to the end of the run.
6. State C: V(osc) within 3.3 V +/-2% from 0.1 s to the end of the run, including during the dip.
7. Node dig stays >= 3.0 V from 30 ms onward in every state.
8. At most 12 elements in pdn, counting each resistor, CAP, IND, LREG and REF instance. No sources or other elements, and no other model cells.

Deliverable: /app/output/pdn.cir, a SPICE netlist holding the pdn subcircuit.
