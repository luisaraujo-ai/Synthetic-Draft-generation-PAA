### 02-osc-supply-phase-residual-pdn · Regulated 3.3 V oscillator supply branch with bounded phase residual — advance, rank 8

Design decision as written: yes — "The topology is yours." / "Build it only from the cells REF, LREG, CAP and IND in /app/input_assets/models.lib plus plain resistors." / "deliver a subcircuit named pdn with ports feed, osc, dig, gnd."

Forge task: Design a <=12-element PDN subcircuit (topology free: LREG stages, REF, CAP, IND, resistors) that derives 3.3 V from the 12 V feed and holds supply-induced phase residual at osc under 2.0 ps RMS / 8.0 ps pk-pk in four states (pulse load, load-rate step, feed dip, feed sag + reference drift) with the digital node held >= 3.0 V.

Why it fits:
• A design decision (topology, stage count, filter placement, component values, divider ratios) that a headless script can fully exercise: ngspice transient runs per state per corner, plus netlist parsing for R8.
• The trade-offs are physically coupled and genuinely hard: the LREG's un-poled 0.5·V(vin) feedthrough and ~3 kHz loop pole mean the 31.25 kHz feed ripple (not removed by the fit) drives AC rejection, while the state-D sag drives DC line rejection; added stages and filters consume the 12-element budget and add poles that must not ring into the 10 nF–100 uF load range.
• All limits, windows, fit basis (exactly sin + cos + constant), stimulus and library models are already specified in the payload, so a full task can be written from it.

What stops it:
• Structural objections: none. It is a design task, not analysis or tooling.
• Unresolved feasibility risks (author claims, unverified): the claim that single-stage designs fail R4 by 1.2–1.8x and R1 from 31 kHz feedthrough is stated in the draft but not demonstrated; a two-stage cascade plus reference RC is asserted to fit within 12 elements, which has not been counted or simulated. The mechanism note (a solver's own metric with a slope term masks the sag ramp) is a plausible hazard, not a tested one.
• Whether a passing design exists at every held-out corner is unknown until a reference design is simulated.

How to check it:
• ngspice: transient per state at max step <= 2 us, refofs in {-3, 0, +3} mV plus held-out offsets; read V(osc), V(dig); resample at 100 kHz; phi = 800 ps/V x (V(osc) - 3.3); three-term least-squares fit at the state's beat frequency; residual RMS (zero-mean) and max-minus-min against R1–R4; band checks R5–R6; dig minimum R7.
• A netlist parser: .subckt pdn feed osc dig gnd header, element count <= 12, only R / CAP / IND / LREG / REF instances, no sources or undefined cells (R8).
• Runtime is unmeasured: 0.55–0.7 s at 2 us is 2.75e5–3.5e5 steps per run, ~16–20 runs per design evaluation; small circuit, so plausible but needs measurement.

Simulation gaps:
• LREG is behavioural: B-source with min/max clamp, one pole, fixed 0.3 ohm Rout, no current limit, no thermal, no startup/soft-start dynamics, no PSRR data beyond the stated formula. A real LDO's PSRR, stability and dropout behaviour will differ.
• CAP ESR/ESL and IND DCR are idealised formulas with no tolerance, ageing, DC-bias derating or temperature dependence; no PCB layout parasitics or mutual coupling between the osc and dig branches is modelled.
• The 100 kHz resampled phase metric and linear interpolation are a modelling convention; sub-sample ripple and simulator timestep/noise sensitivity (2x timestep variation is accepted) are not characterised.
• Whether the grader sweeps component tolerances is unspecified; without it, nominal-only passing says little about a buildable board.

Why frontier models fail: hypotheses, not trials. The three-term fit deliberately refuses to absorb a slope, so a design that looks fine under a self-written sloped fit fails R4/R2/R3 tails; simultaneously the 31.25 kHz ripple sits inside the sampled band and is not fitted out, the 7 kHz pulse harmonics are not fitted out, and the element cap plus stability across the decoupling range constrains the obvious fix. Getting DC rejection, AC rejection, ringing margin and 12 elements right at once is a real multi-objective problem.

Real-world risks:
• Passing the behavioural bench does not establish a working board: real LDO loop gain/PSRR, real capacitor ESR/ESL spread and inductance of the layout can dominate the 1 mV-scale budgets being held.
• Reference drift/offset modelling is simplified (linear drift ramp, one tone); a real reference has noise and drift spectra the model omits.
• dig load return path and shared ground impedance are ideal here; on hardware they couple pulse noise into osc.

Milestones: not required on the evidence available — the task plausibly fits one run, subject to a measured per-run simulation time. If runtime or iteration count proves excessive, split as: (1) DC/AC line-rejection architecture sized against R3/R4 at a fixed topology; (2) stability and ripple across the decoupling range (R1/R2) and element-budget-legal netlist.

What to change (reshape): none — advance as written once the numbers below are supplied.

Numbers to supply next:
• Missing specification — tolerance policy: whether the grader sweeps CAP/IND/resistor tolerance or nominal values only; e.g. caps ±20%, inductors ±10%, resistors ±1%, swept at the corners.
• Missing specification — dig load waveform definition: 0 to 150 mA square pulses with 1 us edges, or symmetric ±150 mA; e.g. 0/150 mA, edge 1 us, start 0.02 s.
• Missing specification — simulator and options: ngspice version, .options (reltol, method, maxstep 2 us), and whether a solver's transient may be run longer than sim_end_s; e.g. ngspice 42, trap, maxstep 2e-6.
• Missing specification — netlist legality details: whether .param/.include lines are permitted in pdn.cir and whether the element count includes anything outside the .subckt body; e.g. .include forbidden, count instances inside .subckt only.
• Interface — checker bench asset: the wrapping bench netlist (source, 0.2 ohm + 1 uH feed, ripple, loads, state stimulus) as a concrete file, e.g. /app/input_assets/bench_<state>.cir; plus confirmation that models.lib and input.json exist and match the embedded text.
• Output schema — confirm: single file /app/output/pdn.cir containing exactly one .subckt pdn feed osc dig gnd with no internal .subckt definitions; output metrics reported where, if anywhere (e.g. a metrics.json, or checker-only).
• Verification still needed (not spec gaps) — reproduce the claimed single-stage failure at R4/R1 to confirm the difficulty premise; produce one passing reference design across G2–G5 including held-out points; measure per-run runtime and convergence with the B-source clamps at 2 us step; confirm the metric implementation matches the handbook exactly (three terms, zero-mean RMS, pk-pk = max - min).
• Handbook data already present (no action): ESR = 0.015 + 0.1·sqrt(1e-6/C) ohm, ESL 1 nH, DCR = 0.02·sqrt(L/1e-6) ohm, LREG gain 100 / pole ~3 kHz / dropout 0.3 V / Rout 0.3 ohm, 0.8 ps per mV; restate component ranges: caps 10 nF–100 uF, inductors 100 nH–100 uH, resistors 0.1 ohm–1 Mohm.

Evidence status: draft-only payload. The library models and input.json establish supplied text only; I have not inspected /app/input_assets or run any simulation. The reference outline, distinct-design list, public-design failure claims (e.g. 'single LDO fails R4 by 1.2–1.8x'), stated margins and the mechanism_survival claim are unverified author claims. My ripple/feedthrough and drift arithmetic above is engineering inference from the supplied model text, not measured. No design is validated; 'advance' means worth developing.

Checks before full-task readiness: 1) simulate the named public designs to reproduce their claimed R1/R4 failures; 2) build and simulate one candidate reference netlist across all G2–G5 corners plus held-out points to show a passing design exists within 12 elements; 3) implement and cross-check the residual metric independently (three-term fit only) against the handbook; 4) measure transient runtime and timestep sensitivity (1 us vs 2 us) and confirm convergence with the LREG clamps; 5) decide and record the component-tolerance policy before freezing limits.