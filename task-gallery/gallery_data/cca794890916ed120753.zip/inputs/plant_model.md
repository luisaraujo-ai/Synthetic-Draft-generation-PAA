# Behavioural PLL plant (one update per reference cycle)

T = 100 ns (reference period), N = 64, f0 = 640 MHz, f_ref = 10 MHz, A = spur_amp_ps, f_s = spur_offset_hz, k = 0..7999.
Scenario parameters: Kv (Hz/V), m (mismatch fraction), leak (nA), dz (ps). Design: Icp (uA), R, C1, C2, bias (nA), ov (ps).

Initial state: tau_o[0] = 0; V1[0] = V2[0] = v_nom + initial_freq_offset_hz/Kv.

Per step k:
1. tau_ref[k] = A*sin(2*pi*f_s*k*T) + (k >= hop_step ? (k - hop_step)*T*hop_ref_hz/f_ref : 0)  [seconds, A converted from ps].
2. e[k] = tau_ref[k] - tau_o[k].
3. dz_eff = max(0, dz - ov). If |e| <= dz_eff/2 then u = 0, else u = e - sign(e)*dz_eff/2. Then u = clip(u, -T, +T).
4. Charge: Q = Icp*u*(1 + (m/2)*sign(u)) + Icp*m*ov + (bias - leak)*1e-9*T   [Icp in amps, ov in seconds, sign(0) = 0].
5. V2' = V2[k] + Q/C2.
6. [V2[k+1]; V1[k+1]] = expm(M*T) [V2'; V1[k]] with M = [[-1/(R*C2), 1/(R*C2)],[1/(R*C1), -1/(R*C1)]]. Then clip both voltages to [v_min, v_max].
7. tau_o[k+1] = tau_o[k] + T*Kv*(V2[k] - v_nom)/f0.

Reported series: e[k] in ps.

# Metric definitions
- Fixed-basis residual: over a window, least-squares fit of e to [1, sin(2*pi*f_s*k*T), cos(2*pi*f_s*k*T)] only. Residual RMS = RMS of e minus fit, in ps.
- Cold lock time: smallest k_L such that |e[j] - mean(e[3500:4000])| <= 150 ps for every j from k_L to 3999; time = k_L*T.
- Relock time: smallest k_R >= 4000 such that |e[j] - mean(e[7500:8000])| <= 150 ps for all j from k_R to 7999; time = (k_R - 4000)*T.
- Cycle slips: number of k with |e[k]| > 50 ns and |e[k-1]| <= 50 ns.
- Mean phase error: mean of e over the window, in ps.

# Linearised loop gain (Laplace)
L(s) = (Icp/T) * (Kv/f0) * Z(s) / s, with Z(s) = (1 + s*R*C1) / ( s*(C1 + C2) * (1 + s*R*C1*C2/(C1 + C2)) ). Icp in A, Kv in Hz/V. Crossover = highest frequency with |L(j*2*pi*f)| = 1. Phase margin = 180 deg + angle(L) at crossover.