Hi, I need a loop block for the timing card on our data-acquisition module. It is a charge-pump PLL with a passive loop filter, a 10 MHz reference and a divide-by-64 feedback path. The reference carries a 20 ps phase spur at 250 kHz offset, and the charge pump has mismatch, leakage and a dead zone that spread with temperature. Please size the loop and pick the compensation settings so it meets our datasheet numbers.

Fixed inputs are in /app/input_assets/plant_model.md (the behavioural plant, the loop-gain definition and the metric definitions) and /app/input_assets/input.json (ranges, three corner sets, windows, design bounds). Reference hop of 12 kHz at 400 us, cold start with a 2 MHz output frequency error.

Requirements. Everything must hold at the three corners in input.json and at any other point inside the declared ranges (kv, mismatch, leakage, dead zone):
1. Phase residual RMS <= 5.0 ps in window A (samples 2000-3999, 200 us), where the residual is the phase-error series e[k] (ps, one sample per reference cycle) minus its exact least-squares fit of a constant plus a sine and cosine at 250 kHz and nothing else.
2. The same residual, same limit, in window B (samples 6000-7999) after the hop.
3. Cold-start lock time <= 60 us.
4. Relock time after the hop <= 60 us.
5. Cycle slips (|e| crossing 50 ns) = 0 over the whole run.
6. |mean of e| <= 120 ps in each of windows A and B.
7. Unity-gain loop crossover <= 100 kHz at kv = 125 MHz/V, using the linearised loop gain defined in plant_model.md.
8. Phase margin >= 45 degrees at both kv = 75 MHz/V and 125 MHz/V.
9. Design values within the bounds in input.json: charge-pump current 10-100 uA, R 100 ohm-100 kohm, C1 100 pF-10 nF, C2 1-200 pF, bias current 0-50 nA, overlap 0-120 ps.

Deliverable: /app/output/design.json, a JSON object with numeric fields icp_uA, r_ohm, c1_pF, c2_pF, bias_nA, overlap_ps (SI-prefixed units as named).
