### 15 · Charge-pump PLL fixed-basis phase residual — advance, rank 8

Design decision as written: yes — "Please size the loop and pick the compensation settings so it meets our datasheet numbers" / deliverable "design.json ... icp_uA, r_ohm, c1_pF, c2_pF, bias_nA, overlap_ps".

Forge task: Choose charge-pump current, R, C1, C2, bias current and overlap for a type-II charge-pump PLL with passive loop filter (10 MHz reference, N=64, 640 MHz output) so that the simulated fixed-basis phase residual is ≤5.0 ps RMS in windows A and B at three corners and held-out points inside the declared kv/mismatch/leakage/dead-zone ranges, cold-start and relock ≤60 µs, zero cycle slips, |mean e| ≤120 ps, crossover ≤100 kHz at kv=125 MHz/V and phase margin ≥45° at kv=75 and 125 MHz/V, with all six values inside the stated bounds.

Why it fits:
• A bounded configuration decision over six numeric design variables with a fully specified plant (state update, expm discretisation, voltage clipping) — no human judgement needed to score it.
• The whole verification stack is headless and open: numpy/scipy for the 8000-step discrete simulation and least-squares fit, and an analytic Bode computation of L(jω) for R7/R8.
• Difficulty comes from coupled nonlinear physics, not tolerance: the dead-zone nonlinearity plus uncorrected leakage produces a slow sawtooth drift in e[k] on the same 200 µs timescale as the scored window; overlap and bias pull in opposite directions (dz_eff = max(0, dz − ov) vs. the injected mismatch-overlap current and the 120 ps mean-error limit), so a feasible bias window of a few nA at Icp ~30 µA is plausible.
• The exact residual basis (constant + 250 kHz sin/cos only) is a genuine engineering trap: extra detrending terms (slope, quadratic) would absorb the slow wander and make an under-compensated design look passing. The brief states the basis explicitly, so a diligent solver sees the failure; a shortcut solver does not.
• Held-out points inside the ranges are part of the grading plan, so corner-tuned designs that fail at low-leak / negative-mismatch extremes are caught.

What stops it:
• Structural: none identified. The plant is specified equations, so every requirement R1–R9 is computable exactly as written.
• Unresolved feasibility risks (not structural objections): the draft asserts a narrow feasible bias window and that textbook designs fail by a large factor, but no simulation has been run — thresholds (5.0 ps, 120 ps, 60 µs) are the author's, and it is unverified that any design satisfies all of R1–R9 simultaneously. The 50 ns cycle-slip threshold plus the 2 MHz initial error also implies a capture transient whose time-to-lock under the dead zone is not yet demonstrated. Numerical conditioning of the expm update and the LS fit, and runtime of 11+ scenario simuations per candidate design within the ~2 h budget, are unmeasured.
• The provided `input.json` and `plant_model.md` are named specified dependencies; this review has not inspected the filesystem to confirm they exist or match the pasted text.

How to check it:
• numpy/scipy: integrate the per-reference-cycle plant (matrix exponential over T=100 ns, voltage clipping to 0.3–1.5 V) for all 3 corners plus 8 seeded held-out points in kv 75–125 MHz/V, mismatch ±0.10, leak 0.3–5.0 nA, dz 40–220 ps; extract e[k] in ps.
• numpy.linalg.lstsq on the fixed basis [1, sin(2πf_s kT), cos(2πf_s kT)]: residual RMS and mean of e in windows A [2000,4000) and B [6000,8000).
• Same simulation, definitions from plant_model.md: lock time vs. mean(e[3500:4000]), relock time vs. mean(e[7500:8000]), slip count at |e| crossing 50 ns.
• Analytic/computational Bode of L(s) = (Icp/T)(Kv/f0)Z(s)/s with Z(s) as given: crossover on a log grid refined to 0.1%, phase margin at kv=75 and 125 MHz/V.

Simulation gaps:
• The plant is behavioural: no VCO phase noise, no reference jitter beyond the deterministic 20 ps / 250 kHz spur, no charge-pump current noise, no supply/substrate coupling, no quantisation of the reset/overlap timing, no thermal drift within a run. Real silicon residual could exceed 5 ps RMS from noise sources absent here.
• The loop-gain model deliberately ignores mismatch, dead zone and leakage; PM/crossover computed there do not guarantee the nonlinear transient behaves.
• Held-out coverage is 8 seeded points — it samples, but does not prove, the whole 4-D range; worst case may sit between samples.
• Solver convergence of the LS fit and conditioning of expm(M·T) with extreme R·C products are unverified numerics.

Why frontier models fail:
• The metric basis is exactly three terms; a solver that adds a slope or quadratic to 'detrend' absorbs the dead-zone sawtooth and reports passing numbers for a design that fails R1/R2 — an honest-looking shortcut rather than a hidden rule, since the basis is stated.
• The bias current must satisfy conflicting inequalities across the leak/mismatch/dz range: keep |u_ss| above the ~20 ps spur swing at the low-leak, negative-mismatch corner while keeping dz_eff/2 + u_ss within 120 ps at dz=220 ps. Optimising only at the three nominal corners produces a design that fails held-out points.
• Coupled linear/nonlinear design: crossover, zero/pole placement and the dead-zone compensation interact through Icp (which sets both detector gain and the mismatch-overlap current and u_ss scaling), so the variables cannot be tuned independently.
• These are hypotheses consistent with the mechanism described in the draft; no model trials have been run.

Real-world risks:
• A design passing the behavioural checks would plausibly work on a real timing card only if the fabricated charge pump matches the model's dead-zone/leakage/mismatch parameterisation — model-to-hardware mismatch on the dead-zone shape and leakage temperature coefficient is the main gap.
• 5 ps RMS residual at 10 MHz reference is aggressive once reference jitter and VCO noise are included; a built loop could pass the model and still fail the datasheet number.
• The mean-error limit of 120 ps trades static phase offset against robustness; a real device needs guard band, which the bounds may not provide.

Milestones (if too big): not required — the full task plausibly fits one run (11+ scenarios × 8000 steps per candidate, trivially parallelised). If runtime proves excessive, split as: (1) static lock-point analysis (find bias/overlap satisfying u_ss and dz_eff constraints at all corners) graded by an analytic feasibility check; (2) linear filter sizing (R, C1, C2 for crossover/PM) graded by the Bode check; (3) full transient verification of all six values graded by the complete R1–R9 checker.

What to change (reshape): nothing structural.

Evidence status: author draft only. The plant equations, ranges, metric definitions and grader plan are supplied text, not executed artefacts. Claims that textbook designs fail R1/R2 by a large factor, that the feasible bias window is a few nA, and that 30–50 validation runs fit the budget are unverified author claims; no checker, reference design or runtime measurement has been inspected. Named files /app/input_assets/input.json and /app/input_assets/plant_model.md are specified dependencies, not confirmed assets.

Checks before full-task readiness:
• Confirm /app/input_assets/input.json and plant_model.md exist and match the quoted content, and that the checker implementation reproduces the stated metric definitions exactly.
• Produce a reference design that passes R1–R9 at all three corners and a large sweep (e.g. 200+ seeded points) of held-out points; if none exists, reassess the provisional thresholds rather than widening them without justification.
• Reproduce the claimed failures of at least the textbook (no bias, no overlap) and pure-overlap public designs under the exact basis, and demonstrate that adding a linear detrend term changes the residual as predicted.
• Measure wall-clock time of a full 3-corner + 8-held-out evaluation and of the candidate loop a solver would need (e.g. 30–50 evaluations), including float noise in the LS fit and expm update.

Numbers to supply next:
• Requirement: confirm the fixed limits (5.0 ps residual RMS, 120 ps |mean|, 60 µs lock/relock, 0 slips, 100 kHz crossover cap, 45° PM floor) as stated requirements and justify them against the timing-card datasheet — e.g. "phase residual ≤5 ps RMS at 250 kHz spur".
• Requirement: lock/relock band definition (already given as 150 ps about a specified mean window) and whether lock time is measured in µs from k=0 and k=4000 — e.g. "60 µs from t=0".
• Interface: input files /app/input_assets/input.json (as pasted) and /app/input_assets/plant_model.md (as pasted); output /app/output/design.json with schema {"icp_uA": number, "r_ohm": number, "c1_pF": number, "c2_pF": number, "bias_nA": number, "overlap_ps": number}; checker script path and its RNG seed for the 8 held-out points — e.g. seed 12345.
• Handbook data: charge-pump mismatch range ±10%, leakage 0.3–5.0 nA, dead zone 40–220 ps (already declared); additionally, the datasheet figures the 5 ps / 120 ps limits come from and any guard-band policy — e.g. "design target 3.5 ps to allow model error".
• Verification still needed: reference design simulation results, held-out sweep size and pass rate, and measured per-evaluation runtime — e.g. "reference design passes 200/200 random points, 40 s per full evaluation".