FIXED STAGE (all values nominal)
- Source: ideal 48 V in series with 20 mohm, then 20 uF input capacitor with 5 mohm ESR across the half-bridge. Input power is measured at the ideal source terminal, so the 20 mohm counts as loss.
- Half-bridge: two identical switches, subcircuit SWM in models.lib (terminals drain, gate, source). Each contains a 2 ohm gate resistor, Ron about 12 mohm at 10 V gate drive, 400 pF output capacitance, about 20 nC gate charge, and a body diode. Your extra Rgate is in series with each gate outside the subcircuit. Gate drive is an ideal 0/10 V source with 1 ns edges. Each switch is on for half a period minus a 40 ns dead time at each edge (high side on first). Duty is nominally 50 %. Gate-drive power is excluded from efficiency.
- Tank: half-bridge midpoint -> Rd -> Lr -> Cr -> transformer primary. Lr and Lm each carry a series ESR R = 2*pi*200 kHz*L/80 (inductor Q of 80 at 200 kHz). Cr has 5 mohm ESR. The snubber (Rsn in series with Csn) is across the primary.
- Transformer: magnetising inductance Lm across the primary, plus an ideal transformer with primary:secondary ratio n:1 (Vsec = Vpri/n, Isec = n*Ipri), no extra leakage (Lr is all the leakage).
- Parasitic capacitance: 150 pF x scale across the primary and 150 pF x scale across the secondary (rectifier input). Scale is a test condition from 0.7 to 1.3.
- Rectifier: full bridge of four DSCH diodes (models.lib) from the secondary.
- Output: 100 uF with 10 mohm ESR across the rectifier output, then an ideal current sink of 2, 3.5 or 5 A (load steps are instantaneous). The sink stays active for any output voltage above 0 V.
- Drive frequency is fixed per run (open loop); the drive does not track the tank.

DEFINITIONS
- Cycle = one drive period. Efficiency = mean (Vout x Iload) / mean source input power over whole drive cycles in the steady-state window. Final value for settling = mean output voltage over the steady-state window; settling is the last cycle where the cycle-mean output deviates by more than 2 % of final value.
- Ripple = peak to peak of output voltage over the 50 steady-state cycles after removing the cycle-mean trend is not applied; plain peak to peak over the last 10 cycles of the window.
- Tank current = current through Lr. Phase = time of each rising zero crossing of tank current relative to the preceding rising drive edge of the high-side gate, expressed in degrees of the drive period; ringing crossings inside 100 ns after a switching edge are ignored.
- Half-frequency component: DFT amplitude of tank current at f/2 over the 50-cycle window, divided by the amplitude at f.
- Periodicity windows: cycles 161-180 and 181-200.
- Switch peak current: drain-source branch current magnitude including Coss and body diode.
- Convergence comparison: same condition from the random initial states versus the zero-state run (zero-state steady state is also taken at cycles 151-200 for the 200-cycle runs; the start-up run is longer).
- Numerical check: maximum internal step 5 ns, then 2.5 ns, trapezoidal integration, tight relative tolerance, same initial state.

FACTS FOR SIZING
- Fundamental-mode estimates: Z0 = sqrt(Lr/Cr), fr = 1/(2*pi*sqrt(Lr*Cr)), Rac = (8/pi^2) * n^2 * Vout/Iload, loaded Q = Z0/(Rac + Rd + ESR). Rectifier clamping puts the primary near +/-n*(Vout + diode drops) while conducting; the half-bridge gives +/-24 V across the tank after the DC-blocking capacitor.
- Series-resonant stages operated below resonance have discontinuous tank current; above resonance the switch current lags the voltage and switch-node transitions can be soft.
- Voltage gain of a series-resonant stage depends on frequency relative to fr more strongly as loaded Q rises.
- The tank currents of a lightly damped tank take many cycles to decay; the decay time constant is about 2*L_total/R_total.
- Rectifier forward drop at these currents is about 0.3 to 0.5 V per diode, so two diodes in series cost roughly 4 to 7 % of the output at 12 V.
- Efficiency in this class is typically 85 to 93 % depending on damping, gate resistance and operating point. Series damping resistors dissipate Rd x I_rms^2.
- Parasitic capacitance with magnetising and leakage inductance rings at several MHz when current in the rectifier reaches zero; a snubber or gate resistance changes how this ring and the switching-edge timing behave.
- Checker test points: drive frequencies within 174.6 to 226.6 kHz (not disclosed, including values near both ends), loads 2, 3.5, 5 A, parasitic scales 0.7 and 1.3, and several random initial states drawn uniformly from the stated ranges.
