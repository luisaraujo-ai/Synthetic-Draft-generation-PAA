We are adding a 48 V to 12 V auxiliary supply to a telecom shelf and I need the power-stage values from you. The drive clock drifts with temperature and ageing, and production parasitics will differ from the bench. A supply that loses lock or rings without settling browns out the downstream rail. The fixed stage (source, input capacitor, half-bridge, series resonant tank, transformer, rectifier, output capacitor, load, parasitics) is described in the handbook. Device models are in /app/input_assets/models.lib.

You choose Lr (2 to 100 uH), Cr (10 to 500 nF), Lm (20 to 500 uH), n (1.5 to 4), extra gate resistor per switch Rgate (0 to 20 ohm), a damping resistor Rd in series with the tank (0 to 2 ohm), and an optional snubber across the transformer primary (Rsn 1 to 100 ohm in series with Csn 0 to 2 nF).

Unless stated, every requirement must hold at loads of 2, 3.5 and 5 A, at any drive frequency from 174.6 to 226.6 kHz (the 180 to 220 kHz band plus 3 % drift), with both parasitic capacitances at 0.7x to 1.3x nominal, and from any initial state with output capacitor 0 to 12 V, resonant capacitor -10 to +10 V and inductor currents within +/-2 A. Steady state means switching cycles 151 to 200 after a run starts or after a load step.
1. Mean output voltage between 10.5 and 13.5 V.
2. Efficiency at least 88 % at 3.5 A and at least 86 % at 2 A and 5 A (gate-drive power excluded).
3. Output ripple at most 0.15 V peak to peak.
4. Start-up from zero state at 3.5 A: output within 2 % of its final value within 400 switching cycles.
5. Load step 2 A to 5 A and 5 A to 2 A: output within 2 % of its final value within 150 cycles after each step.
6. No sub-harmonic operation: tank-current component at half the drive frequency at most 2 % of the fundamental.
7. Periodicity: mean output voltage and RMS tank current in the two consecutive 20-cycle windows ending at cycle 180 and 200 differ by at most 1 %.
8. Switching-phase spread: after removing any linear trend, standard deviation of tank-current zero-crossing phase relative to the drive edge over the 50 steady-state cycles at most 1.5 degrees.
9. Convergence from different initial states: mean output voltage within 0.5 % and efficiency within 0.3 points of the zero-state result at the same condition.
10. Numerical robustness: refining the time resolution of the simulation as defined in the handbook changes efficiency by at most 0.3 points and mean output voltage by at most 0.5 %.
11. Peak current in either switch (channel plus body diode) at most 8 A.

Deliver /app/output/design.json with numeric fields Lr_H, Cr_F, Lm_H, n, Rgate_ohm, Rd_ohm, Rsn_ohm, Csn_F (use Csn_F = 0 for no snubber).
