### 06 · 48 V→12 V resonant aux supply across drifting drive clock — advance, rank 8

Design decision as written: yes — "I need the power-stage values from you... You choose Lr (2 to 100 uH), Cr (10 to 500 nF), Lm (20 to 500 uH), n (1.5 to 4), extra gate resistor... damping resistor Rd... optional snubber"; deliverable is one parameter vector `design.json` for a fixed physical half-bridge series-resonant converter stage.

Forge task: Select Lr, Cr, Lm, n, Rgate, Rd and optional Rsn/Csn for a fixed 48 V→12 V half-bridge series-resonant auxiliary supply so that a transient circuit simulation over drive frequencies 174.6–226.6 kHz, loads 2/3.5/5 A, parasitic scales 0.7–1.3 and random initial states satisfies mean-Vout, efficiency, ripple, start-up and load-step settling, sub-harmonic, periodicity, phase-spread, initial-state-convergence, timestep-robustness and 8 A peak-switch-current limits.

Why it fits:
• It is a parameter decision for a physical device (power stage of a real telecom-shelf supply), not analysis of a fixed design: the eight values are free within ranges and different vectors give different behaviour.
• Every requirement is measurable from a scripted ngspice transient plus Python post-processing: cycle-mean Vout and integrated source/output power (R1, R2, R9), peak-to-peak ripple (R3), settling cycle index (R4, R5), DFT amplitude ratio at f/2 (R6), window-difference of mean Vout and RMS Lr current (R7), detrended standard deviation of rising zero-crossing phase vs the high-side gate edge (R8), cross-run comparison (R9), paired 5 ns / 2.5 ns rerun comparison (R10), drain-source branch peak (R11).
• The device models needed are supplied as text (`models.lib` subckt SWM, DSCH/DBODY), so the netlist is fully constructible headless — checkable in principle, pending harness implementation.
• The difficulty is real engineering, not tedium: gain flatness across a 30% frequency drift versus an 88% efficiency floor at 3.5 A, with damping (Rd, Rgate, snubber) trading stability/settling against loss, plus sub-harmonic, phase-jitter and initial-state sensitivity under parasitic spread.

What stops it:
• Structural: none. The core decision is a design decision and all stated physics is inside a SPICE-class model set (open-source ngspice, listed tool).
• Unresolved feasibility risk (author claim, unverified): the draft states "No reference has been run; all limits are provisional estimates to be calibrated by the task owner" and that the mechanism depends on an existing narrow window between a sharp candidate failing R6–R10 and a damped candidate failing R2. If no parameter vector clears all 11 limits simultaneously, the task has no solution and must be recalibrated (limits retuned — not widened merely to force a pass).
• Unresolved budget risk (arithmetic on the stated plan, not measured runtime): G1 24 runs × ~200 cycles ≈ 1.06 ms sim time each, G2 6 × 420 cycles, G3 and G4 ~16 runs, G5 6 reruns at 2.5 ns — on the order of 14 million timesteps across ~60 long transients before any agent-side design exploration; at an assumed 0.1–1 ms per timestep in a nonlinear MOSFICE netlist this is plausibly tens of minutes to hours of solver time, which threatens the ~2 hour single-run budget for the agent's own iterations. Runtime per run must be measured, not assumed.
• Unresolved specification ambiguity: R3's sentence "after removing the cycle-mean trend is not applied; plain peak to peak over the last 10 cycles" is self-contradictory and must be pinned to one definition; likewise whether G4's random draws are per-condition or shared, and whether R11 applies to the start-up/step transients in G2/G3 only or to all runs.

How to check it:
• ngspice (headless, batch mode): build the handbook netlist (ideal 48 V + 20 mΩ, 20 µF/5 mΩ input cap, two SWM switches with external Rgate, 40 ns dead time, 50% duty, Rd+Lr+Cr+transformer with Lm and ESR terms, 150 pF×scale parasitics at primary and secondary, DSCH full bridge, 100 µF/10 mΩ output, ideal current sink), run 200-cycle (420 for start-up) trapezoidal transients at max step 5 ns.
• Python post-processing of the `.raw`/CSV waveforms: all R1–R11 metrics as defined in the brief, with the drive-edge reference and the 100 ns ringing-crossing rejection for R8.
• Paired runs at 5 ns and 2.5 ns max step on a held-out subset for R10; cross-run comparisons for R9.
• Range validation of `design.json` fields before simulation.

Simulation gaps:
• The models are deliberately simple: level-1 NMOS with constant Coss, no reverse-recovery dynamics for the body diode, ideal transformer with no core loss, no winding AC/proximity loss, no thermal coupling, ideal 0/10 V gate drive with 1 ns edges, ideal current-sink load. Simulated efficiency therefore has an optimistic bias (no core or AC copper loss) and switching-edge/ringing behaviour (R8, R6, R11) will differ on real hardware with a real gate driver and PCB layout.
• Continuum conditions are sampled at 4 undisclosed frequencies and a handful of parasitic/initial-state points; a design can pass the sample and fail inside the band. This is inherent to the stated grader, not fixable by more requirements.
• R10 measures the solver, not the design: a timestep-sensitivity pass says the reported numbers are converged, not that hardware behaves similarly.
• Numerical accuracy of zero-crossing phase at 1.5° (≈ tens of ns at 200 kHz) is close to the 5 ns step scale; detrended phase std must be shown to be insensitive to interpolation method before the limit is meaningful.

Why frontier models fail:
• Hypothesis, unverified. Plausible causes: the parameter space couples gain (Lr, Cr, Lm, n) to damping (Rd, Rgate, Rsn/Csn) so local optima on a coarse nominal grid clear the agent's own gates marginally and fail at held-out frequencies, loads or parasitic scales; the efficiency floor blocks the damping-heavy escape; subharmonic and phase-judge metrics (R6–R8) are emergent behaviours of a lightly damped nonlinear tank that analytic hand-sizing (the handbook's fundamental-mode facts) does not predict; and the agent must spend its run budget wisely on simulation iteration rather than analytic hope. Trials are needed before claiming models actually fail.

Real-world risks:
• Model-to-hardware gap listed above (core loss, AC winding loss, real MOSFET Coss(V) and gate charge, diode leakage, PCB and transformer parasitics beyond the two lumped capacitances) means an in-sim pass may under-deliver efficiency or exhibit different ringing.
• Tolerance/temperature drift of Lr, Cr and the magnetising inductance is not modelled; the 0.7–1.3× parasitic scale covers only two capacitances.
• Component ratings (capacitor ripple current, transformer saturation, MOSFET voltage stress at the ringing frequency) are not among the 11 requirements and are not checked; a passing design could still overstress parts. Peak switch *current* is checked (R11) but peak switch *voltage* is not.

Milestones (if measured runtimes exceed one run):
1. Baseline + calibration: build the checker netlist and reproduce the author's candidate (Lr 3 µH, Cr 330 nF, Lm 150 µH, n 2, Rgate 3 Ω, Rd 0.1 Ω, Rsn 10 Ω/Csn 0.5 nF) at a reduced grid; grader checks that the netlist runs, metrics extract, and measured runtimes are recorded.
2. Window demonstration: run one sharp (low-damping) and one heavily damped candidate across the full grid; grader checks that the sharp one fails R6–R10 (or R1/R5) and the damped one fails R2, establishing that a narrow window exists.
3. Full design task: deliver `design.json` meeting R1–R11 on the undisclosed grid, as originally specified.

What to change (reshape): none at this stage — nothing the idea says needs removing or splitting until runtimes and the passing window are measured. If the calibration shows no passing vector, reshape by retuning the R2 floor / R6–R8 limits against measured candidate behaviour (the author's own stated plan), not by widening limits to manufacture a pass.

Numbers to supply next:
• Requirement calibration (missing specification + verification still needed): a demonstrated passing parameter vector and a demonstrated sharp/damped failure pair, from which the R2 floor (88% at 3.5 A, 86% at 2/5 A) and R6/R7/R8 limits are confirmed — e.g. "candidate Lr=3 µH... passes all of R1–R11 on the 24-run grid; Rd=1.5 Ω variant measures 83.4% at 5 A".
• Requirement: exact R3 definition — e.g. "plain peak-to-peak of Vout over the last 10 cycles of the 151–200 window" (drop the contradictory detrend clause) or "detrended peak-to-peak over 50 cycles".
• Requirement: scope of R11 — e.g. "applies to every run including the 420-cycle start-up and the 200-cycle post-step runs".
• Requirement: R4/R5 settling definition tie-break — e.g. "last cycle whose cycle-mean Vout deviates > 2% of the final value (mean of cycles 401–420 for R4, mean of cycles 351–400 for R5)".
• Interface: checker harness — e.g. `/app/input_assets/topology.cir` template, `/app/output/design.json` schema as stated, plus a metric-output CSV schema (columns: check_id, value, limit, unit, condition_id) and the fixed RNG seed/number of random initial states (e.g. 4 draws, seed 12345).
• Interface: simulation settings — e.g. "ngspice batch, trapezoidal, reltol 1e-4, maxstep 5 ns (2.5 ns for R10), `.ic` from the stated initial-state ranges".
• Verification still needed: measured solver runtime per 200-cycle run at 5 ns and at 2.5 ns on the grader hardware, and total grid runtime, to establish the two-hour agent budget; measured phase-extraction noise (zero-crossing std on a synthetic waveform) to justify the 1.5° limit.
• Handbook data: confirm the model-derived quantities — e.g. DSCH forward drop at 3–5 A (IS=1e-4, RS=0.008), SWM Ron ≈ 12 mΩ and Qg ≈ 20 nC as used in the efficiency accounting, and whether core loss is intentionally excluded from the efficiency definition.

Evidence status: Draft-only input. The `models.lib` text is supplied (establishes the model equations given, not that the asset exists on disk or that the netlist runs). All stated limits, the reference outline, the "distinct_valid_designs" list, the public-design failure claims and the mechanism-survival narrative are author claims; no simulation, reference run or runtime measurement has been supplied or inspected, and the author explicitly states no reference has been run. Efficiency figures, loaded-Q estimates and expected failure modes are unverified engineering estimates. Arithmetic on the grader plan (≈60 long transients, ≈14M timesteps) is my own inference from the stated cycle counts and step limits, not a measured runtime.

Checks before full-task readiness: (1) implement the checker netlist and run the author's candidate once to confirm it executes and metrics extract cleanly; (2) demonstrate a passing design and a sharp/damped failure pair to prove the window exists and to calibrate R2/R6–R8; (3) measure per-run and total solver runtime and set the agent's own simulation budget accordingly; (4) resolve the R3/R11/settling-definition ambiguities in the written requirements; (5) validate that 1.5° zero-crossing phase std is numerically resolvable at 5 ns step; (6) confirm design.json schema and held-out test-point protocol.