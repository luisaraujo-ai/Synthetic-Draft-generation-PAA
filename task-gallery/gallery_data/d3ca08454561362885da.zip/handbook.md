Background data (ranges, practice).

LSB: the converter full scale is +/-2.5 V over 16 bits, so 1 LSB is about 76 uV at the nominal 2.5 V reference. A 1 mV reference shift changes the peak code of a 1 V tone by roughly 5 LSB. Ground shift at the converter input adds directly to the code at about 13.1 LSB per mV.

Shared-impedance coupling: a return current I through R + jwL produces I*R at low frequency and I*wL at the burst harmonics. At 1 MHz, 8 nH is about 50 mohm, four times the 12 mohm resistance. Mean digital current is duty x peak, so a duty ramp becomes a slow ramp in ground voltage across the shared resistance. A parallel path lowers the DC and low-frequency impedance. It also forms loops with the 8 nH inductance that can ring at several MHz when the damping is poor.

Aliasing: the 1 MHz burst content lies exactly at 10 x the sample rate, so every harmonic lands at DC in the sampled data. What the converter sees is the instantaneous ground and reference value at a fixed phase of the burst period, which changes as the pulse width changes.

Reference path: the reference pin is divided against the converter's 20 kohm load, so each ohm in series with the reference costs 125 uV of reference level at 2.5 V. A capacitor from the reference pin to analog ground lets the reference follow analog-ground bounce above the corner 1/(2 pi R C), which cancels the ratio error. A large RC corner also makes the reference lag slow ground movement.

Capacitors: surface-mount ceramics from 100 pF to 22 uF; electrolytics and tantalums to 470 uF. A real capacitor includes equivalent series resistance (a few mohm to tens of mohm) and inductance (about 0.5 to 1.5 nH for small packages). The checker uses the ESR and ESL stated in the input file. Ferrite beads behave as an R plus an L at these frequencies; typical values are 0.1 to 1 ohm and 50 to 500 nH, with the resistance rising with frequency.

Layout bridges: a short copper bridge of a few millimetres has about 6 to 30 mohm and 3 to 10 nH. Its resistance scales with the trace tolerance corner.

Fit conventions: the fit is ordinary linear least squares on the raw code series sampled at t_n = n x 10 us + 0.9 us, with t = 0 at the start of the capture. The residual RMS is the square root of the mean squared residual over the stated window. Codes are the unrounded real-valued converter output expressed in LSB; quantization is not included.
