We are adding a 16-bit sampling channel next to a 1 MHz switching digital block on an existing board. The converter digitizes a 10.000 kHz, 1.000 V peak tone for a coherent-phase measurement, and downstream averaging assumes no slow drift or offset creep in the codes. Digital return current couples into the analog ground and reference through the shared return segment. I need you to design the passive ground-bridging, decoupling and reference-filter network around the fixed lumped board model in /app/input_assets/input.json (nodes, fixed parts, source waveforms, converter law, corner list, element limits and the design file schema are all there).

Fixed: the 12 mohm + 8 nH shared segment cannot be removed; the digital block, converter and reference source cannot change; no active parts. Budget: at most 14 discrete passive parts (R, L, C; a ferrite is an R plus an L), at most 3 ground bridges, at most 4 extra internal nodes.

Definition of the quality metric: take the raw converter code series (100 kS/s, 2.0 s capture) and fit it by least squares with exactly these five terms: sine and cosine at 10.000 kHz, one constant, sine and cosine at 1.000 kHz. The residual RMS is the RMS of what remains, in LSB at the 16-bit scale. No other term is permitted in the fit.

Requirements (all over the 2 s duty ramp described in the input file, at every corner of the supply 3.15/3.30/3.45 V, trace and bridge resistance -20/+20 percent, capacitor tolerance -20/+20 percent, and at intermediate points inside those ranges):
- R1: full-capture residual RMS <= 0.30 LSB.
- R2: the same metric, fitted separately on the window 0 to 0.2 s and on the window 1.8 to 2.0 s, <= 0.30 LSB in each.
- R3: element count <= 14, bridges <= 3, every node and value within the legal sets and ranges in the input file.
- R4: mean voltage between the converter reference pin and analog ground over 0 to 0.2 s between 2.450 V and 2.500 V.

Deliver /app/output/design.json in the schema given in the input file: a list of elements, each with type, value (or r_mohm and l_nH for a bridge), node_a and node_b, using only the named nodes plus up to four internal nodes.
