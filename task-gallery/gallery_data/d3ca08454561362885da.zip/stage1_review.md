### 19 · Mixed-signal ground/reference network for a 16-bit channel — advance, rank 8

Design decision as written: yes — "design the passive ground-bridging, decoupling and reference-filter network around the fixed lumped board model" (deliverable is a list of elements with type, value and node pair, i.e. a topology-and-values decision).

Forge task: Design a passive network (R/L/C plus up to 3 ground bridges, up to 14 discrete parts, up to 4 internal nodes) between AGND, DGND, PSU_RTN, REF_IN and REF_ADC on the fixed lumped board model, such that the exactly-five-term-fit residual RMS of the 16-bit code series is <= 0.30 LSB over the full 2 s capture and in each of the 0–0.2 s and 1.8–2.0 s windows, at every declared corner and held-out interior point, while the mean REF_ADC-to-AGND voltage stays in 2.450–2.500 V.

Why it fits:
- It is a design decision as written: the agent chooses which parts exist, their values and how they are wired; the checker evaluates the delivered file alone.
- The physical mechanism is coupled and real: lowering shared-return DC resistance (bridges) fights the duty-driven ground offset ramp, while the same bridges create L-C loops that ring at MHz and contaminate the burst-phase sampled value; the reference filter must follow ground bounce fast enough to cancel ratio error yet not lag the slow duty ramp; R4 caps how much series resistance the reference path can take. That is a genuine multi-objective trade-off, not hidden rules.
- The metric is deliberately resistant to the standard cheat: a solver that adds a linear-in-time term to its own fit absorbs the ramp and never sees the failure. The exact five-term basis is specified in the brief and in the handbook.
- Budget (14 parts, 3 bridges, 4 internal nodes) makes it a small combinatorial design, plausible for one agent run.

What stops it:
- Structural: none. The deliverable, node set, part limits and metric are specified.
- Unresolved feasibility risks: (a) the 0.30 LSB limit is explicitly provisional in the reference outline and no passing design has been demonstrated; (b) it is an author claim, not verified evidence, that an unbridged/datasheet-style design sits at about 0.7 LSB RMS — my own rough arithmetic (mean digital current ~8–24 mA through 12 mΩ gives ~1.3–3.8 LSB of ground shift at 13.1 LSB/mV, so a ~2.5 LSB p-p ramp has RMS ~0.7 LSB after removing only a constant) is consistent with that claim but is not a simulation; (c) whether 14 parts suffice at all 20+ evaluation points is undemonstrated; (d) the 5 % solver slack is an author choice and may be tighter than the disagreement between a harmonic-sweep envelope method and a direct transient; (e) a full 2 s transient with 1 MHz edges is not computationally feasible directly (2 s at ns steps ≈ 2e9 steps), so the slow/burst split in the grader plan is an approximation whose validity must be shown.

How to check it:
- ngspice or scipy state-space / complex nodal analysis: build the merged linear network (fixed elements from input.json plus the candidate design, including per-C ESR 5 mΩ and ESL 0.8 nH); solve slow content with a transient on the duty-ramp envelope and burst content as harmonic phasors up to ~300 MHz scaled by instantaneous duty and amplitude; sample at t_n = n*10e-6 + 0.9e-6.
- numpy: ordinary least squares with exactly [sin(2*pi*10k t), cos(2*pi*10k t), 1, sin(2*pi*1k t), cos(2*pi*1k t)] and residual RMS in LSB per window.
- A plain Python legality script: counts R/L/C and BRIDGE entries, checks node names against {AGND, DGND, PSU_RTN, REF_IN, REF_ADC, N1..N4}, checks value ranges and bridge minima, counts a ferrite as two parts.
- Cross-check the two solution routes (ngspice transient vs scipy state-space vs harmonic superposition) on one test network to establish that the 5 % slack is adequate.

Simulation gaps:
- The model is lumped: no plane geometry, no distributed return paths, no via/package inductance, no coupling beyond the two named trace segments, no discrete-L self-resonance or DCR (discrete R and L are declared ideal, which is optimistic at 300 MHz), no capacitor dielectric/temperature/voltage derating and no ESR/ESL cornering.
- Sources are ideal; the converter law is memoryless with no quantization, jitter, INL/DNL or aperture effects; "initial state = steady state at duty 0.2" is a modelling convenience.
- Harmonic superposition plus an instantaneous-duty envelope assumes the network is linear and that the duty ramp is slow relative to burst settling; this needs validating against a shorter direct transient on a reduced time base.
- Manufacturability/assembly is not simulated at all: legality of values and bridge ranges stands in for it.

Why frontier models fail: plausible but a hypothesis until trials exist. The traps are engineering-real: the exact five-term basis forbids absorbing the ramp, so a self-consistent but weakened metric cannot be used as the solver's own fitness; the aliasing (1 MHz burst harmonics land at DC at 100 kS/s, sampled at a fixed burst phase) means only the instantaneous burst-phase ground and reference values matter, which is easy to get subtly wrong; and the reference-filter corner trades ramp-following against ripple rejection under a hard R4 DC window, so a design that looks good on one metric usually breaks another. Subject to: an actual trial run showing a frontier model's proxy metric passing while the exact basis fails.

Real-world risks:
- A design passing the lumped model would likely behave qualitatively as intended on a real board, but the gap is large: real shared-return geometry, plane resonances, package parasitics and converter PSRR/INR can dominate at the 76 uV/LSB level.
- The bridge model (6–30 mohm, 3–10 nH per handbook) is a range, not a measured geometry; the delivered network names no copper widths or lengths.
- Ceramic C of tens of uF loses capacitance with DC bias; the 20 % capacitor corner may not cover that.

Milestones (if too big): none required; the task plausibly fits one run. If runtime proves prohibitive, split as: 1. surrogate builder + baseline reproduction: implement the code-series/fit metric, reproduce the ~0.7 LSB unbridged baseline — grader checks the reproduced RMS matches the stated figure within tolerance. 2. network search over the 14-part budget — grader checks the four requirements at all corners.

What to change (reshape): nothing structural. Pin down the open items below instead.

Numbers to supply next:
- Requirement: residual-RMS limit — confirm 0.30 LSB after calibration; first reproduce the author's ~0.7 LSB unbridged baseline and demonstrate at least one design passing all four requirements (verification still needed, not just a specification). Example value: 0.30 LSB RMS with 5 % numerical slack.
- Requirement: bridge element bounds — bridge_r_mohm_max and bridge_l_nH_max (handbook implies 6–30 mohm and 3–10 nH; state the maxima the checker accepts, e.g. 30 and 10).
- Requirement: parasitic policy for discrete R and L — confirm ideal up to 300 MHz or supply a self-resonant-frequency/DCR model; confirm ESR/ESL of capacitors are cornered or fixed at 5 mohm / 0.8 nH.
- Interface: input at /app/input_assets/input.json, output at /app/output/design.json; example entry e.g. {"type":"C","value":2.2e-05,"node_a":"AGND","node_b":"PSU_RTN"} and {"type":"BRIDGE","r_mohm":8,"l_nH":5,"node_a":"AGND","node_b":"PSU_RTN"}; state that C values are in farads as decimals and whether negative values / zero are rejected.
- Handbook data: already largely supplied (1 LSB ≈ 76 uV; 13.1 LSB/mV ground sensitivity; 125 uV per ohm in the reference path; ferrite 0.1–1 ohm and 50–500 nH). Add the accepted capacitor ESR/ESL corner and any derating factors.
- Verification still needed: solver cross-validation (ngspice vs scipy vs harmonic superposition) on a test network; measured runtime for one full 20-point evaluation; validation of the slow/burst envelope split against a direct transient; check that the steady-state initial condition at duty 0.2 is reproducible; confirm the 8 held-out interior points are seed-reproducible.

Evidence status: draft-only input. All figures (the 0.7 LSB baseline, the ~2x shortfall, public-design failures, budget fit, the 5 % slack and the mechanism narrative) are author claims; the embedded input.json text establishes supplied text, not that the asset exists or that any simulation has been run. The reference outline is a proposed solution, not a passing design. No artifact or measurement has been inspected; nothing here is verified.

Checks before full-task readiness: 1) confirm /app/input_assets/input.json exists and matches the embedded text byte-for-byte in the fields the grader reads; 2) reproduce the unbridged baseline residual (~0.7 LSB claimed) with the exact five-term basis; 3) demonstrate one passing design at all 12 corners plus the 8 held-out points; 4) cross-validate two independent solvers and confirm the 5 % slack bounds their disagreement; 5) measure the runtime of one full evaluation; 6) supply bridge maxima and the discrete-parasitic policy.