We are adding a programmable-gain transconductance front end to a 3-channel battery-powered bridge sensing board. It turns a small differential voltage into an output current feeding a switched-capacitor integrator. Gain changes and channel enable pulses must settle without the bias landing in a wrong state, and gm must stay on target across process, supply and temperature.

Fixed interfaces: supply VDD 1.62 to 1.98 V (1.8 V nominal); inputs inp and inm with common mode 0.9 V +/-0.1 V and differential signal +/-50 mV small-signal, up to +/-400 mV in overload; output node out loaded by the subcircuit in /app/input_assets/load.cir (2 pF behind 10 kohm to a 0.9 V sink; output current is the current into that load). Logic inputs: en (0/1.8 V, 100 ns edges) and gsel (0 = gain A, 1 = gain B). Only the devices in /app/input_assets/mosmodel.lib and ideal resistors and capacitors may be used. Temperature -40 to 125 C. Process corners are defined in the library file; any point inside the stated ranges may be tested.

Requirements:
1. Small-signal gm (output current per differential input volt, at 0.9 V common mode) within +/-4 % of 400 uS for gain A and 100 uS for gain B, at every corner and every combination of supply and temperature in range.
2. Total supply current <= 120 uA at every corner and gain code, enabled.
3. Total gate area W*L summed over all MOS devices <= 400 um^2, minimum length 0.18 um.
4. Power-up from rest (all nodes 0 V, supply ramping 0 to VDD in 50 us): gm within the requirement 1 tolerance within 20 us after the ramp ends.
5. Warm start: supply up, en low for 1 us then high, with internal nodes left at any voltages between 0 and VDD: final supply current within 1 % of the power-up-from-rest value, and gm back within tolerance within 20 us of en rising.
6. Gain switch A to B and B to A with a full-scale (50 mV) input: output current settles to within 1 % of its final value within 5 us, overshoot <= 5 % of the step.
7. Overload: input at +/-400 mV for 2 us, then small signal: output current within 1 % of its small-signal value within 10 us.
8. Robustness: requirements 1, 4 and 5 must still hold with the threshold of any single device shifted by 5 mV in either direction and supply shifted by 2 %.
9. Bias-loop damping: the ring-down of the node you declare in design.json as "loop_node" after a 20 mV supply step (defined in the handbook) must have damping ratio >= 0.45 at every corner.
10. Settled output current must change by less than 0.5 % when the transient time resolution is made twice as fine.

Deliverables in /app/output/: design.cir, a netlist of the stage (subcircuit named gmstage with ports vdd gnd inp inm out en gsel) using the supplied models; design.json with fields "devices" (list of name, W_um, L_um), "gain_codes" (gsel value to nominal gm in uS) and "loop_node" (name of a node inside gmstage that is the bias-loop node).
