### 02 · Programmable-gm front end with start-state-independent bias — advance, rank 8

Design decision as written: yes — "We are adding a programmable-gain transconductance front end to a 3-channel battery-powered bridge sensing board... Gain changes and channel enable pulses must settle without the bias landing in a wrong state, and gm must stay on target across process, supply and temperature."

Forge task: Design and size the subcircuit gmstage (vdd gnd inp inm out en gsel) in SPICE using only the supplied MOS models plus ideal R and C, such that gm is 400 uS (gain A) and 100 uS (gain B) within +/-4 % across corners, VDD 1.62-1.98 V and -40 to 125 C, supply current <= 120 uA, total MOS gate area <= 400 um^2, the bias settles to the same state from rest and from arbitrary stored node voltages within 20 us, gain switches settle within 5 us with <= 5 % overshoot, overload recovers within 10 us, the declared bias loop node rings down with zeta >= 0.45, and results are timestep-refinement stable.

Why it fits:
• It asks for a designed artifact (a netlist plus a device table and a declared loop node), not an analysis of a fixed system; the agent chooses topology, sizing, degeneration, startup and compensation.
• The decision is genuinely coupled: constant-gm/deg-referenced bias gives gm accuracy over PVT, but the positive-feedback bias loop has a zero-current basin (start-state dependence), so startup strength trades against the 120 uA current budget, loop damping (zeta >= 0.45) trades against 5 us gain-switch settling and 10 us overload recovery, and all of it is squeezed into 400 um^2 of gate area with L >= 0.18 um.
• Every requirement is expressible as scripted DC, AC or transient checks in ngspice plus Python post-processing and netlist parsing.

What stops it:
• Structural: nothing blocking. The task is a design decision, bounded, and simulable in principle.
• Unresolved feasibility risks: (a) warm-start runs apply .ic voltages on internal nodes — ngspice may fail to converge, and a numerical failure is not evidence of a bistable bias state, so the grader needs a defined policy for convergence failure vs. genuine wrong-state settling; (b) no passing reference netlist exists yet — the author states "Thresholds are provisional until a passing reference is simulated", which is an author claim, not evidence; (c) G1 (27 grid + 20 held-out points), G3 (10 undisclosed seeds x corner subset), G5 (each device singly shifted both signs), G6 (both gains x corners) and G7 imply hundreds of ngspice runs; single-run circuit size makes this plausible but the runtime is unmeasured.

How to check it:
• ngspice: DC/small-signal or 1-5 mV differential-step transient at 0.9 V common mode into the load subcircuit to extract gm per gain code over the corner grid and held-out points (G1), average VDD current (G2 requirement), 50 us supply ramp transient from rest and .ic warm-start transients with en low 1 us (G3), gain-switch and +/-400 mV overload transients with 1 % band settling and overshoot extracted in Python (G4), the same rerun with per-device Vth shifts of +/-5 mV and 2 % supply shift (G5), a +20 mV VDD step in 100 ns with the declared loop_node waveform post-processed by the handbook log-decrement rule for zeta (G6), and the settled-state rerun at half the baseline step (G7).
• Python: parse design.cir and design.json, verify MOS device list consistency, W*L sum <= 400 um^2, L >= 0.18 um, loop_node exists inside gmstage and is not a port or supply rail.
• What a simulation would get wrong: see simulation gaps.

Simulation gaps:
• The supplied level-1 cards model no subthreshold conduction, so near-zero bias states are idealised; real devices leak subthreshold, which changes both the zero-current basin and warm-start recovery. Start-state behaviour is therefore optimistic or pessimistic in ways the model cannot show.
• Ideal resistors and capacitors are stated to be uncounted in area and have no tolerance or temperature coefficient, so gm ≈ 1/R_deg stability across temperature is overstated relative to a real board.
• No mismatch model beyond the single-device +/-5 mV Vth shift, no 1/f or thermal noise, no offset check, no package or board parasitics; the SC integrator is a 10 kohm / 2 pF Thevenin-equivalent load, not the real switched-capacitor waveform.
• Level-1 square-law accuracy for a 0.18 um device class is limited; lambda, gamma and the given TCV/UTE behaviour are approximations. Confirm that ngspice level-1 TCV and UTE reproduce the stated temperature drift (that is a model-consistency check, not validation).
• The zeta extraction assumes an approximately linear second-order ring-down; peak detection and the "fewer than two opposite-sign peaks counts as pass" rule are timestep- and window-sensitive, and a non-converged transient can masquerade as a start-state-dependent wrong basin.

Why frontier models fail:
• The requirements are coupled, not independent: meeting gm +/-4 % across PVT pushes toward a resistor-referenced degenerated loop, whose positive feedback has a stable zero-current state; forcing the correct state consumes current (R2), startup devices load the loop and erode damping (R9), and loop compensation slows gain switching (R6) and overload recovery (R7) while the gate area budget (R3) limits how many helper devices can be added.
• The discriminating requirements (R5 arbitrary stored states with undisclosed seeds, R8 single-device threshold shifts, R9 damping at corners) are exactly the ones a design validated only from a rest-start power-up and timestep halving will miss. That is a hypothesis about model failure, not a measured result.

Real-world risks:
• Real degeneration resistors have tolerance and temperature coefficient, so achieved gm accuracy will exceed the simulated +/-4 %; a real board needs trimming or a better reference.
• Level-1 MOS fidelity, unmodelled subthreshold behaviour, unmodelled mismatch and parasitics mean a design that passes the checker is plausible to work but not demonstrated to work on silicon.
• The battery-powered system's supply ramp, ripple and the 3-channel loading are outside this single-stage scope.

Milestones (if too big): not required at this stage; if runtime measurements show the sweep exceeds one run, split into (1) static gm/current/area target matching over PVT, (2) start-state and enable behaviour, (3) transient behaviour (gain switch, overload) and loop damping, each with its own netlist start state and grader.

What to change (reshape): none — advance as written.

Numbers to supply next:
• Missing specification (not verification): warm-start seed policy — how many seeds, which nodes receive .ic values and their distribution, e.g. 10 seeds, every node inside gmstage drawn uniformly from 0 to VDD, and whether convergence failure counts as a fail.
• Missing specification: R10 baseline transient time step and integrator settings, e.g. max step 5 ns with trap/Gear setting fixed, refined run at 2.5 ns.
• Missing specification: gm measurement stimulus and window, e.g. 2 mV differential step at 0.9 V common mode, output current averaged from 10 us to 20 us after the edge; and the definition of the +20 mV supply step rise time (100 ns is stated — confirm it applies to G6 only).
• Interface: confirm the provided assets exist and match the embedded text — /app/input_assets/mosmodel.lib and /app/input_assets/load.cir are named dependencies, not inspected files. Specify the checker's testbench: whether it instantiates gmstage and .subckt scload with sink at 0.9 V, the top-level node names, and the raw/measure output format the checker reads.
• Output schema (already drafted, keep): design.cir with subcircuit gmstage (vdd gnd inp inm out en gsel); design.json with devices [{name, W_um, L_um}], gain_codes {"0": gm_uS, "1": gm_uS}, loop_node string.
• Handbook data (mostly supplied): keep the level-1 card values (vto 0.45/-0.48 V, kp 300u/100u, TCV -1/+1 mV/K, UTE -1.5), corner definition (|vto| +/-30 mV, kp x0.9/1.1, continuous deltas), supply ramp shape (linear 0 to VDD in 50 us), and ideal R/C not counted in area.
• Verification still needed before full-task readiness: demonstrate one reference netlist that passes all of R1-R10 (the author's reference outline is a proposed solution with provisional thresholds, not a passing design); reproduce at least one claimed public-design failure on R5/R9 to confirm the catching rows discriminate; measure ngspice runtime and convergence rate for .ic transients and the full grid-plus-seeds-plus-shift sweep; confirm ngspice level-1 TCV/UTE behaviour matches the handbook temperature claims.

Evidence status: draft-only input. The instruction, requirements, load.cir and mosmodel.lib text, grader plan and reference outline are author-supplied text; no filesystem inspection or simulation has been performed. The reference outline is a proposed solution and explicitly not validated ("Thresholds are provisional until a passing reference is simulated", author claim). Public-design failure claims and the mechanism-survival narrative are author claims, unverified. The stated grid (27 points) plus held-out points, seeds and per-device shifts implies a large but unmeasured simulation count; no runtime evidence exists.

Checks before full-task readiness: (1) verify /app/input_assets/load.cir and mosmodel.lib exist and match the embedded text; (2) produce and simulate a passing reference design across all grader paths; (3) measure ngspice wall time and convergence for the warm-start .ic runs and define the convergence-failure policy; (4) reproduce a failing baseline for R5, R8 and R9 to show the checks discriminate; (5) confirm level-1 TCV/UTE in ngspice gives the stated drift; (6) fix the R10 step baseline and the R5 seed policy in the task text.