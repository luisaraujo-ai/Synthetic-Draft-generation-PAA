I need a custom gate cell for a near-threshold sensor ASIC block. It computes Y = NOT((A AND B AND C) OR D) and drives a 6 fF load. The block runs at low supply with body bias applied to recover speed, and the three-high stack suffers body effect, so the cell has to work across the whole supply, bias and temperature band, not just at nominal.

Fixed conditions: supply 0.55 to 0.80 V; body bias Vb from -0.2 to +0.3 V (positive is forward; the surroundings drive NW = VDD - Vb and PW = VSS + Vb); temperature 0 to 85 C; input 10-90% edge times 80 to 400 ps; load 6 fF from Y to VSS. Devices use the cards in /app/input_assets/model.inc (NMOS nch, PMOS pch). Gate length 60 nm, each width 120 nm to 2 um, at most 14 devices, total width at most 5.0 um, no resistors or capacitors. Body terminals may go to rails, to NW/PW, or to local nodes.

Requirements:
R1: Static, all 16 input vectors held 20 ns, at every supply, bias and temperature point in the band: Y within 5% of VDD of the correct rail.
R2: Every single-input arc that toggles Y, at every supply, bias, temperature and edge time in range: 50%-to-50% delay at most 500 ps at 0.55 V, falling linearly in supply to at most 220 ps at 0.80 V.
R3: Every single-input arc that must not toggle Y, same conditions: Y excursion from its rail at most 20% of VDD.
R4: Back-to-back toggling of the worst arc, 4 ns period, 200 ps edges, 50 cycles, at every supply, bias and temperature point: in every cycle Y is within 5% of VDD of its final rail within 1.0 ns after the input 50% crossing, and each cycle's delay is within 3 ps of cycle 1's.
R5: Every arc that raises Y, 400 ps edges, every supply, bias and temperature point: (E_supply - C*VDD^2)/E_supply is at most 30%, where E_supply is the energy drawn from VDD from the start of the input edge to 3 ns later and C is 6 fF.
R6: Robustness, two separate checks. (a) Refining the time resolution (see handbook), or starting from different initial node voltages, changes any delay by at most 2 ps and any Y level by at most 1% of VDD. (b) With the threshold magnitude of every device independently shifted by up to 15 mV in either direction, R1, R2 and R3 still pass.
R7: Netlist structure: the stated port order, at most 14 devices, L = 60 nm, 120 nm <= W <= 2 um, total width at most 5.0 um.

Deliverables in /app/output/: cell.sp, a SPICE subcircuit named aoi31 with port order A B C D Y VDD VSS NW PW using models nch and pch; and design.json with fields devices (list of name, type, W_m, drain, gate, source, body) and total_width_m.
