### 07 · Body-bias-tolerant AOI31 near-threshold cell — advance, rank 8

Design decision as written: yes — 'I need a custom gate cell ... It computes Y = NOT((A AND B AND C) OR D) and drives a 6 fF load' plus 'at most 14 devices, total width at most 5.0 um' and deliverables cell.sp / design.json. The agent must choose topology, device widths, stack ordering and body ties; that is a physical design decision, not a simulation study.

Forge task: Design and size a 60 nm, at most 14-device AOI31 standard cell (topology, widths, body ties) delivering Y = NOT((A·B·C) + D) into 6 fF, meeting R1–R7 across VDD 0.55–0.80 V, Vb −0.2 to +0.3 V (NW = VDD − Vb, PW = VSS + Vb), 0–85 °C, input edges 80–400 ps, with robustness to independent ±15 mV per-device threshold shifts, and outputting cell.sp plus design.json.

Why it fits:
• The deliverable is a design artifact (SPICE subcircuit + device table) that a headless simulator can grade end to end; every requirement maps to a scripted DC or transient measurement.
• The engineering difficulty is real and coupled: at 0.55 V with |Vth| ~0.40–0.45 V the three-high stack is body-effect and overdrive limited; tying bodies to rails versus NW/PW versus local nodes trades threshold lowering against glitch and internal-node charge sharing; R7 caps the trivial fix (upsizing).
• R3 (glitch excursion), R5 (short-circuit energy fraction) and R6(b) (margin under shifts) rule out a knife-edge optimum; several distinct topologies can pass, so this is design, not lookup.
• ngspice runs these level-1 cards headlessly: DC operating points (R1), transient arcs with linear ramps (R2/R3), supply-current integration (R5), 50-cycle transient (R4), reruns with halved timestep/initial states and shifted vto (R6), and a Python parse for R7.

What stops it:
• Structural objection: none blocking — the task as written is a design decision and is checkable in principle.
• Unresolved feasibility risk: sweep cost. R2/R3 alone are roughly 32 arc-and-held-state combinations × ~5 edge times × ~30 band points ≈ 4800 transients; R4 adds 200 ns transients per arc per point, R6(a) doubles runs, R6(b) multiplies them by the number of shift patterns. At 0.5–2 s per transient one full pass is plausibly 40 min–3 h, before any design iteration. Measured runtimes are needed; if the budget is exceeded, split rather than widen limits.
• Unresolved feasibility risk: physics oracle. model.inc is author-supplied text; it is uncalibrated for 60 nm devices near threshold, so 'passes the checker' does not imply 'works in silicon' (see simulation gaps).
• Unresolved feasibility risk: tolerances. R2 tolerance is 1 ps measurement resolution and R6(a) allows 2 ps change; the ngspice numerical noise floor for this netlist is unmeasured, so the tolerance may be at or below solver noise.

How to check it:
• ngspice: DC settled operating points for all 16 vectors at grid and interior (VDD, Vb, T) points (R1, Y within 5% of VDD of correct rail).
• ngspice transient, linear-ramp inputs, every single-input arc with the other three held: 50%-to-50% delay versus the linear-in-VDD limit (R2) and maximum Y excursion on non-toggling arcs (R3).
• ngspice transient with supply-current integration from input edge start to +3 ns for every rising-Y arc at 400 ps edges (R5).
• ngspice 50-cycle transient, 4 ns period, 200 ps edges (R4: Y within 5% VDD of rail 1.0 ns after each input 50% crossing, per-cycle delay drift within 3 ps).
• ngspice reruns: halved maximum timestep and alternative initial node voltages (R6a); independent per-device vto offsets up to ±15 mV with R1–R3 rerun (R6b).
• Python parse of cell.sp and design.json: port order aoi31 A B C D Y VDD VSS NW PW, device count, L, W range, total width, file consistency (R7).

Simulation gaps:
• Level-1 cards omit velocity saturation, DIBL, subthreshold conduction, mobility degradation and series resistance; current at 0.55 V/60 nm is therefore an approximation, and the handbook's overdrive-squared scaling is a model property, not measured silicon behaviour.
• Body effect uses a simple sqrt(PHI + Vsb) law; junction conduction at Vb = +0.3 V is asserted negligible in the model (author claim), whereas real forward-biased wells conduct.
• Temperature is a prescribed vto/kp rescale, not a physical temperature model; thermal self-heating and leakage are absent.
• Only model-card overlap and oxide capacitances appear; no routed interconnect R/C, no well tap resistance, no supply network. Glitch and delay would differ in a real layout.
• A finite grid plus undisclosed interior points can miss a failing corner; convergence settings, timestep control and measurement interpolation are not yet specified.

Why frontier models fail: hypothesis, not established. The plausible difficulty is that near-threshold sizing of a three-high stack under a 5.0 µm width cap requires reasoning about body-tie topology, stack ordering, series effective width W1·W2/(W1+W2), internal-node charge sharing and margin against ±15 mV shifts simultaneously; minimum-size AOI, uniform upsizing and knife-edge-optimum AOI each fail one of R2, R7 and R6(b) respectively (author claims, unverified). This needs baseline trials before it can be asserted.

Real-world risks:
• A cell passing the level-1 checker may fail in silicon (short-channel effects, parasitics, well proximity, IR drop); model.inc is uncalibrated text, and no silicon correlation is supplied.
• The 6 fF load, ideal ramp inputs and stylized width budget may not represent the sensor block's real drive and slew environment.
• Forward body bias up to +0.3 V is asserted harmless in this model; real devices would see junction injection and reliability limits.

Milestones (only if measured runtime exceeds one run):
1. Static + delay task: cell.sp meeting R1, R2, R7 on the stated grid; grader runs DC and R2 transients.
2. Glitch + energy + margin task: starting from a supplied baseline cell.sp, meet R3, R5, R6(b) with sizing refinement.
3. Dynamic + numerical task: meet R4 and R6(a) with a supplied cell.sp and harness.

What to change (reshape): nothing structural. Pin down the sweep grid, hidden interior point count, R4 arc definition, R6(a) base timestep and R6(b) pattern count, and solver options before release. If one full verification pass measurably exceeds the run budget, split at the milestones above; do not widen the limits.

Numbers to supply next:
• Requirement (grid, R1–R5): supply points e.g. {0.55, 0.625, 0.70, 0.775, 0.80} V; bias points e.g. {−0.2, −0.1, 0.0, +0.15, +0.3} V; temperature points e.g. {0, 25, 55, 85} °C — plus the number of undisclosed interior points (e.g. 3 random per axis) and the seed policy.
• Requirement (R2/R3): sampled edge times, e.g. {80, 160, 240, 320, 400} ps, and whether intermediates are interpolated or swept.
• Requirement (R4): define 'worst arc' — e.g. all toggling arcs, or the arc with the largest R2 delay at each corner; the stimulus pattern (which input toggles, the values the other three are held at), and that the 50 cycles use the stated 4 ns period and 200 ps edges.
• Requirement (R6a): base transient maximum timestep, e.g. 2 ps, halved to 1 ps; and the initial node voltage set, e.g. all-0 V, all-VDD, plus 5 random seeds in [0, VDD].
• Requirement (R6b): number and distribution of vto shift patterns, e.g. 20 random patterns with each device offset uniform in [−15, +15] mV, and the corner subset rerun (e.g. 6 of the grid points).
• Requirement (R5): confirm the 3 ns integration window and that E_supply is the integral of VDD-source current (as written).
• Interface: inputs /app/input_assets/model.inc; outputs /app/output/cell.sp (subcircuit aoi31, port order A B C D Y VDD VSS NW PW) and /app/output/design.json; state the design.json types/units (W_m float in metres, nodes as strings, total_width_m float, per-device L implied 60 nm) and where the checker harness and hidden points are injected (specification, not yet an inspected asset).
• Handbook data: model card parameters are given (nch vto 0.35 V, pch −0.37 V, gamma 0.25, phi 0.8, kp 400u/200u, tox 2n); add the input driver model for the ramps (e.g. ideal voltage ramp with 10 Ω series resistance), the 6 fF load's connection (Y to VSS, as stated), and ngspice version plus .options (method, reltol, gmin, max step) used for all acceptance runs.
• Verification still needed (not a missing specification): reproduce one claimed baseline failure (minimum-size AOI exceeding 500 ps at 0.55 V, 0 °C, Vb = −0.2 V) with the harness; demonstrate at least one reference cell passing R1–R7; measure per-transient wall time and total sweep cost against the run budget; measure the halved-step delay difference on a fixed netlist to confirm the 2 ps R6(a) tolerance sits above solver noise.

Evidence status: draft only. The model.inc card text, the reference outline (e.g. the 360 ps / 480 ps hand estimates), the public-design failure claims, and the stated margins are author claims in the supplied text; nothing has been simulated or inspected here. Named assets (/app/input_assets/model.inc) are specified dependencies, not verified files. The reference outline is a proposed solution outline, not a passing design. Claimed difficulty of public designs and predicted frontier-model failures are hypotheses pending trials.

Checks before full-task readiness:
1. Build the checker harness and reproduce at least one author-claimed baseline failure (R2 at 0.55 V, 0 °C, Vb = −0.2 V).
2. Demonstrate a passing reference netlist across the full grid plus held-out interior points (the author explicitly marks all thresholds provisional).
3. Measure ngspice runtimes per requirement class and total sweep cost; decide single-run versus milestone split from data.
4. Measure the numerical noise floor (halved-step and initial-state deltas on a fixed netlist) to validate the 2 ps / 1 ps tolerances.
5. Freeze the grid, edge-time set, R4 arc definition, R6 pattern counts and solver options in the task text.