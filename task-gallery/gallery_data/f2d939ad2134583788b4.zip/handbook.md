Conventions and reference data.

Bridge. Differential signal sp minus sn equals Vex x 0.003 x s. It is proportional to the voltage across xp-xn, whichever polarity that has. Common mode is half the excitation. Bridge resistance seen by the drive is 350 ohm. Bridge dissipation is Vex^2/350 for a DC or square-wave drive of amplitude Vex, scaled by the fraction of time it is driven. The parts file supplies a bridge subcircuit that takes the strain through a control node ctl, where 1 V means s=+1.

Op-amp model (oa inp inn out vdd). Open-loop gain 1e5, a single pole giving GBW of 5 MHz, output limited to 0.1-3.2 V, 10 ohm output resistance, 150 uA quiescent current drawn from its vdd pin when that pin is above 2 V. When its vdd pin is below 2 V it draws nothing and its output is 0 V. Its input offset is the global parameter vosg, the same for every instance, within +/-300 uV. A real front end also has 8 nV/rtHz white noise and a 100 Hz 1/f corner. The parts file represents that low-frequency error only by the static offset. Noise is not graded.

Switch model SW. Ron 5 ohm, Roff 1e9 ohm, threshold 1.65 V with 0.2 V hysteresis. A switch closes when v(control+) minus v(control-) exceeds the threshold. The control voltage does not depend on the switch's own terminals, so any switch may be driven from clk, en or a node derived from them. Charge injection is ignored.

Inverter (inv a y vdd). Smooth logic inverter, 100 ohm output, y = vdd when a is low and 0 when a is high, with its threshold at vdd/2.

E24 series per decade: 10 11 12 13 15 16 18 20 22 24 27 30 33 36 39 43 47 51 56 62 68 75 82 91. Series and parallel combinations of E24 parts are allowed. Resistor thermal noise is 4kTR, about 1.29 nV/rtHz for 100 ohm at 300 K.

Measurement definitions.
- Final value of out is its mean over the last 2 ms of the interval in which s is constant, with a burst at least 10 ms long. In a burst containing a strain step, the final value is the mean over 18-20 ms.
- Settling time is the last time out is outside the 1.2 mV band around the final value.
- Overshoot is the peak excursion beyond the final value in the direction of the step.
- Ripple is the peak-to-peak value of out over the last 2 ms of the burst.
- Periodicity compares out at t and t+1/fclk over that same interval, where fclk is the actual clock frequency in use.
- Supply power is the mean of v(vdd) x supply current over the stated interval.
- Sleep current is the mean supply current with en low for 5 ms from rest.

Initial states. A charged start sets each capacitor's initial voltage between 0 and 3.3 V, measured from its first to its second listed node. The en rise time is about 1 us. The op-amp internal state starts at rest.

Typical practice. A single-pole filter's 0.05 percent settling takes about 7.6 time constants. A switch network's ripple depends on the clock frequency, so a design that is quiet at one frequency can show more at another inside the declared clock range. Gain from E24 values depends on the combinations used. Held-out points: the clock frequency, strain values, offset values and starting charges are chosen inside the declared ranges, not only at their corners.
