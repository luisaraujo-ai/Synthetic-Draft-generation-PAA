We are adding a battery-powered load-cell node and need the front end that excites a 350 ohm full bridge and reads it out as one single-ended voltage. The node sleeps most of the time and wakes for short bursts. The readout must therefore settle quickly after each wake, whatever charge its capacitors were left holding. It also has to behave the same for any clock the host happens to provide.

Fixed interfaces. Deliver one subcircuit named readout with ports: vdd gnd clk en xp xn sp sn out. Supply is 3.3 V on vdd. clk is a 3.3 V logic clock at 50 percent duty, at any frequency from 7.76 to 12.36 kHz. en is 3.3 V logic: high is measure, low is sleep. xp and xn are the two bridge excitation terminals your circuit drives. sp and sn are the bridge signal terminals your circuit senses. out is the single-ended output. out drives 1 Mohm in parallel with 100 pF to a 1.65 V reference. The bridge has four 350 ohm arms and 3 mV/V sensitivity. Its signal is Vex x 0.003 x s, where s is the strain fraction from -1 to +1 and Vex is the excitation across the bridge. Bridge, op-amp, switch and inverter models are in /app/input_assets/parts.lib. That file is supplied separately, so do not include it. Every op-amp instance has the same static input offset, anywhere within +/-300 uV.

Requirements. out must equal 1.65 V + 1.2 V x s. FS is the 2.4 V output span. The settling band is 0.05 percent FS, which is 1.2 mV around the output's final value.
R1. Wake from rest: en rises at t=0 with all capacitors at 0 V and s fixed anywhere in range. Out stays inside the settling band from 2.0 ms until the end of the 10 ms burst.
R2. Same limit as R1, but every capacitor starts at any voltage from 0 to 3.3 V.
R3. Strain step: s steps between any two values in range (up to 2 in size) during a burst. Out is inside the settling band within 2.0 ms of the step and overshoots the final value by at most 0.2 percent FS (4.8 mV).
R4. Ripple and periodicity: once settled, out peak-to-peak is at most 0.5 mV. The difference between out and out one clock period earlier is at most 0.15 mV.
R5. Accuracy: settled out is within 1 percent FS (24 mV) of the ideal line for every s in range and every offset in range.
R6. Power: average supply power over a settled measure interval, including the power delivered to the bridge, is at most 12 mW at every s.
R7. Sleep: with en low, the supply current is at most 5 uA and out is within 20 mV of 1.65 V.
R8. Numerical robustness: quartering the simulation step changes the settled mean by at most 0.2 mV and the settling time by at most 0.1 ms.
R9. Construction: use only resistors, capacitors, switches (model SW), oa and inv instances. No inductors, no other subcircuits, no sources. Values come from the E24 series. Total capacitance is at most 10 uF.

Deliverable: /app/output/readout.cir, a SPICE netlist containing only the readout subcircuit definition.
