### 24 · Duty-cycled bridge readout front end — advance, rank 8

Design decision as written: yes — "Deliver one subcircuit named readout with ports: vdd gnd clk en xp xn sp sn out" and "use only resistors, capacitors, switches (model SW), oa and inv instances", i.e. the agent chooses topology and E24 component values for a physical front end.

Forge task: Design a single-ended readout subcircuit (R, C, SW, oa, inv only) that excites a 350 ohm, 3 mV/V load-cell bridge from a 3.3 V rail and produces out = 1.65 V + 1.2 V x s, meeting bounded wake-from-arbitrary-charge settling (2 ms), strain-step settling/overshoot, ripple/periodicity at any 7.76-12.36 kHz clock, 24 mV accuracy over +/-300 uV offset, 12 mW measure power including bridge, and 5 uA sleep — as /app/output/readout.cir.

Why it fits:
- • It is a design decision, not an analysis: the deliverable is a netlist whose topology and values are chosen by the agent.
- • It is checkable without a human: ngspice transients with the supplied parts.lib plus a Python netlist parser cover function, accuracy, settling, ripple, power, sleep and construction rules.
- • The physics that matters (op-amp pole/GBW, output clamps, switch Ron/hysteresis, bridge resistance modulation, supply gating) is inside the supplied behavioral models, so the graded behaviour is the modelled behaviour.
- • The trade-off is real and coupled: 2 ms settling from any 0-3.3 V capacitor charge fights the 0.5 mV ripple limit at the lowest clock and the 4.8 mV overshoot limit, while offset and E24 gain quantisation eat the 24 mV accuracy window.

What stops it:
- • Structural objections: none. The task is a bounded design problem with a specified output file and modelled physics.
- • Unresolved feasibility risks (not blocking, but unverified): the reference outline is an unverified concept, explicitly labelled as such by the author; the claimed failures of the four public designs are hypotheses, not trial results. Whether a design exists that meets R1-R8 simultaneously across held-out clocks, offsets and random capacitor charges has not been demonstrated.
- • Runtime is unmeasured: a settling/ripple/step sweep over several clocks x s values x offsets x ic seeds, each repeated at two timesteps for R8, is on the order of 10^2 transient runs; at even 10-30 s per nonlinear transient this may be 15-90 minutes of grading and comparable iteration cost for the agent. Arithmetic on the stated timebases is fine (22 ms at max step 1/(400 x 10 kHz) is ~88k points), but wall-clock is unknown.
- • Numerical-convergence risk: the SW model uses Roff 1e9 and the oa model has discontinuous clamp expressions; large switch networks can produce timestep stalls or convergence warnings, and R8's 0.2 mV / 0.1 ms tolerances must exceed ngspice solver noise on this bench (unmeasured).

How to check it:
- • Static parser (Python): R9 — allowed element types (R, C, S, X oa/inv), subckt name/port order, E24 value or declared series/parallel combination, summed capacitance <= 10 uF.
- • ngspice transient (G2): wake from rest and from three random ic seeds (uniform 0-3.3 V on every C line), 12 ms run; departure of out from its 8-10 ms mean over 2.0-10 ms <= 1.2 mV + 0.05 mV allowance.
- • ngspice transient (G3): 22 ms run with a strain step at 10 ms; settling <= 2.0 ms to the 1.2 mV band and overshoot <= 4.8 mV.
- • Derived from the G3 waveforms (G4): pk-pk over 18-20 ms <= 0.5 mV and |out(t+T)-out(t)| <= 0.15 mV at T = 1/fclk.
- • Settled-mean comparison (G5): error to 1.65 + 1.2 s <= 24 mV across s and vosg sweep points.
- • Power integration (G6): mean of v(vdd) x supply current over 6-10 ms and 14-20 ms <= 12 mW, with an integrated-energy sanity check against bridge dissipation (Vex^2/350 scaled by drive duty; 3.3 V continuous excitation is ~31 mW, matching the author's figure).
- • Sleep bench (G7): en low 5 ms from rest, mean supply current over last 2 ms <= 5 uA and out within 20 mV of 1.65 V.
- • Step-quartering convergence (G8): max timestep 1/(400 fclk) vs 1/(1600 fclk); mean shift <= 0.2 mV, settling-time shift <= 0.1 ms.

Simulation gaps:
- • Noise is explicitly out of scope (8 nV/rtHz white, 100 Hz 1/f corner reduced to a static offset); a real build's noise and drift are not graded, so real ripple/settling will be worse than simulated.
- • Switch charge injection is ignored, so a real demodulator's pedestal and clock feedthrough are absent — this is the largest fidelity gap for a switched-capacitor/chopper design.
- • The oa model is a single-pole behavioural block with hard clamps and an ideal 1e12 ohm input; no input bias current, no CMRR/PSRR, no output current limit, no supply-dependent behaviour beyond the 2 V gate. Simulated settling under capacitive load or bridge imbalance may be optimistic.
- • Strain is applied as a control node with a 10 us ramp; real transducer dynamics and bridge thermal drift are not represented.
- • Unknown: ngspice convergence/stiffness behaviour for large switch matrices, and whether the R8 tolerance is larger than measured solver noise (needs a numerical-noise measurement on the reference bench).

Why frontier models fail:
- • The binding constraints pull in opposite directions: short time constants to erase arbitrary 0-3.3 V initial charges within 2 ms versus enough filtering/damping for 0.5 mV ripple at 7.76 kHz versus <= 4.8 mV overshoot versus 24 mV accuracy across +/-300 uV offset with E24-only gain parts. Tuning to a rest-start, nominal-clock response is the natural failure mode (author's hypothesis, to be confirmed in trials).
- • E24 gain quantisation plus offset means the accuracy budget must be closed analytically before simulation, not by trial-and-error sweeps.
- • Duty-cycled excitation must keep mean power (bridge + op-amp quiescent, 150 uA each at 3.3 V) under 12 mW while sleeping under 5 uA, i.e. supply gating has to be designed, not added later.
- • These are engineering-trade-off reasons, not hidden rules or pure tedium; the claim that frontier models fail here is a hypothesis until trial runs are done.

Real-world risks:
- • Charge injection, clock feedthrough, PCB parasitics and connector/lead resistance to a 350 ohm bridge are absent from the model and would eat the 0.5 mV ripple and 24 mV accuracy budgets on hardware.
- • 12 mW with a 3.3 V coin cell implies substantial duty cycling of the bridge; real excitation settling and thermoelectric offsets are unmodelled.
- • Common-mode half-excitation drive on sp/sn means the amplifier input range and CMRR (unmodelled) matter in a real build.
- • Noise is ungraded but real; a design that passes in simulation may not resolve fine strain in the field.

Milestones (if too big): not required at Stage 1, but if trial runtime is prohibitive, split as: 1. DC-excited accuracy/power/sleep front end: grader checks R5, R6, R7 on readout.cir. 2. Duty-cycled excitation plus demodulation with reset: grader checks R1, R2, R3, R4, R8 on the full subcircuit.

What to change (reshape): • Nothing yet. The single-subcircuit, single-file deliverable is coherent and Stage-1 complete; the open items below are specifications and verification, not scope changes.

Numbers to supply next:
- • Requirement (spec): an explicit netlist-complexity cap so grading stays bounded — e.g. "at most 40 R/C/S/X instances and at most 20 internal nodes".
- • Requirement (spec): exact syntax accepted for E24 series/parallel combinations — e.g. "two explicit R elements in series, or a value written as {10k+2.2k} / {10k||2.2k}, to 1 percent rounding".
- • Requirement (spec): whether `.param` lines are permitted and which parameters may be set (e.g. "allowed, but not vosg") — currently ambiguous against G1's allowed-line list.
- • Requirement (verification needed): a measured per-transient runtime and total grader sweep budget — e.g. "each transient <= 30 s on one CPU core; full G2-G8 sweep <= 40 min".
- • Requirement (verification needed): numerical-noise floor of ngspice on the reference bench, to confirm R8's 0.2 mV / 0.1 ms limits exceed solver noise — e.g. "repeat an identical run at two timesteps and record mean shift".
- • Requirement (verification needed): a reference netlist that actually passes R1-R8 across held-out clocks (7.76, 9.3, 11.1, 12.36 kHz), s points (0, +/-0.37, -0.81, +/-1), offsets (+/-300, +217 uV) and ic seeds, plus reproduced failures of the four named public designs.
- • Interface (spec): the grader bench fixture as a file — e.g. /app/input_assets/bench_wake.cir showing the bridge instantiation with ctl driven by 1 V = s=+1, Vsup source, clk/en sources and the 1 Mohm || 100 pF load to 1.65 V, plus the exact rule for appending `ic=` to C lines.
- • Interface (spec): confirmation that `out` is the sole output node, that no internal node may be exposed, and the required port order string `.subckt readout vdd gnd clk en xp xn sp sn out`.
- • Handbook data (already largely supplied; confirm): E24 table and rounding rule, op-amp static model (A0=1e5, GBW=5 MHz, 0.1-3.2 V clamp, 10 ohm Ro, 150 uA Iq), SW (Ron 5, Roff 1e9, vt 1.65 +/-0.2 V hysteresis), inv (100 ohm, threshold vdd/2), bridge sensitivity 3 mV/V and 350 ohm drive impedance.

Evidence status: Draft-only input. The reference outline, public-design failure claims, mechanism-survival narrative and distinct_valid_designs are author claims; no filesystem inspection or simulation execution has occurred here. Stated requirements (R1-R9, limits, models) are taken as given specification. Engineering inferences made here: bridge dissipation at 3.3 V continuous excitation computes to ~31 mW (consistent with the author's figure); 2 ms settling to 1.2 mV implies single-pole time constants around or below ~0.26 ms for full-span transients, which puts the ripple filter corner in tension with the 7.76 kHz ripple limit; per-run transient step counts (~88k for 22 ms at 1/(400 fclk)) are modest, but wall-clock runtime is unmeasured. Nothing in this report is verified evidence.

Checks before full-task readiness: 1. Build and simulate a reference netlist across held-out clocks, s, offsets and random capacitor charges; confirm every requirement passes and record margins. 2. Measure per-transient and full-sweep runtime on target hardware; add an explicit element-count cap if needed. 3. Measure ngspice timestep-convergence noise on the reference design to confirm R8 tolerances are above solver noise. 4. Pin the E24 series/parallel syntax rule and .param policy so G1 is unambiguous. 5. Reproduce at least two of the claimed public-design failures (offset-amplified DC in-amp error; AC-coupling charge decay) to validate that the catching rows are real discriminators.