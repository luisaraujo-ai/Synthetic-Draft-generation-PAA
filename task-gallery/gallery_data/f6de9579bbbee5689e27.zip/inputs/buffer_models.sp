* Fixed external part models for the sample-and-hold drive
* Buffer: unity-gain follower, feedback from OUT. ib = bias current (A); GBW = 120MHz*ib/200u
* gbwscale multiplies GBW (use 0.75 / 1.25 for corners). Second pole fixed 400MHz, Rout 40 ohm.
.subckt BUF in out ib=200u gbwscale=1
.param pi=3.14159265
.param gbw={120meg*(ib/200u)*gbwscale}
.param a0=3162
.param fp1={gbw/a0}
E1 n0 0 value={a0*(v(in)-v(out))}
R1 n0 n1 1k
C1 n1 0 {1/(2*pi*1k*fp1)}
E2 n2 0 n1 0 1
R2 n2 n3 1k
C2 n3 0 {1/(2*pi*1k*400meg)}
E3 n4 0 n3 0 1
Rout n4 out 40
.ends BUF
* Switch: closed (resistance ron) while control > 0.5 V, 1G when open. ron nominal 40 ohm (+/-20%).
.model SWM SW(ron=40 roff=1e9 vt=0.5 vh=0.05)
* Fixed network: BUF out -> node OUT; C 3p (+/-20%) and Cb from OUT to ground;
* Rs from OUT to switch; switch to node CS; Cs 8p (+/-10%) from CS to ground.
