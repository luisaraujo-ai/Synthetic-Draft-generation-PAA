I need the input sample-and-hold drive for a 12-bit SAR converter in a multi-channel logger. The sample clock comes from a drifting source, so the rate wanders anywhere from 20 to 30 MS/s. The sampling switch is closed for the first 45% of every period, and the held sample must be accurate at the instant it opens. I want a drive that settles cleanly at every rate in the band without ringing.

Fixed parts: a unity-gain buffer drives an output node. That node carries 3 pF of parasitic capacitance to ground, plus your added bypass capacitor. A series damping resistor then connects to the sampling switch, and the switch connects to an 8 pF sampling capacitor to ground. Switch on-resistance is 40 ohm. The buffer is described in full in /app/input_assets/buffer_models.sp. Its gain-bandwidth is set by its bias current. The full-scale input is 1 V, taken as a step from -0.5 V to +0.5 V or the reverse at the start of each window. One LSB is 1 V / 4096.

You choose three values: the series damping resistor (0 to 500 ohm), the bypass capacitor (0 to 50 pF) and the buffer bias current (50 to 400 uA).

Requirements, all measured on the sampling-capacitor voltage. They must hold at every sample rate from 20 to 30 MS/s and in every combination of these corners: buffer gain-bandwidth -25%/+25%, output-node parasitic capacitance -20%/+20%, sampling capacitor -10%/+10%, switch on-resistance -20%/+20%.

1. Error at the instant the switch opens, in each of 20 consecutive windows of alternating full-scale steps, starting with the capacitor and buffer at the opposite polarity: at most 122 uV (0.5 LSB).
2. Same error limit in each of the first 3 windows after power-up, with the capacitor at 0 V and the first input step 0 V to +0.5 V.
3. Overshoot beyond the final value, in any window: at most 5% of the step size (50 mV).
4. Buffer bias current: at most 400 uA.
5. Numerical robustness: the window-end error must be computed accurately enough that refining the numerical resolution of the simulation by a factor of two changes it by at most 25 uV.

Deliver /app/output/design.json with these numeric fields: "rs_ohm", "cb_pf", "ibias_ua".
