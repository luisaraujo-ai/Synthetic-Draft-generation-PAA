### 12 · SAR sample-and-hold buffer rate-band settling — advance, rank 8

Design decision as written: yes — "You choose three values: the series damping resistor (0 to 500 ohm), the bypass capacitor (0 to 50 pF) and the buffer bias current (50 to 400 uA)"

Forge task: Design a unity-gain SAR input drive (select Rs in 0–500 Ω, Cb in 0–50 pF, Ibias in 50–400 µA for a fixed buffer subcircuit) so the 8 pF sampling capacitor settles to ≤122 µV error at the switch-opening instant with ≤5% overshoot across 20–30 MS/s and all 16 combinations of GBW ±25%, Cpar ±20%, Cs ±10%, Ron ±20%, delivered as `/app/output/design.json` with numeric fields rs_ohm, cb_pf, ibias_ua.

Why it fits:
• It is a physical design decision (component value selection in a real mixed-signal network), not analysis of a fixed system.
• ngspice runs headless and can rebuild the circuit from the supplied `.subckt` and check every stated requirement: transient window-end error, overshoot, power-up first-3-window error, and time-step refinement (R5).
• The core difficulty is engineering-real: loop phase margin (fixed 400 MHz second pole, Rout=40 Ω driving node capacitance) trades against RC settling of (Rs+Ron)·Cs, and ringing phase relative to window end shifts non-monotonically across the rate band — exactly the coupled behaviour a knob-turning model gets wrong.
• Bounded parameter space (3 continuous knobs) and one small output file fit a single agent run; no human judgement is needed in grading.

What stops it:
• Structural: none. The task is a bounded parameter-selection problem over a specified, reproducible network.
• Unresolved feasibility risk (not a reason to drop): no passing design is demonstrated — the draft states "no passing reference demonstrated yet" and that its thresholds are provisional estimates (author claim, unverified). Whether a single (Rs, Cb, Ibias) point satisfies R1–R3 at all 17 corner/rate cases simultaneously is an open question until a reference sweep runs.
• Unresolved coverage risk: the brief requires "every sample rate from 20 to 30 MS/s", but the grader samples discrete rates (20, 30 and ≥8 undisclosed). A design failing at an unchecked intermediate rate would pass the grader yet fail the stated requirement.
• Unresolved definition risk: R5 constrains simulation numerics (change ≤25 µV on halving max time step), which is a grader-consistency property rather than a built hardware property; the max-step reference value and integration method are not fixed in the text.
• Runtime risk is unquantified: 17 corner/rate cases × 20 windows × (design sweep + a halved-step re-run) — an author claim of feasibility, with no measured runtime supplied.

How to check it:
• ngspice: rebuild BUF + SWM network from `/app/input_assets/buffer_models.sp`; transient-run 20 alternating ±0.5 V windows per rate/corner, measure |Vcap(0.45T) − Vin| and step-direction overshoot; separately run the 0 V power-up case for 3 windows (G2).
• ngspice (second pass, different integration method/tolerances and switch edge 0.1–0.3 ns): re-run with max time step halved and compare max window-end error (G3).
• A JSON schema check validates rs_ohm/cb_pf/ibias_ua numeric fields and bounds (G1's first step).

Simulation gaps:
• The supplied subcircuit is idealised: no slew rate, no headroom/supply limits (1.8 V stated but not modelled), no noise, no switch charge injection/clock feedthrough, no buffer input capacitance or PSRR — so a passing simulation does not establish silicon behaviour.
• The switch is a behavioural SW model with a 0.05 V hysteresis window and an edge time whose effect is asserted to be immaterial (author claim); edge-time sensitivity at fast ringing rates is unverified.
• GBW corner scaling is assumed to scale the dominant pole linearly; real buffers vary offset, output impedance and second-pole position with bias too.
• Numerical accuracy near 122 µV on a 1 V step (~7e-5 relative) is close to what transient tolerances reliably resolve; R5 partially guards this but the reference step size, method and ngspice version are unspecified.
• Discrete rate grid can alias with ringing zero-crossings; a finite grid cannot prove the continuous-band claim.

Why frontier models fail:
• The bias/settling/damping trade is coupled: raising Ibias helps the slow corner (GBW −25% at 30 MS/s) but erodes phase margin and raises overshoot at GBW +25%, while Rs and the Rout–Cb pole interact inside the loop. Naive "max bandwidth" or "big reservoir" intuitions fail one side of the trade.
• Error vs sample rate is non-monotonic because ringing phase relative to the window end moves; a model that checks only 20 and 30 MS/s or only nominal corners will pick a knife-edge point that fails at held-out rates and corners.
• Robust designs need deliberate margin, not threshold-hugging — a systematic sweep plus margin discipline, which is tedious and easy to shortcut. (Predicted failure is a hypothesis here; no trials are supplied.)

Real-world risks:
• Simulated pass still leaves unmodelled charge injection, switch leakage, clock jitter at the 0.45T aperture instant, resistor tolerance/tempco, PCB parasitics beyond the 3 pF, and buffer noise/offset — none are in the checker.
• The 20 MS/s lower rate is generous in time but the 30 MS/s corner with GBW −25% is the binding constraint; if the true buffer's second pole is below 400 MHz, real settling would be worse than simulated.

Milestones (if too big): not required — one run suffices if the sweep is scripted. If measured sweep runtime exceeds budget, split into: 1. Nominal + slow-corner feasibility sweep (grader: max window-end error ≤122 µV and overshoot ≤5% at 20/30 MS/s, corners GBW ×0.75 and RC-high). 2. Full 17-case verification with halved-step robustness (grader: R1–R5 over all corners and the undisclosed rate set).

What to change (reshape): none required — same device and same core decision. If the SME wants tighter scope, restrict the claim to a specified rate grid rather than the continuous band, or state R5's reference numerics explicitly; these are pinning-down changes, not reshapes.

Numbers to supply next:
• Requirement: rate sampling rule for "every rate in the band" — e.g. verify at 0.25 MS/s steps plus ≥10 uniform-random undisclosed rates in 20–30 MS/s (example).
• Requirement: R5 reference numerics — e.g. max time step 5 ps → 2.5 ps, trap + gear comparison, ngspice 42, reltol 1e-6, and acceptance of ≤25 µV change (example).
• Requirement: overshoot reference for the power-up case — e.g. fraction of the 0.5 V first step vs the 1 V full-scale step (state which).
• Requirement: measured runtime budget for a full corner×rate sweep — e.g. per-case transient ≤2 s wall clock on one core (example; to be measured, not estimated).
• Interface: input `/app/input_assets/buffer_models.sp` (fixed, as embedded); output `/app/output/design.json` schema — {"rs_ohm": number 0–500, "cb_pf": number 0–50, "ibias_ua": number 50–400}; checker rebuilds the network itself.
• Handbook data: corner application table — e.g. GBW ×{0.75, 1.0, 1.25}, Cpar ×{0.8, 1.0, 1.2} on 3 pF, Cs ×{0.9, 1.0, 1.1} on 8 pF, Ron ×{0.8, 1.0, 1.2} on 40 Ω (16 extreme combos + nominal).
• Handbook data: switch model parameters — e.g. SWM(ron=40 roff=1e9 vt=0.5 vh=0.05), edge time sampled in 0.1–0.3 ns.
• Verification still needed: run one reference sweep to demonstrate at least one passing (Rs, Cb, Ibias) point with margin at the slow-GBW/high-RC corner at 30 MS/s and at the +25% GBW corner; reproduce at least one listed public-design failure to calibrate the claimed narrow feasible band; measure sweep runtime and numerical noise floor (uV-level agreement between two integration methods).

Evidence status: draft-only. The buffer/switch netlist is supplied text (establishes the specified dependency, not validated model fidelity); the reference outline, budget fit, public-design failure claims, mechanism-survival narrative and threshold margins are author claims and remain unverified — no simulation output, passing design or runtime measurement is attached. Checkability in principle (ngspice, headless) is assessed from the text; implemented and validated coverage is not established.

Checks before full-task readiness: (1) reproduce a baseline failure of one listed public design to confirm the checks discriminate; (2) demonstrate a passing design with stated margin across all 17 cases and the halved-step re-run; (3) fix the rate-sampling rule, R5 numerics definition and power-up overshoot basis; (4) measure per-case and total sweep runtime and the uV-level numerical agreement between two integration methods; (5) confirm the switch edge-time insensitivity claim empirically in 0.1–0.3 ns.